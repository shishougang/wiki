#include "hello.h"

int main() {
  Print("Hello World\n");
  return 0;
}
