void Print(const char* s);
