#include <stdio.h>

void Print(const char* s) {
  printf("%s", s);
}
