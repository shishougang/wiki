#include "/etc/latrace.d/headers/latrace.h"
void Print(const char* s);
