#include <linux/fs.h>
#include <linux/init.h>
#include <linux/miscdevice.h>
#include <linux/module.h>
#include <asm/uaccess.h>
#include <linux/wait.h>
#include <linux/sched.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("wait queue example module");

//wait_queue_head_t read_wait_queue;
DECLARE_WAIT_QUEUE_HEAD(read_wait_queue);
int read_flag = 0;
static ssize_t buffer_read(struct file * file, char * buf, 
			  size_t count, loff_t *ppos) {
  char *str = "read finished\n";
  ssize_t ret;
  int len = strlen(str);
  printk(KERN_INFO "prepare to read\n");
  wait_event_interruptible(read_wait_queue, read_flag != 0);
  printk(KERN_INFO "reader woken up\n");
  read_flag = 0;
  ret = copy_to_user(buf, str, len);
  return ret;
}

ssize_t buffer_write(struct file *file, const char *buff,
                     size_t count, loff_t *offp) {
  ssize_t ret;
  char str[100];
  printk(KERN_INFO "writer to woke up reader\n");
  read_flag = 1;
  wake_up_interruptible(&read_wait_queue);
  ret = copy_from_user(str, buff, 100);
  return ret;
}

static const struct file_operations buffer_fops = {
	.owner		= THIS_MODULE,
	.read		= buffer_read,
        .write          = buffer_write,
};

static struct miscdevice wait_test_dev = {
	/*
	 * kernel to just pick minor number.
	 */
	MISC_DYNAMIC_MINOR,
	/*
	 * Name ourselves /dev/hello.
	 */
	"wait_test",
	&buffer_fops
};

static int __init wait_test_init(void) {
	int ret;
	ret = misc_register(&wait_test_dev);
	if (ret)
		printk(KERN_ERR
		       "Unable to register wait test misc device\n");
	return ret;
}
module_init(wait_test_init);

static void __exit wait_test_exit(void) {
	misc_deregister(&wait_test_dev);
}
module_exit(wait_test_exit);
