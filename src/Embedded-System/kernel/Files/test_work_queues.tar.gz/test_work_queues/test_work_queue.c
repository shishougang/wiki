#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/workqueue.h>
#include <linux/sched.h>
#include <linux/slab.h>
#include <linux/delay.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("work queues examples");


static void work_queue1_func(struct work_struct* work);
static void work_queue2_func(struct work_struct* work);
static void delay_work_queue_func(struct work_struct* work);

static struct work_struct* test_work1;
static DECLARE_WORK(test_work2, work_queue2_func);
static DECLARE_DELAYED_WORK(test_work3, delay_work_queue_func);
static struct workqueue_struct *test_workqueue;
static int stop;

static void work_queue1_func(struct work_struct* work) {
  printk("%s(): on cpu:%d, pname:%s\n",
         __func__, smp_processor_id(), current->comm);
}

static void work_queue2_func(struct work_struct* work) {
  printk("%s(): on cpu:%d, pname:%s\n",
         __func__, smp_processor_id(), current->comm);
  msleep(50);
  if (!stop) {
    queue_work(test_workqueue, &test_work2);
  }
}

static void delay_work_queue_func(struct work_struct* work) {
  printk("%s(): on cpu:%d, pname:%s\n",
         __func__, smp_processor_id(), current->comm);
  queue_delayed_work(test_workqueue, &test_work3, 50);
}

static int __init test_work_queue_init(void) {
  test_work1 = kzalloc(sizeof(*test_work1), GFP_KERNEL);
  INIT_WORK(test_work1, work_queue1_func);
  schedule_work(test_work1);

  test_workqueue = create_workqueue("test_work_queue");
  stop = 0;
  queue_work(test_workqueue, &test_work2);
  queue_delayed_work(test_workqueue, &test_work3, 1);
  return 0;
}

static void __exit test_work_queue_exit(void) {
  cancel_delayed_work(&test_work3);
  flush_workqueue(test_workqueue);
  stop = 1;
  destroy_workqueue(test_workqueue);
}

module_init(test_work_queue_init);
module_exit(test_work_queue_exit);
