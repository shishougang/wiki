#include <stdio.h>

/*
  Write a function rightrot(x,n) that returns the value of the integer x rotated to the right by n bit positions.
*/
unsigned int rightrot(unsigned int x, int n)
{
  while(n > 0){
    if((x & 1) == 1)
      x = (x >> 1) | (~(~0 >> 1));
    else
      x = x >> 1;
    --n;
  }
}

int main(int argc, char *argv[])
{
  
  return 0;
}
