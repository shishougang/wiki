#include <stdio.h>
/*
  As written, getint treats a + or - not followed by a digit as a valid representation of zero. Fix it to push such a character back on the input.
*/
int getch(void);
void ungetch(int c);

int getint(int *pn)
{
  int c, sign;
  *pn = 0;
  while(isspace(c = getch()));

  if(!isdigit(c) && (c != '+') && (c != '-')){
    return 0;
  }

  sign = (c == '-')? -1 : 1;
  if(c == '+' || c == '-'){
    c = getch();
    if(!isdigit(c)){
      ungetch(c);
      return 0;
    }
  }
  while(isdigit(c)){
    *pn = *pn * 10 + (c - '0');
    c = getch();
  }
  *pn *= sign;
  if(c != EOF)
    ungetch(c);
  return c;
}
  

int main(int argc, char *argv[])
{
  
  return 0;
}
