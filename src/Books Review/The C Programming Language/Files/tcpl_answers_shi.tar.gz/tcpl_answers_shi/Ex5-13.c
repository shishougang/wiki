#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
  Write the program tail, which prints the last n lines of its input. By default, n is 10, say, but it can be changed by an optional argument, so that 
  tail -n

prints the last n lines. The program should behave rationally no matter how unreasonable the input or the value of n. Write the program so it makes the best use of available storage; lines should be stored as in the sorting program of Section 5.6, not in a two-dimensional array of fixed size.
*/
#define MAXLINES    5000
char *lineptr[MAXLINES];

#define BUFFERSIZE    5000

#define DEFAULT_LAST  10

int readlines(char *lineptr[], char *buffer, int maxlines);
void unwrap(char *buffer, int index);
void reverse(char *lineptr[], int nlines);


int main(int argc, char *argv[])
{
  int i, last;
  char *p;

  last = DEFAULT_LAST;
  for(i = 0; i < argc; ++i){
    p = argv[i];
    if(*p == '-'){
      ++p;
      last = 0;
      while(isdigit(*p)){
        last = last * 10 + (*p - '0');
        ++p;
      }
      if(*p != '\0'){
        printf("Invalid argument:%s\n", argv[i]);
        last = DEFAULT_LAST;
      }
    }
  }

  int nlines;
  char buf[BUFFERSIZE];
  int offset;
  nlines = readlines(lineptr, buf, MAXLINES);

  if(nlines < last){
    printf("the number of lines is too small, only print the last %d\
lines.\n",nlines);
    offset = 0;
  }
  else{
    offset = nlines - last;
  }

  for(i = 0; i < nlines && i < last; ++i){
    printf("%s\n", lineptr[offset + i]);
  }
  
  return 0;
}


int readlines(char *lineptr[], char *buffer, int maxlines)
{
  int wrap = 0;
  int c, offset;
  char *p;
  p = buffer;

  while((c = getchar()) != EOF){
    if(c == '\n')
      *p = '\0';
    else
      *p = c;
    ++p;
    if(p - buffer == BUFFERSIZE){
      wrap = 1;
      p = buffer;
    }
  }

  if(wrap){
    unwrap(buffer, p - buffer);
    p = buffer + BUFFERSIZE;
  }
  --p;
  *p = '\0';

  int nlines = 0;
  while(p >= buffer && nlines < maxlines){
    --p;
    if(*p == '\0'){
      lineptr[nlines++] = p + 1;
    }
  }
  reverse(lineptr, nlines);
  return nlines;
}

void unwrap(char *buffer, int index)
{
  char store[BUFFERSIZE];
  memcpy(store, buffer + index, BUFFERSIZE - index);
  memcpy(store + BUFFERSIZE - index, buffer, index);
  memcpy(buffer, store, BUFFERSIZE);
}

void reverse(char *lineptr[], int nlines)
{
  int i;
  char *tmp;
  for(i = 0; i < nlines / 2; ++i){
    tmp = lineptr[i];
    lineptr[i] = lineptr[nlines - 1 - i];
    lineptr[nlines - 1 - i] = tmp;
  }
}
  
