#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>
/*
  Write a program that reads a C program and prints in alphabetical order each group of variable names that are identical in the first 6 characters but different somewhere thereafter. Don't count words within strings and comments. Make 6 a parameter that can be set from the command line.
 */
#define MAXWORD 100
#define NUM_CHAR 6
struct tnode{
  char *word; /* points to the text */
  int count;  /* number of occurrences */
  struct tnode *left;
  struct tnode *right;
};

struct tnode *addtree(struct tnode*, char *);
char *treeprint(struct tnode*, char *, int n);
int getvar(char *, int);

int main(int argc, char *argv[])
{
  struct tnode *root;
  char var[MAXWORD];
  int i, n;
  char *p;

  n = NUM_CHAR;
  for(i = 1; i < argc; ++i){
    p = argv[i];
    if(*p == '-'){
      ++p;
      if(*p == 'n'  && *(p+1) == '\0' && argc - i > 1){
        ++i;
        n = 0;
        for(p = argv[i]; *p != '\0'; ++p){
          if(isdigit(*p)){
            n = n * 10 + (*p - '0');
          }
          else{
            fprintf(stderr, "Usage: %s [-n NUM]\n", argv[0]);
            return EXIT_FAILURE;
          }
        }
        break;
      }
      else{
        fprintf(stderr, "Usage: %s [-n NUM]\n", argv[0]);
        return EXIT_FAILURE;
      }
    }
    else{
      fprintf(stderr, "Usage: %s [-n NUM]\n", argv[0]);
      return EXIT_FAILURE;
    }
  }


  root = NULL;
  while(getvar(var, MAXWORD) != EOF){
    root = addtree(root, var);
  }
  treeprint(root, NULL, n);
  return 0;
}
struct tnode *tnode_alloc(void);

struct tnode *addtree(struct tnode *t, char *w)
{
  int cond = 0;
  if(t == NULL){
    t = tnode_alloc();
    t->word = strdup(w);
    t->count = 1;
    t->left = t->right = NULL;
  }
  else if((cond = strcmp(t->word, w)) == 0){
    t->count++;
  }
  else if(cond > 0){
    t->right = addtree(t->right, w);
  }
  else{
    t->left = addtree(t->left, w);
  }
  return t;
}

char *treeprint(struct tnode *root, char *w, int n)
{
  char *p;
  if(root != NULL){
    p = treeprint(root->left, w, n);
    if(p != NULL && strncmp(p, root->word, n) != 0)
      printf("\n");
    printf("%s\n", root->word);
    return treeprint(root->right, root->word, n);
  }
  else{
    return w;
  }
}

struct tnode *tnode_alloc(void)
{
  return (struct tnode*) malloc(sizeof(struct tnode));
}

int isletter(int c)
{
  return isalpha(c) || c == '_';
}

int getch(void);
void ungetch(int c);

int getvar(char *var, int lim)
{
  int c;
  char *v = var;

  while((c = getch()) != EOF){
    if(c == '\''){
      c = getch();
      if(c = '\\')
        c = getch();
      c = getch();
    }
    else if(c == '"'){
      while((c = getch()) != '"' && c != EOF){
        if(c = '\\')
          c = getch();
      }
    }
    else if(c == '/'){
      if((c = getch()) == '*'){
        while(1){
          c = getch();
          if(c == '*'){
            c = getch();
            if(c == '/')
              break;
          }
          else if(c == EOF)
            break;
        }
      }
      else
        ungetch(c);
    }
    else if(c == '#'){
      while((c = getch()) != '\n' && c != EOF){
        if(c == '\\')
          c = getch();
      }
    }
    else if(isletter(c)){
      *v++ = c;
      for(; --lim > 0; v++){
        if(!isletter((*v = getch())) && !isdigit(*v)){
          ungetch(*v);
          break;
        }
      }
      *v = '\0';
      return var[0];
    }
  }
  return EOF;
  
}

#define BUFSIZE 100

char buf[BUFSIZE];	/* buffer for ungetch */
int bufp = 0;		/* next free position in buf */

int getch(void) /* get a (possibly pushed back) character */
{
	return (bufp > 0) ? buf[--bufp] : getchar();
}

void ungetch(int c)	/* push character back on input */
{
	if (bufp >= BUFSIZE)
		printf("ungetch: too many characters\n");
	else
		buf[bufp++] = c;
}
