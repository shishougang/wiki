#include <stdio.h>
#include <limits.h>
#include <float.h>
#include <ctype.h>

/*
  Extend atof to handle scientific notation of the form 123.45e-6 where a floating-point number may be followed by e or E and an optionally signed exponent.
 */
enum{
  SUCCESS,
  FAIL
};

int do_atof(char *s, double *p_num)
{
  if(s == NULL || p_num == NULL)
    return FAIL;

  double ret = 0;
  double one_tenth = 0.1;
  double ten = 10.0;
  int is_negative = 0;
  int found_digits = 0;
  char *str;
  str = s;
  
  while(isspace(*str))
    ++str;
  if(*str == '+')
    ++str;
  else if(*str == '-'){
    ++str;
    is_negative = 1;
  }

  while(isdigit(*str)){
    found_digits = 1;
    ret *= ten;
    ret += *str - '0';
    ++str;
  }

  if(*str == '.'){
    double scale = one_tenth;
    ++str;
    while(isdigit(*str)){
      found_digits = 1;
      ret += scale * (*str - '0');
      scale *= one_tenth;
      ++str;
    }
  }

  if(!found_digits){
    *p_num = 0;
    return FAIL;
  }

  if(ret == 0.0){
    *p_num = 0;
    return SUCCESS;
  }

  if((*str == 'e') || (*str == 'E')){
    int neg_exponent = 0;
    long exponent = 0;
    double getting_too_big = DBL_MAX * one_tenth;
    double getting_too_small = DBL_MIN * ten;

    ++str;
    if(*str == '+'){
      ++str;
    }
    else if(*str == '-'){
      neg_exponent = 1;
      ++str;
    }

    while(isdigit(*str)){
      if(exponent > (LONG_MAX / 10))
        break;
      exponent *= 10;
      exponent += *str - '0';
      ++str;
    }
    int i;
    if(neg_exponent){
      for(i = 0; i < exponent; ++i){
        if(ret < getting_too_small){
          ret = DBL_MIN;
          break;
        }
        else{
          ret *= one_tenth;
        }
      }
    }
    else{
      for(i = 0; i < exponent; ++i){
        if(ret > getting_too_big){
          ret = DBL_MAX;
          break;
        }
        else{
          ret *= ten;
        }
      }
    }
  }

  if(is_negative)
    ret = -ret;
  *p_num = ret;
  return SUCCESS;
}

int main(int argc, char *argv[])
{
  char  *strings[] = {
    "1.0e43",
    "999.999",
    "123.456e-9",
    "-1.2e-3",
    "1.2e-3",
    "-1.2E3",
    "-1.2e03",
    "cat",
    "",
    0
  };
  int i;
  double num = 0;
  for(i = 0; strings[i]; ++i){
    do_atof(strings[i], &num);
    printf("atof(%s) = %g \n", strings[i], num);
  }
  
  return 0;
}
