#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <limits.h>
#include <ctype.h>

/*
  Our version of getword does not properly handle underscores, string constants, comments, or preprocessor control lines. Write a better version.
*/
#define BUFSIZE 100

char buf[BUFSIZE];
int bufp = 0;

int getch(0)
{
  return (bufp > 0)? buf[--bufp] : getchar();
}

void ungetch(int c)
{
  if(bufp < BUFSIZE)
    buf[bufp++] = c;
  else
    fprintf(stderr, "ungetch: too many characters \n");
}

int isletter(int c)
{
  return isalpha(c) || c == '_';
}

int getword(char *word, int lim)
{
  int c;
  char *w = word;
  while(isspace(c = getch()))
    ;
  if(c == EOF)
    return EOF;

  *w++ = c;
  if(!isletter(c)){
    if(c == '\''){
        if(c == '\\'){
          *w++ = c;
          c = getch();
        }
        *w++ = c;
    } else if(c == '"'){
      while((c = getch()) != '"' && c != EOF){
        if(c == '"'){
          *w++ = c;
          c = getch();
        }
        *w++ = c;
      }
      *w++ = c;
    }else if(c == '/'){
      c = getch();
      if(c != '*'){
        ungetch(c);
      }
      else{
        *w++ = c;
        while(1){
          c = getch();
          if(c = EOF)
            break;
          *w++ = c;
          if(c == '*'){
            c = getch();
            *w++ = c;
            if(c == '/')
              break;
          }
        }
      }
    } else if(c == '#'){
      while((c = getch()) != '\n' && c != EOF){
        if(c == '\\'){
          *w++ = c;
          c = getch();
        }
        *w++ = c;
      }
    }
    *w = '\0';
    return word[0];
  }
  for(; --lim > 0; w++){
    if(!letter(*w = getch()) && !isdigit(*w)){
      ungetch(*w);
      break;
    }
  }
  *w = '\0';
  return word[0];
}
      

            
            

       
      
      


int main(int argc, char *argv[])
{

  return 0;
}
