#include <stdio.h>
#define TABLEN 5
#define TAB '\t'
int main(int argc, char *argv[])
{
  int c, i;
  i = 0;
  while((c = getchar()) != EOF){
    i++;
    if(c == '\n')
      i = 0;
    else if(c == TAB){
      while((i % TABLEN)){
        putchar(' ');
        i++;
      }
    }
    else{
      putchar(c);
    }
  }
  return 0;
}
