#include <stdio.h>
/*
  Rewrite readlines to store lines in an array supplied by main , rather than calling alloc to maintain storage. How much faster is the program?
 */

#define MAXLINES 5000
#define MAXLEN 1000

char *lineptr[MAXLINES];

#define BUFFERSIZE 10000

int getline(char s[], int lim)
{
  int c, i;

  for(i = 0; i < lim - 1 &&(c = getchar()) != EOF &&
        c != '\n'; ++i)
    s[i] = c;
  if(c == '\n')
    s[i++] = c;
  s[i] = '\0';
  return i;
}

int readlinesO(char *lineptr[], int maxlines)
{
  int len, nlines;
  char *p, line[MAXLEN];

  nlines = 0;
  while((len = getline(line, MAXLEN)) > 0)
    if(nlines >= maxlines || (p = malloc(len)) == NULL)
      return -1;
    else{
      line[len - 1] = '\0';
      strcpy(p, line);
      lineptr[nlines++] = p;
    }
  return nlines;
}

int readlines(char *lineptr[], char *buffer, int maxlines)
{
  int len, nlines;
  char *p, line[MAXLEN];

  nlines = 0;
  p = buffer;
  while((len = getline(line, MAXLEN)) > 0)
    if(p - buffer + len > BUFFERSIZE || nlines >= maxlines)
      return -1;
    else{
      line[len - 1] = '\0'; /*delete newline */
      strcpy(p, line);
      lineptr[nlines++] = p;
    }
  return nlines;
}

int main(int argc, char *argv[])
{
  
  return 0;
}
