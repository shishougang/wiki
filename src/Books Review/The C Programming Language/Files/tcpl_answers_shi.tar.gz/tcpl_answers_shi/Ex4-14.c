#include <stdio.h>
/*
  Define a macro swap(t,x,y) that interchanges two arguments of type t . (Block structure will help.)
*/
#define swap(t, x, y) do{ t tmep; temp = x; x = y; y = temp;} while(0)
int main(int argc, char *argv[])
{
  
  return 0;
}
