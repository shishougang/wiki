#include <stdio.h>
#include <string.h>

/*
  Write an alternate version of squeeze(s1,s2) that deletes each character in the string s1 that matches any character in the string s2 .
 */

void squeeze1(char *s1, char *s2)
{
  char char_table[256] = {0};
  int i = 0;
  while(s2[i] != '\0'){
    char_table[(unsigned char) s2[i]] = 1;
    i++;
  }
  i = 0;
  int j = 0;
  while(s1[j] != '\0'){
    if(char_table[(unsigned char) s1[j]]){
      j++;
    }
    else{
      s1[i] = s1[j];
      i++;
      j++;
    }
  }
  s1[i] = '\0';
}

void squeeze2(char *s1, char *s2)
{
  int k;
  for(k = 0; s2[k] != '\0'; ++k){
    int i, j;
    for(i = 0, j = 0; s1[j] != '\0'; ++j){
      if(s1[j] != s2[k]){
        s1[i] = s1[j];
        i++;
      }
    }
    s1[i] = '\0';
  }
}
 

int main(int argc, char *argv[])
{
  char *leftstr[] =
  {
    "",
    "a",
    "antidisestablishmentarianism",
    "beautifications",
    "characteristically",
    "deterministically",
    "electroencephalography",
    "familiarisation",
    "gastrointestinal",
    "heterogeneousness",
    "incomprehensibility",
    "justifications",
    "knowledgeable",
    "lexicographically",
    "microarchitectures",
    "nondeterministically",
    "organizationally",
    "phenomenologically",
    "quantifications",
    "representationally",
    "straightforwardness",
    "telecommunications",
    "uncontrollability",
    "vulnerabilities",
    "wholeheartedly",
    "xylophonically", /* if there is such a word :-) */
    "youthfulness",
    "zoologically"
  };
  char *rightstr[] =
  {
    "",
    "a",
    "the",
    "quick",
    "brown",
    "dog",
    "jumps",
    "over",
    "lazy",
    "fox",
    "get",
    "rid",
    "of",
    "windows",
    "and",
    "install",
    "linux"
  };

  char buffer_algo1[32], buffer_algo2[32];
  int sizeleft = sizeof(leftstr) / sizeof(leftstr[0]);
  int sizeright = sizeof(rightstr) / sizeof(rightstr[0]);
  
  int i, j;
  for(i = 0; i < sizeleft; ++i){
    for(j = 0; j < sizeright; ++j){
      strcpy(buffer_algo1, leftstr[i]);
      squeeze1(buffer_algo1, rightstr[j]);

      strcpy(buffer_algo2, leftstr[i]);
      squeeze2(buffer_algo2, rightstr[j]);

       if(strcmp(buffer_algo1, buffer_algo2) != 0){
        printf("something wrong, leftstr=%s, rightstr=%s, sque1=%s,\
           sque2=%s\n", leftstr[i], rightstr[j], buffer_algo1, buffer_algo2);
       }
    }
  }
  printf("all match,\n");
  return 0;
}
