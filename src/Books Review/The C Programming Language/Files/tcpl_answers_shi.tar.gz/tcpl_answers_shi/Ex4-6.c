#include <stdio.h>
/*
  Add commands for handling variables. (It's easy to provide twenty-six variables with single-letter names.) Add a variable for the most recently printed value.
*/
int main(int argc, char *argv[])
{
  
  return 0;
}
