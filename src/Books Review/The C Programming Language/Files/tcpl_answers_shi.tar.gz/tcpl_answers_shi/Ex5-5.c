#include <stdio.h>
/*
  Write versions of the library functions strncpy , strncat , and strncmp , which operate on at most the first n characters of their argument strings. For example, strncpy(s,t,n) copies at most n characters of t to s . Full descriptions are in Appendix B.
 */
char *strncpy(char *s, const char *t, size_t n)
{
  int i;
  for(i = 0; i < n && t[i] != '\0'; ++i)
    s[i] = t[i];
  while(i < n)
    s[i++] = '\0';
  return s;
}
char *strncat(char *s, const char *t, size_t n)
{
  int i;
  char *ps;
  ps = s;
  while(*ps != '\0')
    ++ps;
  for(i = 0; i < n && t[i] != '\0'; ++i, ++ps)
    *ps = t[i];
  *ps = '\0';
  return s;
}

int strncmp(const char *s, const char *t, size_t n)
{
  int i;
  for(i = 0; i < n && s[i] == t[i]; ++i){
    if(t[i] == '\0' && s[i] == '\0')
      return 0;
    else if(t[i] == '\0')
      return 1;
    else if(s[i] == '\0')
      return -1;
  }
  if(i == n)
    return 0;
  return 1;
}


int main(int argc, char *argv[])
{
  char s[100] = "Hello";
  char t[100] = "World";

  strncpy(s, t, strlen(t) + 1);
  strncat(s, "Word", 4);
  printf("%s\n", s);
  printf("%s\n", t);
  printf("%s\n", (strncmp(s, t, 5) == 0) ? "true" : "false");

  return 0;
}
