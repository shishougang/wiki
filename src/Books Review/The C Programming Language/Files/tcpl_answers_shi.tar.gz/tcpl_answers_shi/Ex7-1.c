#include <stdio.h>
#include <string.h>
/*
  Write a program that converts upper case to lower or lower case to upper, depending on the name it is invoked with, as found in argv[0].
 */

int null_transform(int c)
{
  return c;
}

int main(int argc, char *argv[])
{
  int (*transform) (int);
  if(strcmp(argv[0], "utol") == 0)
    transform = tolower;
  else if(strcmp(argv[0], "ltou") == 0)
    transform = toupper;
  else
    transform = null_transform;

  while((c = getchar()) != EOF)
    putchar(transform(c));
  return 0;
}
