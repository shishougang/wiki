
#  The standard library function calloc(n,size) returns a pointer to n objects of size size , with the storage initialized to zero. Write calloc , by calling malloc or by modifying it.


gcc   -c -o malloc.o malloc.c
gcc   malloc-test.c malloc.o   -o malloc-test
