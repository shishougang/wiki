#include <stdio.h>

/*
  Write a function setbits(x,p,n,y) that returns x with the n bits that begin at position p set to the rightmost n bits of y, leaving the other bits unchanged.
*/



unsigned int setbits(unsigned int x, int p, int n, unsigned int y)
{
  unsigned int msk = ~(~0 << n);
  unsigned int xmsk = x & ~(msk << (p + 1 - n));
  unsigned int ymsk = y & msk;
  return xmsk | (ymsk << (p+1-n));
}
