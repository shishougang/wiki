#include <stdio.h>
#define MAXLEN 101


int getline1(char s[], int lim)
{
  int i;
  int c;
  for(i = 0; (i < lim - 1) && ((c = getchar()) != EOF) && c != '\n'; i++){
    s[i] = c;
  }
  if( c == '\n'){
    s[i] = c;
    i++;
  }
  s[i] = '\0';
  return i;
}

void reverse(char s[], int len){
  int i;
  char temp;
  if(s[len-1] == '\n'){
    len--;
    s[len] = '\0';
  }
  len--;

  for(i = 0; i < len; i++, len--){
    temp = s[len];
    s[len] = s[i];
    s[i] = temp;
  }
}
  
  
int main(int argc, char *argv[])
{

  int n;
  char str[MAXLEN];
  while((n = getline1(str, MAXLEN)) > 0){
    printf("%s", str);
    reverse(str, n);
    printf("%s\n", str);
  }
  
  return 0;
}
