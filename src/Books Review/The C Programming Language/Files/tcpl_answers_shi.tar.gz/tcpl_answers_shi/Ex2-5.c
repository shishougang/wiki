#include <stdio.h>
#include <string.h>

/*
  Write the function any(s1,s2) , which returns the first location in the string s1 where any character from the string s2 occurs, or -1 if s1 contains no characters from s2 . (The standard library function strpbrk does the same job but returns a pointer to the location.)
*/

int any(char *s1, char *s2)
{
  int pos = -1;
  char char_table[256] = {0};
  int i = 0;
  while(s2[i] != '\0'){
    char_table[(unsigned char) s2[i]] = 1;
    i++;
  }
  i = 0;
  while(s1[i] != '\0'){
    if(char_table[(unsigned char) s1[i]] != 0){
      pos = i;
      break;
    }
    i++;
  }
  return pos;
}

int main(int argc, char *argv[])
{
    char *leftstr[] =
  {
    "",
    "a",
    "antidisestablishmentarianism",
    "beautifications",
    "characteristically",
    "deterministically",
    "electroencephalography",
    "familiarisation",
    "gastrointestinal",
    "heterogeneousness",
    "incomprehensibility",
    "justifications",
    "knowledgeable",
    "lexicographically",
    "microarchitectures",
    "nondeterministically",
    "organizationally",
    "phenomenologically",
    "quantifications",
    "representationally",
    "straightforwardness",
    "telecommunications",
    "uncontrollability",
    "vulnerabilities",
    "wholeheartedly",
    "xylophonically",
    "youthfulness",
    "zoologically"
  };
  char *rightstr[] =
  {
    "",
    "a",
    "the",
    "quick",
    "brown",
    "dog",
    "jumps",
    "over",
    "lazy",
    "fox",
    "get",
    "rid",
    "of",
    "windows",
    "and",
    "install",
    "linux"
  };

  size_t numlefts = sizeof leftstr / sizeof leftstr[0];
  size_t numrights = sizeof rightstr / sizeof rightstr[0];
  size_t left = 0;
  size_t right = 0;

  int passed = 0;
  int failed = 0;

  int pos = -1;
  char *ptr = NULL;

  for(left = 0; left < numlefts; ++left){
    for(right = 0; right < numrights; ++right){
      pos = any(leftstr[left], rightstr[right]);
      ptr = strpbrk(leftstr[left], rightstr[right]);
      if(ptr == NULL){
        if(pos == -1){
          ++passed;
        }
        else{
          ++failed;
        }
      }
      else{
        if(pos == -1){
          ++failed;
        }
        if(pos == (ptr - leftstr[left])){
          ++passed;
        }
        else{
          ++failed;
        }
      }
    }
  }
  printf("passed=%d, failed=%d, total=%d\n", passed, failed, passed + failed);
  return 0;
}
