#include <stdio.h>

int main(void)
{
  printf("声音或视觉警告。 \a\n");  
  printf("换页. \f\n");
  printf("This escape, \r, 光标移到本行的起始位置\n");
  printf("纵向制表 \v 。。。\n");

  return 0;
}
