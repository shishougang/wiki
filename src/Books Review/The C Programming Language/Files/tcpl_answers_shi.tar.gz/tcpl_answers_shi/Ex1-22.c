#include <stdio.h>
#include <string.h>

#define MAXLEN 1001
#define LIMIT 20

int getline1(char s[], int lim)
{
  int i, c;
  for(i = 0; (i < lim -1) && ((c = getchar()) != EOF) && c != '\n'; i++){
    s[i] = c;
  }

  if('\n' == c){
    s[i] = c;
    i++;
  }

  s[i] = '\0';
  return i;
}

void cutline(char s[], int start)
{
  int i, j;
  for(i = start + LIMIT; (i > start) && (s[i] != ' ') && (s[i] != '\t'); i--);
  /* [start:start+LIMIT] has no space, find from the start+LIMIT */
  if(i == start){
    for(i = start + LIMIT; (i < strlen(s)) && (s[i] != ' ') && (s[i] != '\t'); i++);
    /* prevent the begining is space */
    for(; (i<strlen(s)) && (s[i] == ' ') && (s[i] == '\t'); i++);
    /*    s[i] = '\n';*/
  }

  if( (strlen(s) - i) < LIMIT){
    s[i] = '\n';
  }
  else if(i > start){
    s[i] = '\n';
    cutline(s,i);
  }
}
    

int main(int argc, char *argv[])
{
  char str[MAXLEN];
  int len;
  while((len = getline1(str, MAXLEN)) > 1){
    if(len > LIMIT)
      cutline(str,0);
    printf("%s", str);
  }
  return 0;
}
