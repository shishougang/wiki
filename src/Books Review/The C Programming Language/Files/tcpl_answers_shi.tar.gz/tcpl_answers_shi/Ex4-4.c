#include <stdio.h>
/* Add commands to print the top element of the stack without popping, to duplicate it, and to swap the top two elements. Add a command to clear the stack.
 */
   
int main(int argc, char *argv[])
{
  
  return 0;
}
