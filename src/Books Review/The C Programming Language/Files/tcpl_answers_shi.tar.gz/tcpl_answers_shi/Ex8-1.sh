gcc -o cat cat.c
gcc -o cat-sys cat-sys.c

time dd if=/dev/zero bs=1M count=1 | ./cat > /dev/null

time dd if=/dev/zero bs=1M count=1 | ./cat-sys > /dev/null
