#include <stdio.h>
int main(void)
{
  printf("press a key please.\n");
  printf(" the value of the expression getchar != EOF is %d. \n", getchar() != EOF);
  return 0;
}
