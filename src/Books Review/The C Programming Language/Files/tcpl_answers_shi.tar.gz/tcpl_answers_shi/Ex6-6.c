#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

/*
  Implement a simple version of the #define processor (i.e., no arguments) suitable for use with C programs, based on the routines of this section. You may also find getch and ungetch helpful. .
 */

  
unsigned int hash(char *s);
struct nlist *lookup(char *name);
struct nlist *install(char *name, char *defn);
void undef(char *name);

struct nlist{
  char *name;
  char *defn;
  struct nlist *next;
};


#define MAXLINE 1000
#define MAXTOKEN 100

int getline1(char *line, int lim);
int gettoken(char *line, char *token, char **start, char **end);
void print_substring(char *start, char *end);


int main(int argc, char *argv[])
{

  char line[MAXLINE];
  char *start, *end, *prev_end;
  char *nl;
  char token[MAXTOKEN];
  int i;
  struct nlist *np;

  while(getline1(line, MAXLINE) > 0){
    nl = line;
    while(isspace(*nl))
      nl++;
    if(nl[0] == '#'){
      gettoken(nl, token, &start, &end);
      if(strcmp(token, "define") == 0){
        gettoken(end, token, &start, &end);
        char *replacement = end;
        while(isspace(*replacement))
          replacement++;
        for(i = strlen(replacement) - 1;
            i > 0 && isspace(replacement[i]); ++i)
          replacement[i] = '\0';
        install(token, replacement);
      }
      else if(strcmp(token, "undef") == 0){
        gettoken(end, token, &start, &end);
        undef(token);
      }
    }
    else{
      end = line;
      prev_end = end;
      while(gettoken(line, token, &start, &end) > 0){
        print_substring(prev_end, start);
        np = lookup(token);
        if(np == NULL)
          printf("%s", token);
        else
          printf("%s", np->defn);
        prev_end = end;
      }
      printf("%s", end);
    }
  }

  return 0;
}


int getline1(char *line, int lim)
{
  int c, i;
  for(i = 0; i < lim - 1 && (c = getchar()) != EOF && c != '\n'; ++i){
    line[i] = c;
  }
  if(c == '\n'){
    line[i] = '\n';
    i++;
  }
  line[i] = '\0';

  while(c != EOF && c != '\n')
    c = getchar();
  return i;
}

int gettoken(char *line, char *token, char **start, char **end)
{
  while(isspace(*line))
    ++line;
  if(*line == '\0'){
    *token = '\0';
    return 0;
  }

  *start = line;
  if(isalpha(*line) || *line == '_'){
    while(isalpha(*line) || isdigit(*line) || *line == '_')
      *token++ = *line++;
  }
  *token = '\0';
  *end = line;
  return *end - *start;
}

void print_substring(char *start, char *end)
{
  while(start < end){
    putchar(*start);
    ++start;
  }
}




#define HASHSIZE 101

static struct nlist *hashtab[HASHSIZE];

unsigned int hash(char *s)
{
  unsigned hashval;

  for(hashval = 0; *s != '\0'; ++s)
    hashval = *s + 31 * hashval;
  return hashval % HASHSIZE;
}


struct nlist *lookup(char *name)
{
  struct nlist *np;
  for(np = hashtab[hash(name)]; np != NULL; np = np->next){
    if(strcmp(name, np->name) == 0)
      return np;
  }
  return NULL;
}


struct nlist *install(char *name, char *defn)
{
  struct nlist *np;
  unsigned int hashval;
  if((np = lookup(name)) == NULL){
    np = (struct nlist*) malloc(sizeof(struct nlist));
    if(np == NULL || (np->name = strdup(name)) == NULL)
      return NULL;
    hashval = hash(name);
    np->next = hashtab[hashval];
    hashtab[hashval] = np;
  }
  else{
    free(np->defn);
  }
  if((np->defn = strdup(defn)) == NULL)
    return NULL;
  return np;
}

void undef(char *name)
{
  struct nlist *np, **prev;
  unsigned int hashval;
  hashval = hash(name);
  np = hashtab[hashval];
  prev = &hashtab[hashval];
  for(; np != NULL; prev = &(np->next), np = np->next){
    if(strcmp(name, np->name) == 0){
      *prev = np->next;
      free(np->name);
      free(np->defn);
      free(np);
      break;
    }
  }
}
  

  
