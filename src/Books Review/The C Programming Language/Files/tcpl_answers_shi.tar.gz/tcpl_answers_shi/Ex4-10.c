#include <stdio.h>
/*
  An alternate organization uses getline to read an entire input line; this makes getch and ungetch unnecessary. Revise the calculator to use this approach.
 */
int main(int argc, char *argv[])
{
  
  return 0;
}
