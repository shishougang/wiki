#include <stdio.h>
#include <stdlib.h>
#include <limits.h>
#include <string.h>
/*
  In a two's complement number representation, our version of itoa does not handle the largest negative number, that is, the value of n equal to -(2 to the power (wordsize - 1)) . Explain why not. Modify it to print that value correctly regardless of the machine on which it runs.
 */
void reverse(char *s)
{
  int i, j;
  char c;
  i = 0;
  j = strlen(s) - 1;
  for(; i < j; ++i, --j){
    c = s[i];
    s[i] = s[j];
    s[j] = c;
  }
}
  
void itoa(int n, char *s)
{
  int i;
  int sign = n;
  i = 0;
  do{
    s[i++] = abs(n % 10) + '0';
  }while(n /= 10);
  if(sign < 0)
    s[i++] = '-';
  s[i] = '\0';
  reverse(s);
}

int main(int argc, char *argv[])
{
  char buffer[50];
  itoa(INT_MIN, buffer);
  printf("INT_MIN:%d ==> %s\n", INT_MIN, buffer);
  
  return 0;
}
