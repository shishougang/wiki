#include <stdio.h>
int main(void)
{
  printf(" the value of EOF is %d \n", EOF);
  return 0;
}
