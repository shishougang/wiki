#include <stdio.h>

/*
  Modify getop so that it doesn't need to use ungetch. Hint: use an internal static variable.
 */
#define NUMBER 0

int getop(char *s)
{
  int c;
  static int buf = EOF;

  if(buf != EOF && buf != ' ' && buf != '\t' &&
     buf != '.' && !isdigit(buf)){
    c = buf;
    buf = EOF;
    return c;
  }

  if(buf == EOF || buf == ' ' || buf == '\t'){
    while((*s = c = getch()) == ' ' || c == '\t')
      ;
  }
  else{
    *s = c = buf;
  }
  buf = EOF;
  s++;
  *s = '\0';
  if(!isdigit(c) && c != '.')
    return c;    /* not a number */
  if(isdigit(c)){
    while(isdigit(*s = c = getch())){
      s++;
    }
  }
  if(c == '.'){
    while(isdigit(*s = c = getch())){
      s++;
    }
  }
  *(s - 1) = '\0';
  buf = c;
  return NUMBER;
}
  

      

  
int main(int argc, char *argv[])
{
  
  return 0;
}
