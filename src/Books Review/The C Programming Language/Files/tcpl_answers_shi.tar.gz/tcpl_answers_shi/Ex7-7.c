#include <stdio.h>
#include <string.h>
#include <stdlib.h>
/*
  Modify the pattern finding program of Chapter 5 to take its input from a set of named files or, if no files are named as arguments, from the standard input. Should the file name be printed when a matching line is found? 
 */
#define MAXLINE 1000
#define MAXFILES 10

int find(FILE *fp, char *filename, char *pattern, int number, int except);
int getline1(FILE *fp, char s[], int lim);

int main(int argc, char *argv[])
{
  char *files[MAXFILES];
  int i, except, number, found;
  int num_files;
  char *pattern;
  except = number = found = 0;
  i = 1;

  while(i < argc && argv[i][0] == '-'){
    char *pg = argv[i];
    pg++;
    while(*pg != '\0'){
      switch(*pg){
      case 'x':
        except = 1;
        break;
      case 'n':
        number = 1;
        break;
      default:
        printf("find: illegal option %c\n", *pg);
        return EXIT_FAILURE;
      }
      pg++;
    }
    i++;
  }

  if(argc - i < 1){
    fprintf(stderr, "Usage: find -x -n pattern\n");
    return EXIT_FAILURE;
  }
  
  pattern = argv[i];

  i++;
  num_files = 0;
  while(num_files < MAXFILES &&  i < argc){
    files[num_files++] = argv[i];
    i++;
  }

  if(num_files == 0)
    found += find(stdin, NULL, pattern, number, except);
  else{
    for(i = 0; i < num_files; i++){
      FILE *fp = fopen(files[i], "r");
      if(fp == NULL){
        fprintf(stderr, "Can't open %s\n", files[i]);
        return EXIT_FAILURE;
      }
      found += find(fp, files[i], pattern, number, except);
      fclose(fp);
    }
  }
  
  return 0;
}

int find(FILE *fp, char *filename, char *pattern, int number, int except)
{
  long lineno = 0;
  int found = 0;
  char line[MAXLINE];

  while (getline1(fp, line, MAXLINE) > 0) {
    lineno++;
    if ((strstr(line, pattern) != NULL) != except) {
      if (filename != NULL)
        printf("%s:", filename);
      if (number)
        printf("%ld:", lineno);
      printf("%s", line);
      found++;
    }
  }

  return found;
}

int getline1(FILE *fp, char s[], int lim)
{
  int i, c;
  for(i = 0; i < lim-1 && (c=getc(fp)) != EOF && c!='\n'; i++)
    s[i] = c;
  if(c == '\n') {
    s[i] = c;
    ++i;
  }
  s[i] = '\0';
  for ( ; c != EOF && c != '\n'; )
    c = getc(fp);
  return i;
}
