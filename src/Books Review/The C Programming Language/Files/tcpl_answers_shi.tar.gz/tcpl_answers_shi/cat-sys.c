#include <stdio.h>
#include <fcntl.h>
#include <stdlib.h>

#define STDIN_FILENO 0
#define STDOUT_FILENO 1

void filecopy(int, int);
int main(int argc, char *argv[])
{
  int fd;
  int i;

  if(argc == 1)
    filecopy(STDIN_FILENO, STDOUT_FILENO);
  else{
    for(i = 1; i < argc; ++i){
      if((fd = open(argv[i], O_RDONLY, 0)) == -1){
        fprintf(stderr, "%s: cannot open %s\n",
                argv[0], argv[i]);
        exit(1);
      }
      else{
        filecopy(fd, STDOUT_FILENO);
        close(fd);
      }
    }
  }

  return 0;
}
      
  
void filecopy(int infd, int outfd)
{
  int c;
  while(read(infd, &c, sizeof(c)) == 1){
    write(outfd, &c, 1);
  }
}
    
