#include <stdio.h>
#include <stdlib.h>
#include <string.h>
/*
  Write the function itob(n,s,b) that converts the integer n into a base b character representation in the string s . In particular, itob(n,s,16) formats n as a hexadecimal integer in s .
 */
void reverse(char *s)
{
  int i, j;
  char c;
  i = 0;
  j = strlen(s) - 1;
  for(; i < j; ++i, --j){
    c = s[i];
    s[i] = s[j];
    s[j] = c;
  }
}

int itob(int n, char *s, int b)
{
  char number[] = "0123456789ABCDEF";
  int i = 0;
  int sign = n;
  if(b < 2 || b > 16){
    fprintf(stderr, "cannot support the base %d\n", b);
    exit(EXIT_FAILURE);
  }
  
  do{
    s[i++] = number[abs(n % b)];
  } while(n /= b);
  if(sign < 0)
    s[i++] = '-';
  s[i] = '\0';
  reverse(s);
}


int main(int argc, char *argv[])
{
  char buffer[20];
  int i;
  for(i = 2; i <= 16; ++i){
    itob(1023, buffer, i);
    printf("num:%d in base %i is %s\n", 1023, i, buffer);
  }
  return 0;
}
