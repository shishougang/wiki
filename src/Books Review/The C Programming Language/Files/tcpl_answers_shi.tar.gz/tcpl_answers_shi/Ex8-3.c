#include <stdio.h>
#include <string.h>
/*
  Design and write _flushbuf , fflush and fclose .

  see stdio.h and stdio.c
 */

