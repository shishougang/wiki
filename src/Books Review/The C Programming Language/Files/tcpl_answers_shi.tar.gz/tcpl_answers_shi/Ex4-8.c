#include <stdio.h>
/*
  Suppose there will never be more than one character of pushback. Modify getch and ungetch accordingly.
 */
int buf = EOF; /* buffer for ungetch */

int getch(void) /* get a (possibly pushed back) character */
{
  int temp;

  if (buf != EOF) {
    temp = buf;
    buf = EOF;
  } else {
    temp = getchar();
  }
  return temp;                          
}
 
void ungetch(int c) /* push character back on input */
{
  if(buf != EOF)
    printf("ungetch: too many characters\n");
  else       
    buf = c;
}

int main(int argc, char *argv[])
{
  
  return 0;
}
