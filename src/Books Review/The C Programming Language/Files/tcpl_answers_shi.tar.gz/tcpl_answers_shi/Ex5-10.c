#include <stdio.h>
#include <stdlib.h>


#define STACK_SIZE 1024

#define MAXOP 10
#define NUMBER '0'

double stack[STACK_SIZE];
int stackp = 0;

void push(double value)
{
  if(stackp >= STACK_SIZE){
    fprintf(stderr, "stack is full\n");
  }
  stack[stackp++] = value;
}

double pop()
{
  if(stackp == 0){
    fprintf(stderr, "stack is empty\n");
    return EXIT_FAILURE;
  }
  return stack[--stackp];
}

int getop(char *s, char *argp)
{
  int i;

  if(!isdigit(*argp) && *argp != '.')
    return *argp;
  i = 0;
  while(isdigit(s[i++] = *argp++))
    ;
  if(*(argp - 1) == '.'){
    while(isdigit(s[i++] = *argp++))
      ;
  }
  s[i-1] = '\0';
  return NUMBER;
}

  

int main(int argc, char *argv[])
{
  int type;
  double op2;
  char s[MAXOP];

  int i;
  for(i = 1; i < argc; ++i){
    type = getop(s, argv[i]);
    switch(type){
    case NUMBER:
      push(atof(s));
      break;
    case '+':
      push(pop() + pop());
      break;
    case '*':
      push(pop() * pop());
      break;
    case '-':
      op2 = pop();
      push(pop() - op2);
      break;
    case '/':
      op2 = pop();
      if(op2 != 0)
        push(pop() / op2);
      else{
        fprintf(stderr, "error divided by zero.\n");
        return EXIT_FAILURE;
      }
      break;
    default:
      fprintf(stderr, "error unknown command.\n");
      return EXIT_FAILURE;
    }
  }
  printf("result: %0.8g\n", pop());
  return 0;
}
