#include <stdio.h>
/*
  In a two's complement number system, x &= (x-1) deletes the rightmost 1-bit in x . Explain why. Use this observation to write a faster version of bitcount .
*/

int bitcount(unsigned int x)
{
  int bits = 0;
  unsigned int input = x;
  while(x){
    ++bits;
    x &= (x - 1);
  }
  return bits;
}

int main(int argc, char *argv[])
{
  int x = 0xF1;
  int bits = bitcount(x);
  printf("0x%x has %d bits\n", x, bits);
  
  return 0;
}
