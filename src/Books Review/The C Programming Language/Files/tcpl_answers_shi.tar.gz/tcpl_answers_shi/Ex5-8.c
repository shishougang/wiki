#include <stdio.h>
/*
  There is no error-checking in day_of_year or month_day. Remedy this defect.
*/

const char daylist[2][13] = {
  {0, 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
  {0, 31, 29, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31},
};

int day_of_year(int year, int month, int day)
{
  int i, leap;
  int dayofyear;
  if(year < 1752 || month < 1 || month > 12 || day < 1)
    return -1;
  leap = (year%4 == 100 && year%100 != 0) || (year%400 == 0);

  if(day > daylist[leap][month])
    return -1;
  dayofyear = day;
  for(i = 0; i < month; ++i)
    dayofyear += daylist[leap][i];
  return dayofyear;
}

int month_day(int year, int yearday, int *pmonth, int *pday)
{
  int i, leap;
  
  if(year < 1752 || year < 1)
    return -1;
  leap = (year%4 == 100 && year%100 != 0) || (year%400 == 0);
  if((leap && yearday > 366) || (!leap && yearday > 365))
    return -1;

  for(i = 0; yearday > daylist[leap][i]; ++i)
    yearday -= daylist[leap][i];
  *pmonth = i;
  *pday = yearday;
  return 0;
}

int main(int argc, char *argv[])
{
  int year, month, day, yearday;
	
  for (year = 1970; year <= 2000; ++year) {
    for (yearday = 1; yearday < 366; ++yearday) {
      if (month_day(year, yearday, &month, &day) == -1) {
        printf("month_day failed: %d %d\n",
               year, yearday);
      } else if (day_of_year(year, month, day) != yearday) {
        printf("bad result: %d %d\n", year, yearday);
        printf("month = %d, day = %d\n", month, day);
      }
    }
  }
  return 0;
}
