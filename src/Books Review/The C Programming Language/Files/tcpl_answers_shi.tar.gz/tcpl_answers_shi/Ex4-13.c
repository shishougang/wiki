#include <stdio.h>
#include <string.h>
/*
  Write a recursive version of the function reverse(s) , which reverses the string s in place.
 */
void reverse_helper(char *s, int i, int j)
{
  if(i >= j)
    return;
  int temp;
  temp = s[i];
  s[i] = s[j];
  s[j] = temp;
  ++i;
  --j;
  reverse_helper(s, i, j);
}

void reverse(char *s)
{
  int len;
  len = strlen(s);
  reverse_helper(s, 0, len - 1);
}


int main(int argc, char *argv[])
{
  char test[] = "abcdefg";
  printf("origin string: %s\n", test);
  reverse(test);
  printf("reverse string: %s\n", test);
  return 0;
}
