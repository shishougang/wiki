#include <stdio.h>
#include <math.h>
#include <limits.h>
/*
  Adapt the ideas of printd to write a recursive version of itoa ; that is, convert an integer into a string by calling a recursive routine.
 */
char*  itoa_helper(int value, char *s, int base)
{
  char num[] = "0123456789abcdef";
  /* incase -INTMIN overflow */
  int r = value % base;
  int d = value / base;

  if(value < 0){
    if(r < 0)
      r = -r;
    d = -d;
    *s++ = '-';
  }

  if(d > 0)
    s = itoa_helper(d, s, base);
  *s++ = num[r];
  *s = '\0';
  return s;
}
  
void do_itoa(int value, char *s, int base)
{
  itoa_helper(value, s, base);
}
   

int main(int argc, char *argv[])
{

  int array[22] =
    {   0,
        1,
        2,
        9,
        10,
        11,
        16,
        17,
        21,
        312,
        -0,
        -1,
        -2,
        -9,
        -10,
        -11,
        -16,
        -17,
        -21,
        -312,
        INT_MAX,
        INT_MIN,
    };
  char s[1000];
  int i;
  for(i = 0; i < sizeof(array) / sizeof(array[0]); ++i){
    do_itoa(array[i], s, 10);
    printf("%d ==> %s\n", array[i], s);
  }
  return 0;
}
