#include <stdio.h>
#include <stdlib.h>

void filecopy(FILE *, FILE *);
int main(int argc, char *argv[])
{
  FILE *fp;
  int i;

  if(argc == 1)
    filecopy(stdin, stdout);
  else{
    for(i = 1; i < argc; ++i){
      if((fp = fopen(argv[i], "r")) == NULL){
        fprintf(stderr, "%s: cannot open %s\n",
                argv[0], argv[i]);
        exit(1);
      }
      else{
        filecopy(fp, stdout);
        fclose(fp);
      }
    }
  }
  if(ferror(stdout)){
    fprintf(stderr, "%s: error writing stdout\n", argv[0]);
		exit(2);
  }
  return 0;
}
      
  
void filecopy(FILE *infp, FILE *outfp)
{
  int c;
  while((c = getc(infp) != EOF)){
      putc(c, outfp);
  }
}
    
