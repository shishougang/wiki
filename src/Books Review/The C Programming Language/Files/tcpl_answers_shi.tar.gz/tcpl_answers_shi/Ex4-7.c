#include <stdio.h>
#include <
/*
  Write a routine ungets(s) that will push back an entire string onto the input. Should ungets know about buf and bufp , or should it just use ungetch ?
 */
#define BUFSIZE 100

char buf[BUFSIZE];
int bufp = 0;

int getch(void)
{
  return (bufp > 0)? buf[--bufp] : getchar();
}

void ungetch(int c)
{
  if(bufp < BUFSiZE)
    buf[bufp++] = c;
  else
    printf("ungetch: too many letter\n");
}

void ungets(char *s)
{
  int len = strlen(s);
  while(i > 0){
    ungetch(s[--i]);
  }
}

int main(int argc, char *argv[])
{
  
  return 0;
}
