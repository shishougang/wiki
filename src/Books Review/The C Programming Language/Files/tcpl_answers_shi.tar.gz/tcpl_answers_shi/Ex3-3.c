#include <stdio.h>

/*
  Write a function expand(s1,s2) that expands shorthand notations like a-z in the string s1 into the equivalent complete list abc...xyz in s2 . Allow for letters of either case and digits, and be prepared to handle cases like a-b-c and a-z0-9 and -a-z . Arrange that a leading or trailing - is taken literally.
 */
enum{
  DirDown,
  DirUp
};

int expand_pair(char *s, int index, char start, char end, int direction)
{
  int ret_index = index;
  char start_char = start;
  char end_char = end;
  while(start_char < end_char){
    if(direction == DirUp){
      s[ret_index++] = start_char;
      ++start_char;
    }
    else{
      s[ret_index++] = end_char;
      --end_char;
    }
  }
  return ret_index;
}
    
  
void expand(char *s1, char *s2)
{
  int index_s1, index_s2, has_pair;
  index_s1 = index_s2 = 0;
  has_pair = (s1[index_s1] != '\0') && (s1[index_s1+1] != '\0') &&
    (s1[index_s1+2] != '\0');
  while(has_pair){
    printf("index_s1 = %d\n", index_s1);
    if(s1[index_s1 + 1] != '-'){
      s2[index_s2++] = s1[index_s1++];
    }
    else{
      int can_expand;
      char ch1,ch2;
      ch1 = s1[index_s1];
      ch2 = s1[index_s1 + 2];
      can_expand = (ch1 >= 'a') && (ch1 <= 'z') &&
        (ch2 >= 'a') && (ch2 <= 'z');
      can_expand = can_expand || (ch1 >= 'A') && (ch1 <= 'Z') &&
        (ch2 >= 'A') && (ch2 <= 'Z');
      can_expand = can_expand ||  (ch1 >= '0') && (ch1 <= '9') &&
        (ch2 >= '0') && (ch2 <= '9');
      
      if(can_expand){
        if(ch1 <= ch2)
          index_s2 = expand_pair(s2, index_s2, ch1, ch2, DirUp);
        else
          index_s2 = expand_pair(s2, index_s2, ch2, ch1, DirDown);
        index_s1 += 2;
      }
      else{
        s2[index_s2++] = s1[index_s1++];
        s2[index_s2++] = s1[index_s1++];
      }
    }
    has_pair = (s1[index_s1] != '\0') && (s1[index_s1+1] != '\0') &&
      (s1[index_s1+2] != '\0');
  }
  
  while(s1[index_s1]){
    s2[index_s2++] = s1[index_s1++];
  }
  s2[index_s2] = '\0';
    
}

int main(int argc, char *argv[])
{
  char *s[] = { "a-z-", "z-a-", "-1-6-",
                  "a-ee-a", "a-R-L", "1-9-1",
                  "5-5", NULL };
  char result[100];
  int i = 0;
  
  while ( s[i] ) {
    expand(s[i], result);
    printf("Unexpanded: %s\n", s[i]);
    printf("Expanded  : %s\n", result);
    ++i;
  }
  return 0;
}
