#include <stdio.h>
#include <stdlib.h>

/*
  Write a program to check a C program for rudimentary syntax errors like unbalanced parentheses, brackets and braces. Don't forget about quotes, both single and double, escape sequences, and comments. (This program is hard if you do it in full generality.)
 */
#define MAX_STACK 1024
enum {
  CODE,
  COMMENT,
  SINGLE_QUOTE,
  DOUBLE_QUOTE
};

int main(int argc, char *argv[])
{
  int ch;
  int state = CODE;
  size_t line = 1;
  int error = 0;
  int top = 0;
  int stack[MAX_STACK];

  while((ch = getchar()) != EOF){
    if(ch == '\n'){
      line++;
      continue;
    }
    switch(state) {
    case CODE:
      if(ch == '\''){
        state = SINGLE_QUOTE;
      }
      else if(ch == '"'){
        state = DOUBLE_QUOTE;
      }
      else if(ch == '\\'){
        if((ch = getchar()) == '*'){
          state = COMMENT;
        }
        else{
          ungetc(ch, stdin);
        }
      }
      else if(ch == '(' || ch == '[' || ch == '{'){
        if(top < MAX_STACK){
          stack[top] = ch;
          top++;
        }
        else{
          printf("Stack is too small\n");
          return EXIT_FAILURE;
        }
      }
      else if(ch == ')' || ch == ']' || ch == '}'){
        if(top == 0){
          error = 1;
          printf("Line %lu: Closing '%c' found without conterpart.\n", line, ch);
        }
        top--;
        int match = stack[top];
        if((ch == ')' && match != '(') ||
           (ch == ']' && match != '[') ||
           (ch == '}' && match != '{')){
          error = 1;
          printf("Line %lu: Closing '%c' does not match opening '%c'.\n",line, ch, match);
        }
      }
      break;
    case COMMENT:
      if(ch == '*'){
        ch = getchar();
        if(ch == '/'){
          state = CODE;
        }
        else{
          ungetc(ch, stdin);
        }
      }
      break;
    case SINGLE_QUOTE:
      if(ch == '\\'){
        ch = getchar();
      }
      else if(ch == '\''){
        state = CODE;
      }
      break;
    case DOUBLE_QUOTE:
      if(ch == '\\'){
        ch = getchar();
      }
      else if(ch == '\"'){
        state = CODE;
      }
      break;
    }
  }

  if(state == COMMENT){
    printf("Codes end inside the comment.\n");
  }
  else if(state == SINGLE_QUOTE){
    printf("Codes end inside the single quote.\n");
  }
  else if(state == DOUBLE_QUOTE){
    printf("Codes end inside the double quote.\n");
  }

  if(top == 0 && error == 0){
    printf("Codes is OK.\n");
  }
  if(top > 0){
    printf("stack still has something unmatch:\n");
    int i;
    for(i = 0; i < top; i++)
      printf("'%c' \n", stack[i]);
  }
  return 0;
}
