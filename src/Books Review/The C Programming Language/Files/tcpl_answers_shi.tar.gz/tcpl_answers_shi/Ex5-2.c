#include <stdio.h>
/*
  Write getfloat , the floating-point analog of getint . What type does getfloat return as its function value?
 */

#define BUFSIZE 100
char buf[BUFSIZE];
int bufp = 0;

int getch(void)
{
  return bufp > 0? buf[--bufp] : getchar();
}

int ungetch(int c)
{
  if(bufp >= BUFSIZE)
    printf("ungetch: too many characters\n");
  else
    buf[bufp++] = c;
}

int getfloat(float *pn)
{
  int c, sign, power;

  while(isspace(c = getch()))
    ;
  if(!isdigit(c) && (c != EOF) && (c != '+') && (c != '-')){
    ungetch(c);
    return 0;
  }
  sign = c == '+'? 1 : -1;
  if(c == '+' || c == '-'){
    c = getch();
    if(!isdigit(c)){
      ungetch(c);
      return 0;
    }
  }
  for(*pn = 0; isdigit(c); c = getch()){
    *pn = *pn * 10.0 + (c - '0');
  }
  if(c == '.')
    c = getch();
  for(power = 1; isdigit(c); c = getch()){
    power = power * 10;
    *pn += (c - '0') / (float)power;
  }
  *pn *= sign;
  if(c != EOF)
    ungetch(c);
  return c;
}
  
    
      

int main(int argc, char *argv[])
{
  
  return 0;
}
