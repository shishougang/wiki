#include <stdio.h>
#include <ctype.h>
#include <time.h>
/*
  Functions like isupper can be implemented to save space or to save time. Explore both possibilities
 */

int isupper_space(int c)
{
  return c >= 'A' && c <= 'Z';
}

const static int time_tab[256] = {
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1,
	1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
};

int isupper_time(int c)
{
  return c < 256 && time_tab[c];
}

#define COUNT 10000000L
struct Test_Func{
  char *name;
  int (*func)(int);
};
int main(int argc, char *argv[])
{
  struct Test_Func tries[] = {
    "isupper_space", isupper_space,
    "isupper_time", isupper_time,
    "library isupper", isupper
  };

  int i;
  long count;
  clock_t start, end;

  for (i = 0; i < sizeof(tries) / sizeof(*tries); i++) {
    start = clock();
    for (count = COUNT; count > 0; count--)
      tries[i].func('A');
    end = clock();
    printf("%s: %f s\n", tries[i].name,
           (double) (end - start) / CLOCKS_PER_SEC);
  }
  return 0;
}
