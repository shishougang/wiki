#include <stdio.h>
#include <math.h>
/*
Given the basic framework, it's straightforward to extend the calculator. Add the modulus ( % ) operator and provisions for negative numbers.
 */
int main(int argc, char *argv[])
{
  int type;
  double op1, op2;
  char s[MAXOP];

  while((type = Getop(s)) != EOF){
    switch(type){
    case '%':
      op2 = pop();
      op1 = pop();
      if(op2)
        push(fmod(op1, op2));
      else
        fprintf(stderr, "Divided by zero\n");
    }
  }

        
  return 0;
}
