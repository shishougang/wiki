#include <stdio.h>
#include <string.h>

/*
  Write the function strend(s,t) , which returns 1 if the string t occurs at the end of the string s , and zero otherwise.
 */
int strend(char *s, char *t)
{
  int ret = 0;
  int s_len, t_len;
  s_len = strlen(s);
  t_len = strlen(t);
  if(s_len < t_len)
    return ret;
  s += s_len - t_len;
  while(*s == *t){
    if(*s == '\0'){
      ret = 1;
      break;
    }
    ++s;
    ++t;
  }
  return ret;
}
    


int main(int argc, char *argv[])
{
  
  return 0;
}
