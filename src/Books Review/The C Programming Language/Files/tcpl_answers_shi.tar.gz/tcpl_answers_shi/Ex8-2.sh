

#  Rewrite fopen and _fillbuf with fields instead of explicit bit operations. Compare code size and execution speed.

gcc -c -o stdio.o stdio.c
gcc -o test-fields-f -I. -g -UBITFIELDS test-fields.c stdio.o
cat ./stdio.c | ./test-fields-f

gcc -c -o stdio-field.o stdio-field.c
gcc -o test-fields-b -I. -g -DBITFIELDS test-fields.c stdio-field.o
cat ./stdio.c | ./test-fields-b
