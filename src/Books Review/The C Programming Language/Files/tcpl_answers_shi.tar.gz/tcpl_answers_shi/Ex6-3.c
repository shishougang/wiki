#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/*
  Write a cross-referencer that prints a list of all words in a document, and, for each word, a list of the line numbers on which it occurs. Remove noise words like "the", "and," and so on.
 */
#define MAXWORD 100

char **binsearch(char *key, char *array[], int n);
struct node *node_add(struct node *node, char *word, int n);
void treeprint(struct node* n);
int getword(char *word, int lim);

char *noise[] = {
  "a", "and", "of", "the"
};

struct line_node{
  int num;
  struct line_node *next;
};

struct node{
  char *word;
  struct line_node *line;
  struct node *left;
  struct node *right;
};
  

int main(int argc, char *argv[])
{
  struct node *root;
  int line;
  char word[MAXWORD];

  root = NULL;
  line = 1;
  while(1){
    line += getword(word, MAXWORD);
    printf("line = %d\n", line);
    if(word[0] == '\0')
      break;
    if(binsearch(word, noise, sizeof(noise) / sizeof(noise[0])) == NULL)
      root = node_add(root, word, line);
  }
  treeprint(root);

  return 0;
}

char **binsearch(char *key, char *array[], int n)
{
  int low, high, mid;
  int cond;
  low = 0;
  high = n - 1;
  while(low < high){
    mid = (low + high) / 2;
    cond = strcmp(key, array[mid]);
    if(cond < 0)
      high = mid - 1;
    else if(cond > 0)
      low = mid + 1;
    else
      return array + mid;
  }
  return NULL;
}

struct node *node_alloc(void)
{
  return (struct node*) malloc(sizeof(struct node));
}

struct line_node *line_node_alloc(void)
{
  return (struct line_node*) malloc(sizeof(struct line_node));
}

struct node *node_add(struct node *node, char *word, int n)
{
  int cond;
  if(node == NULL){
    node =  node_alloc();
    node->line = line_node_alloc();
    node->word = strdup(word);
    node->left = node->right = NULL;
    node->line->num = n;
    node->line->next = NULL;
  }
  else if((cond = strcmp(node->word, word)) == 0){
    struct line_node *l;
    l = node->line;
    while(l->next != NULL)
      l = l->next;
    l->next = line_node_alloc();
    l->next->num = n;
  }
  else if(cond < 0){
    node->right = node_add(node->right, word, n);
  }
  else{
    node->left = node_add(node->left, word, n);
  }
  return node;
}

void treeprint(struct node* n)
{
  if(n != NULL){
    treeprint(n->left);
    
    printf("%s: ", n->word);
    struct line_node *l;
    l = n->line;
    while(l != NULL){
      printf("%d ", l->num);
      l = l->next;
    }
    printf("\n");

    treeprint(n->right);
  }
}

int getch(void);
void ungetch(int c);
int getword(char *word, int lim)
{
  int line, c;
  char *w;

  line = 0;
  while(!isalpha(c = getch()) && c != EOF){
    if(c == '\n')
      ++line;
  }
  w = word;

  while(lim-- > 0 && isalpha(c)){
    *w++ = c;
    c = getch();
  }
  *w = '\0';
  return line;
}


#define BUFSIZE 100

char buf[BUFSIZE];	/* buffer for ungetch */
int bufp = 0;		/* next free position in buf */

int getch(void) /* get a (possibly pushed back) character */
{
	return (bufp > 0) ? buf[--bufp] : getchar();
}

void ungetch(int c)	/* push character back on input */
{
	if (bufp >= BUFSIZE)
		printf("ungetch: too many characters\n");
	else
		buf[bufp++] = c;
}
