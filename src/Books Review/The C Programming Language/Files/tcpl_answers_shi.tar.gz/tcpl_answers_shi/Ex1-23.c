#include <stdio.h>
/*
  Write a program to remove all comments from a C program. Don't forget to handle quoted strings and character constants properly. C comments do not nest.
 */
#define READFILENAME "test.c"
#define WRITEFILENAME "testout.c"

int doublequote_process(FILE *fpRead, FILE *fpWrite)
{
  unsigned int c;
  do{
    c = getc(fpRead);
    if(c == '\\'){
      fputc(c, fpWrite);
      c = getc(fpRead);
      if(c == EOF)
        return 1;
      else
        fputc(c, fpWrite);
    }
    else if(c == '"'){
      fputc(c, fpWrite);
      return 0;
    }
    else{
      fputc(c, fpWrite);
    }
  } while(c != EOF);
  return 1;
}

int singlequote_process(FILE *fpRead, FILE *fpWrite)
{
  unsigned int c;
  do{
    c = getc(fpRead);
    if(c == '\\'){
      fputc(c, fpWrite);
      c = getc(fpRead);
      if(c == EOF)
        return 1;
      else
        fputc(c, fpWrite);
    }
    else if(c == '\''){
      fputc(c, fpWrite);
      return 0;
    }
    else{
      fputc(c, fpWrite);
    }
  } while(c != EOF);
  return 1;
}

int comment_process(FILE *fpRead)
{
  unsigned int c1, c2;
  c2 = getc(fpRead);
  do{
    c1 = c2;
    printf("%c", c1);
    if(c1 == EOF)
      return 1;
    c2 = getc(fpRead);
    if((c1 == '*') && (c2 == '/'))
      return 0;
  } while(c2 != EOF);
  return 1;
}
    
      

int main(int argc, char *argv[])
{
  FILE *fpRead, *fpWrite;
  fpRead = fopen(READFILENAME, "r");
  if(fpRead == NULL)
    perror("Error opening");
  
  fpWrite = fopen(WRITEFILENAME, "w");
  if(fpWrite == NULL){
    fclose(fpRead);
    perror("Error opening");
  }

  unsigned int c;
  int EndFile = 0;
  do{
    c = getc(fpRead);
    EndFile = 0;
    if(c == '"'){
      fputc(c, fpWrite);
      EndFile = doublequote_process(fpRead, fpWrite);
    }
    else if(c == '\''){
      fputc(c, fpWrite);
      EndFile = singlequote_process(fpRead, fpWrite);
    }
    else if(c == '/'){
      c = getc(fpRead);
      if(c == '*'){
        EndFile = comment_process(fpRead);
      }
      else{
        fputc('/', fpWrite);
        fputc(c, fpWrite);
      }
    }
    else{
      fputc(c, fpWrite);
    }
    if(EndFile)
      break;
  } while(c != EOF);

  fclose(fpRead);
  fclose(fpWrite);
  return 0;
}
