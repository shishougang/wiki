#include <stdio.h>
/*
  Write the function htoi(s) , which converts a string of hexadecimal digits (including an optional 0x or 0X) into its equivalent integer value. The allowable digits are 0 through 9, a through f, and A through F .
  
 */

int hex_to_int(char c)
{
  int ret = 0;
  char num[]="aAbBcCdDeEfF";
  int i;
  for(i = 0; num[i] != '\0'; ++i){
    if(num[i] == c){
      ret = 10 + i / 2;
      break;
    }
  }
  return ret;
}

int htoi(char *s)
{
  int decimal_value = 0;
  int i = 0;
  while(s[i] != '\0'){
    int begin_x = (s[i] == '0') && (s[i+1] == 'x' || s[i + 1] == 'X');
    if(begin_x){
      i += 2;
      continue;
    }
    if(s[i]  >= '0' && s[i] <= '9'){
      decimal_value = decimal_value*16 + (s[i] - '0');
    }
    else{
      int valid_num = 0;
      valid_num = hex_to_int(s[i]);
      if(!valid_num){
        decimal_value = 0;
        break;
      }
      decimal_value = decimal_value*16 + valid_num;
    }
    i++;
  }
  return decimal_value;
}
    

int main(int argc, char *argv[])
{
  char *endp = NULL;
  char *test[] =
  {
    "F00",
    "bar",
    "0100",
    "0x1",
    "0XA",
    "0X0C0BE",
    "abcdef",
    "123456",
    "0x123456",
    "deadbeef",
    "zog_c"
  };

  unsigned int result;
  unsigned int check;

  size_t numtests = sizeof test / sizeof test[0];

  size_t thistest;

  for(thistest = 0; thistest < numtests; thistest++)
  {
    result = htoi(test[thistest]);
    check = (unsigned int)strtoul(test[thistest], &endp, 16);

    if((*endp != '\0' && result == 0) || result == check)
    {
      printf("Testing %s. Correct. %u\n", test[thistest], result);
    }
    else
    {
      printf("Testing %s. Incorrect. %u\n", test[thistest], result);
    }
  }

  return 0;
}
