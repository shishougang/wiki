#include <stdio.h>

/*
  Write the function strrindex(s,t) , which returns the position of the rightmost occurrence of t in s , or -1 if there is none.
 */
int strrindex(char *s, char t)
{
  int find_index = -1;
  int i = 0;
  while(s[i] != '\0'){
    if(s[i] == t)
      find_index = i;
    ++i;
  }
  return find_index;
}
  
int main(int argc, char *argv[])
{
  
  return 0;
}
