#include <stdio.h>
/*  for(i=0; i<lim-1 && (c=getchar()) != '\n' && c != EOF; ++i)
    s[i] = c;


Write a loop equivalent to the for loop above without using && or || .
*/
#define MAX_STRING_LEN 500
int main(int argc, char *argv[])
{
  int i;
  int lim = MAX_STRING_LEN;
  int c;
  char s[MAX_STRING_LEN];
  for(i = 0; i < lim - 1; ++i){
    c = getchar();
    if(c == EOF)
      break;
    else if(c == '\n')
      break;
    s[i] = c;
  }
  s[i] = '\0';
 
  return 0;
}
