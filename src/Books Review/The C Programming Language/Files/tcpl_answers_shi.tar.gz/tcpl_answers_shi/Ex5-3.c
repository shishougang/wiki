#include <stdio.h>

/*
  Write a pointer version of the function strcat that we showed in Chapter 2: strcat(s,t) copies the string t to the end of s .
*/

void strcat(char *s, char *t)
{
  char* dst = s;
  char* src = t;
  while(*dst != '\0')
    dst++;
  while((*s = *t) != '\0'){
    ++s;
    ++t;
  }
}
   

int main(int argc, char *argv[])
{
  
  return 0;
}
