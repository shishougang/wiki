#include <stdio.h>
#include <time.h>
/*
  Our binary search makes two tests inside the loop, when one would suffice (at the price of more tests outside). Write a version with only one test inside the loop and measure the difference in run-time.
*/
int binsearch(int x, int v[], int n)
{
  int low, mid, high;
  low  = 0;
  high = n - 1;
  while(low <= high){
    mid = (low + high) / 2;
    if(x < v[mid])
      high = mid - 1;
    else if(x > v[mid])
      low = mid + 1;
    else
      return mid;
  }
  return -1;
}

int binsearch_test_while(int x, int v[], int n)
{
  int low, mid, high;
  low = 0;
  high = n - 1;
  mid = (low + high) / 2;
  while(low <= high && x != v[mid]){
    if(x < v[mid])
      high = mid - 1;
    else
      low = mid + 1;
    mid = (low + high) / 2;
  }
  if(x == v[mid])
    return mid;
  else
    return -1;
}

int binsearch_one_test(int x, int v[], int n)
{
  int low, mid, high;
  low = 0;
  high = n - 1;
  while(low < high){
    mid = (low + high) / 2;
    if(x <= v[mid])
      high = mid;
    else
      low = mid + 1;
  }
  return (x == v[high])? high : -1;
}
  
#define MAX_ELEMENT 300000
int main(int argc, char *argv[])
{
  int testarray[MAX_ELEMENT];
  int index;
  int i;
  int findx;
  clock_t clock_start, clock_taken;

  for(i = 0; i < MAX_ELEMENT; ++i){
    testarray[i] = i;
  }

  clock_start = clock();
  for(findx = 0; findx < MAX_ELEMENT; ++findx){
    index = binsearch(findx, testarray, MAX_ELEMENT);
  }
  clock_taken = clock() - clock_start;
  printf("binsearch algo1 take clocks: %lu clocks(%f seconds)\n",
         (unsigned long)clock_taken, ((float)clock_taken) / CLOCKS_PER_SEC);

  clock_start = clock();
  for(findx = 0; findx < MAX_ELEMENT; ++findx){
    index = binsearch_test_while(findx, testarray, MAX_ELEMENT);
  }
  clock_taken = clock() - clock_start;
  printf("binsearch algo2 take clocks: %lu clocks(%f seconds)\n",
         (unsigned long)clock_taken, ((float)clock_taken) / CLOCKS_PER_SEC);

  clock_start = clock();
  for(findx = 0; findx < MAX_ELEMENT; ++findx){
    index = binsearch_one_test(findx, testarray, MAX_ELEMENT);
  }
  clock_taken = clock() - clock_start;
  printf("binsearch algo3 take clocks: %lu clocks(%f seconds)\n",
         (unsigned long)clock_taken, ((float)clock_taken) / CLOCKS_PER_SEC);
  
  
  return 0;
}
