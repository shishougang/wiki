#include <stdio.h>
#define MAXLEN 1001
#define TABSPACE 4

int getline1(char s[], int lim)
{
  int c, i;
  for(i = 0; (i < lim -1 ) && ((c = getchar()) != EOF) && c != '\n'; i++){
    s[i] = c;
  }
  if(c == '\n'){
    s[i] = c;
    i++;
  }
  s[i] = '\0';
  return i;
}
int main(int argc, char *argv[])
{
  int spacecount = 0;
  int nline;
  char str[MAXLEN];
  int i, j, k;
  while((nline = getline1(str, MAXLEN)) > 0){
    for(i = 0; i < nline; i++){
      if(str[i] == ' ')
        spacecount++;
      else
        spacecount = 0;

      if(spacecount == TABSPACE){
        j = TABSPACE - 1;
        i -= j;
        nline -= j;
        str[i] = '\t';

        for(k = i + 1; k < nline; k++)
          str[k] = str[k + 3];
        str[k] = '\0';

        spacecount = 0;
      }
    }
    printf("%s", str);
  }
  return 0;
}
