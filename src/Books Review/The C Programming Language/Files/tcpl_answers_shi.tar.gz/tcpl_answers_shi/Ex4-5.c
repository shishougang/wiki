#include <stdio.h>

/*
  Add access to library functions like sin , exp , and pow . See <math.h> in Appendix B, Section 4.
 */
int main(int argc, char *argv[])
{
  
  return 0;
}
