#include <iostream>
#include "matrix3.h"

using namespace std;

int main()
{
    matrix<int>  m(10,20);

    m[2][3] = 1;
    cout << m[2][3] << endl;

    return 0;
}


