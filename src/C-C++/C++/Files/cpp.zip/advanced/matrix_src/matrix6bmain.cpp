#include <iostream>
#include "matrix6.h"

using namespace std;

int main()
{
    matrix<int> *p = new matrix<int>(10,20);
    matrix<int> &r = *p;

    matrix<int>::proxy_matrix pm = r[2];
    
    delete p;

    cout <<pm[3] << endl;

    return 0;
}


