
/*
 *  sc.cpp
 *  (C) gsd 2001
 */                                                                              

// #include <sstream>   // for standard
#include <strstream>    // for g++                                              

#include "sc.h"

using namespace std;

CSessionCon::~CSessionCon() { }
void CSessionCon::assign( long dbid)
{
    m_dbid = dbid; 
}
void CSessionCon::receive( string message)
{
//    istringstream is( message);	// for standard
    istrstream  is(message.c_str());    // for g++
    long    oper_id;
    string  command;
    string  uid;
    
    if ( is >> oper_id >> command >> uid )
    {
        if ( "CALL" == command )
	{
            send( oper_id, "SC: call initiated: " + uid); 
        }
        else if ( "DISC" == command )
        {
            send( oper_id, "SC: active call cleared" + uid);
        }
    }
    else
        send( oper_id, "SC: bad parameters");
}

#ifdef TEST

bool CSessionCon::regist( std::string u, long n)
{
    cout << "Registering " << u << ", " << n << endl;
    return db->store( "terminal", u, CTerminal( u, n));
}
bool CSessionCon::unregist( std::string u) // should check: is it in use?
{
    cout << "Unregistering " << u << endl;                           
    return true;
}
bool CSessionCon::call( std::string u1, std::string u2)
{
    cout << "Calling " << u1 << ", " << u2 << endl; // it might be used
    return true;
}
bool CSessionCon::discon( std::string u)
{
    cout << "Disconnecting " << u << endl;
    return true;
}
bool CSessionCon::lcalls()
{
    cout << "Listing active calls " << endl;
    return true;
}
bool CSessionCon::lregs()
{
    cout << "Listing registered terminals " << endl; 
    return true;
}

#endif
