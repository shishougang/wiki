
/*
 *  db.h
 *  (C) gsd 2001
 */                                                                             

#ifndef DATABASE_H
#define DATABASE_H

#include <string>
#include <iostream>

#include "mesbus.h"

class CDataBase : public CMessageBus
{
public:
	CDataBase( std::string name = "local.db");
private:
    void    receive( long sender, std::string);
    bool    find( std::string uid, std::streampos &pos);
    bool    store( std::string uid, std::string s);
    bool    remove( std::string uid);
    bool    retrieve( std::string uid, std::string &s);

    std::filebuf fb;	    // the file buffer
    std::istream ifile;  // the input stream over fb
    std::ostream ofile;  // the output stream over fb  
};

#endif /* DATABASE_H */
