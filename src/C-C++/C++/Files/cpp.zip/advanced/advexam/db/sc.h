
/*
 *  sc.h
 *  (C) gsd 2001
 */                                                                             

#ifndef SESSIONCON_H
#define SESSIONCON_H


#include "mesbus.h"

class CSessionCon : public CMessageBus
{
public:
	~CSessionCon();
    void    assign( long dbid);
private:
    void    receive( std::string message);

    long    m_dbid;
};

#endif /* SESSIONCON_H */
