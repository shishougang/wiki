
#include <iostream>
#include <fstream>

#include "db.h"
#include "sc.h"
#include "oper.h"

using namespace std;

int main( int argc, char *argv[])
{
    int retval = 0;

    CDataBase   db;
    CSessionCon sc;

    sc.assign( db.getid() );

    if ( argc < 2 )
    {
	COperMaint oper;
	oper.assign( sc.getid(), db.getid() );
	oper.doit();
    }
    else
	for ( int i = 1; i < argc; ++i )
	{
            ifstream inp( argv[i]);

	    if ( !inp )
	    {
	        cerr << "Can't open file " << argv[i] << " for read" << endl;
	        ++retval;
	    }
	    else
	    {
                COperMaint oper( inp);
		oper.assign( sc.getid(), db.getid() );
		oper.doit();
	    }
        }
    return retval;
}
