
/*
 *  mesbus.cpp
 *  (C) gsd 2001
 */  
        
#ifndef MESSAGEBUS_H
#define MESSAGEBUS_H

/*
    The terminals, the session controller, the database are acting
    like they were inot in the same address space, so they can 
    communicate only via the MessageBus layer. (That is like they
    would use CORBA, or others.)
 */

#include <string>
#include <map>

class CMessageBus
{
public:
	     CMessageBus();	// init id, and register to router
    virtual ~CMessageBus();	// deregister from router

    static  void printrouter();	// in the first version
	    long getid() const { return m_busid; }
     std::string getsid() const;

            bool send( long target_id, std::string message);
    virtual void receive( long sender_id, std::string message);
private:
    const  long m_busid;	// the unique id of a comm. device - like IP addr.

    static long sm_busid;  // the sequencer
    static std::map<long, CMessageBus*> sm_router;  // the router
};


#endif /* MESSAGEBUS_H */


