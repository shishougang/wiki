
/*
 *  oper.h
 *  (C) gsd 2001
 */                                                                             

#ifndef OPERMAINT_H
#define OPERMAINT_H

#include <iostream>
#include <map>
#include <string>

#include "mesbus.h"

class COperMaint : CMessageBus
{
public:
    COperMaint( std::istream& is = std::cin, std::ostream& os = std::cout);
    void    assign( long scid, long dbid);
    void    doit();
private:
    void    init();
    bool    parse( std::string line);
    void    execute();
    void    uexit();

    void    receive( long sender, std::string message);  // override CMessageBus::receive()

    long    m_scid;	// bus id of session controller
    long    m_dbid;	// bus id of database 
    
    std::istream&   m_input_source;   // input stream
    std::ostream&   m_output_source;  // output stream

    std::string	    m_sid;	    // my id in string format
    std::string	    m_arguments;    // current argument line

    std::map<std::string, int>	m_commands;
//  std::map<std::string, int, less<std::string>> m_commands;
    std::map<std::string, int>::const_iterator	  m_it_current;

    bool    m_is_exit;
};

#endif /* OPERMAINT_H */
