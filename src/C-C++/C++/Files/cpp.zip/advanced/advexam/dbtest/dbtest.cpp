#include <string>
#include <iostream>
#include <fstream>

using namespace std;

int main()
{
    filebuf fb;
    istream ifile(&fb);
    ostream ofile(&fb);

    fb.open( "local.db", ios::in | ios::out);

    if ( ifile )
    {
	    cout << "file opened" << endl;

	    string s; 

	/* class streambuf  -> controlling input/output for a file
	 * six pointers:
	 *	beg, curr, end  of input and output stream
	 * streamoff   ->	fseek, ftell   represented as long
	 * streampos   ->  describing position in the file (fpos_t in <stdio.h>)
	 * streampos += streamoff
         */

	streampos spos  = fb.pubseekoff(0, ios::beg); 
	streampos sprev = spos;
	while ( getline( ifile, s) )
	{
//	    cout << sprev << " : ";
	    cout << spos << " : ";
	    cout << s << endl;
	    sprev = spos;
        spos += 1+s.size();
//	    spos = fb.pubseekoff(0, ios::cur);
	}
	long where_to_pos = 17;
	fb.pubseekoff(where_to_pos, ios::beg);
        ifile.clear();
	if ( getline( ifile, s) )
	{
	    cout << where_to_pos << " : ";
	    cout << s << endl;
	}
	else
	    cerr << "last line" << endl;
	
    }
    else
	cout << "error" << endl;
    return 0;    
}
