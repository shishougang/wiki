
/*
 *  db.h
 *  (C) gsd 2001
 */                                                                             

#ifndef DATABASE_H
#define DATABASE_H

#include <string>
#include <iostream>

#include "mesbus.h"

class CDataBase : public CMessageBus
{
public:
	CDataBase( std::string name = "local.db");
private:
    void    receive( long sender, std::string);
};

#endif /* DATABASE_H */
