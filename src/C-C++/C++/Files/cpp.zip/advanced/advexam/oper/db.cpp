
/*
 *  db.cpp
 *  (C) gsd 2001
 */

#include <sstream>      // for standard
//#include <strstream>    // for g++
#include <string>
#include <iostream>
#include <fstream>
#include <cstdlib>

#include "db.h"

using namespace std;

CDataBase::CDataBase( string )
{
}
void CDataBase::receive( long sender, string message)
{
    istringstream is( message);	// for standard
//    istrstream  is(message.c_str());	// for g++
    string  command;    

    if ( is >> command )
    {
	send( sender, command+" OK");
    }
    else
    {
	send( sender, "Sorry?");
    }
}
