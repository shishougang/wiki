
#include <iostream>
#include <string>

#include "mesbus.h"

int main()
{
    CMessageBus dev1, dev2, dev3;

    CMessageBus::printrouter();
    dev1.send(dev2.getid(),"first message");
    dev2.send(dev3.getid(),"second message");
    dev3.send(dev1.getid(),"third message");

    return 0;
}
