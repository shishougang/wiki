#ifndef DATE_H
#define DATE_H

#include <iostream>

class date
{
public:
    enum fmt { us, de, hu, ansi };
    friend std::ostream& operator<<( std::ostream& os, date::fmt f);

        date( int y=1900, int m=1, int d=1) { set( y, m, d); }
        date( const char *s);
    date&  set_year( int y)  { year = y; return *this; }
    date&  set_month( int m) { month = m; return *this; }
    date&  set_day( int d)   { day = d; return *this; }
    int  get_year()  const { return year; }
    int  get_month() const { return month; }
    int  get_day()   const { return day; }

    date& next();
    date& add( int n);
    date& operator++()       { return next(); }
    date  operator++(int)    { date curr(*this); next(); return curr; };
    date& operator+=( int n) { return add(n); }

    void read( std::istream& is);
    void print( std::ostream& os) const;

private:
    void set( int y, int m, int d) 
    { 
        /* some check here */
        year = y; month = m; day = d;
    }

    int year;
    int month;
    int day;

    static fmt next_fmt;
};

bool operator<( date d1, date d2);
inline bool operator==( date d1, date d2) { return !(d1<d2 || d2<d1); }
inline bool operator!=( date d1, date d2) { return d1<d2 || d2<d1; }
inline bool operator<=( date d1, date d2) { return !(d2<d1); }
inline bool operator>=( date d1, date d2) { return !(d1<d2); }
inline bool operator>( date d1, date d2)  { return d2<d1; }

std::istream& operator>>( std::istream& is, date& d);
std::ostream& operator<<( std::ostream& os, const date &d);

std::ostream& operator<<( std::ostream& os, date::fmt f);

#endif /* DATE_H */

