#include <iostream>
#include "date1.h"

using namespace std;

int main()
{
    cout << date::us;
    date d(2001, 10, 19);
    cout << d << endl;
    cout << date::hu << d << endl;
    cout << date::de << d << endl;
    cout << date::ansi << d << endl;
    return 0;
}