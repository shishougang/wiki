

P�lda 8
=========

template <class Ch, class Tr = char_traits<Ch> >
class std::basic_ostream : virtual public basic_ios<Ch,Tr> {
public:
	virtual ~basic_ostream();
	// ...
};



P�lda 9
=========

typedef basic_ostream<char> ostream;
typedef basic_ostream<wchar_t> wostream;



P�lda 10
=========

template <class Ch, class Tr = char_traits<Ch> >
class std::basic_ios : public ios_base {
public:
	typedef Ch char_type;
	typedef Tr traits_type;
	typedef typename Tr::int_type int_type;	// type of integer value of character
	typedef typename Tr::pos_type pos_type;	// position in buffer
	typedef typename Tr::off_type off_type;	// offset in buffer
};



P�lda 11
=========

ostream cout;		// standard output stream of char
ostream cerr;		// standard unbuffered output stream for error messages
ostream clog;		// standard output stream for error messages

wostream wcout;	// wide stream corresponding to cout
wostream wcerr;	// wide stream corresponding to cerr
wostream wclog;	// wide stream corresponding to clog



P�lda 12
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_ostream : virtual public basic_ios<Ch,Tr> {
public:
	// ...

	basic_ostream& operator<<(short n);
	basic_ostream& operator<<(int n);
	basic_ostream& operator<<(long n);

	basic_ostream& operator<<(unsigned short n);
	basic_ostream& operator<<(unsigned int n);
	basic_ostream& operator<<(unsigned long n);

	basic_ostream& operator<<(float f);
	basic_ostream& operator<<(double f);
	basic_ostream& operator<<(long double f);

	basic_ostream& operator<<(bool n);
	basic_ostream& operator<<(const void* p);		// write pointer value

	basic_ostream& put(Ch c);	// write c
	basic_ostream& write(const Ch* p, streamsize n);	// p[0]..p[n-1]

	// ...
};



P�lda 13
=========

cerr << "x = " << x;

(cerr.operator<<("x = ")).operator<<(x);



template<class Ch, class Tr>
	basic_ostream<Ch,Tr>& operator<<(basic_ostream<Ch,Tr>&, Ch);
template<class Ch, class Tr>
	basic_ostream<Ch,Tr>& operator<<(basic_ostream<Ch,Tr>&, char);
template<class Tr>
	basic_ostream<char,Tr>& operator<<(basic_ostream<char,Tr>&, char);
template<class Tr>
	basic_ostream<char,Tr>& operator<<(basic_ostream<char,Tr>&, signed char);
template<class Tr>
	basic_ostream<char,Tr>& operator<<(basic_ostream<char,Tr>&, unsigned char);



template<class Ch, class Tr>
	basic_ostream<Ch,Tr>& operator<<(basic_ostream<Ch,Tr>&, const Ch*);
template<class Ch, class Tr>
	basic_ostream<Ch,Tr>& operator<<(basic_ostream<Ch,Tr>&, const char*);
template<class Tr>
	basic_ostream<char,Tr>& operator<<(basic_ostream<char,Tr>&, const char*);
template<class Tr>
	basic_ostream<char,Tr>& operator<<(basic_ostream<char,Tr>&, const signed char*);
template<class Tr>
	basic_ostream<char,Tr>& operator<<(basic_ostream<char,Tr>&, const unsigned char*);




P�lda 30
=========

template <class Ch, class Tr = char_traits<Ch> >
class std::basic_istream : virtual public basic_ios<Ch,Tr> {
public:
	virtual ~basic_istream();

	// ...
};



P�lda 31
=========

typedef basic_istream<char> istream;
typedef basic_istream<wchar_t> wistream;

istream cin;	// standard input stream of char
wistream wcin;	// standard input stream of wchar_t



P�lda 32
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_istream : virtual public basic_ios<Ch,Tr> {
public:
	// ...
	// formatted input:

	basic_istream& operator>>(short& n);		// read into n
	basic_istream& operator>>(int& n);
	basic_istream& operator>>(long& n);

	basic_istream& operator>>(unsigned short& u);	// read into u
	basic_istream& operator>>(unsigned int& u);
	basic_istream& operator>>(unsigned long& u);

	basic_istream& operator>>(float& f);			// read into f
	basic_istream& operator>>(double& f);
	basic_istream& operator>>(long double& f);

	basic_istream& operator>>(bool& b);			// read into b
	basic_istream& operator>>(void*& p);		// read pointer value into p

	// ...
};



P�lda 33
=========

istream& istream::operator>>(T& tvar)	// T is a type for which istream::operator>> is declared
{
	// skip whitespace, then somehow read a T into `tvar'
	return *this;
}



P�lda 34
=========

int read_ints(vector<int>& v)	// fill v, return number of ints read
{
	int i = 0;
	while (i<v.size() && cin>>v[i]) i++;
	return i;
}


P�lda 41
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_ios : public ios_base {
public:
	// ...

	bool good() const;	// next operation might succeed
	bool eof() const;	// end of input seen
	bool fail() const;	// next operation will fail
	bool bad() const;	// stream is corrupted

	iostate rdstate() const;					// get io state flags
	void clear(iostate f = goodbit);				// set io state flags
	void setstate(iostate f) { clear(rdstate()|f); }	// add f to io state flags

	operator void*() const;					// nonzero if !fail()
	bool operator!() const { return fail(); }

	// ...
};



P�lda 42
=========

class ios_base {
public:
	// ...

	typedef implementation_defined2 iostate;
	static const iostate badbit,	// stream is corrupted
					eofbit,	    // end-of-file seen
					failbit,	// next operation will fail
					goodbit;	// goodbit==0

	// ...
};



P�lda 43
=========

void f()
{
	ios_base::iostate s = cin.rdstate();	// returns a set of iostate bits

	if (s & ios_base::badbit) {
		// cin characters possibly lost
	}
	// ...
	cin.setstate(ios_base::failbit);
	// ...
}



P�lda 44
=========

template<class T> void iocopy(istream& is, ostream& os)
{
	T buf;
	while (is>>buf) os << buf << '\n';
}



P�lda 45
=========

void f(istream& i1, istream& i2, istream& i3, istream& i4)
{
	iocopy<complex>(i1,cout);	// copy complex numbers
	iocopy<double>(i2,cout);	// copy doubles
	iocopy<char>(i3,cout);		// copy chars
	iocopy<string>(i4,cout);	// copy whitespace-separated words
}



P�lda 46
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_istream : virtual public basic_ios<Ch,Tr> {
public:
	// ...
	// unformatted input:

	streamsize gcount() const;	// number of char read by last get()

	int_type get();				// read one Ch (or Tr::eof())

	basic_istream& get(Ch& c);	// read one Ch into c

	basic_istream& get(Ch* p, streamsize n);		// newline is terminator
	basic_istream& get(Ch* p, streamsize n, Ch term);

	basic_istream& getline(Ch* p, streamsize n);	// newline is terminator
	basic_istream& getline(Ch* p, streamsize n, Ch term);

	basic_istream& ignore(streamsize n = 1, int_type t = Tr::eof());
	basic_istream& read(Ch* p, streamsize n);	// read at most n char
	// ...
};



P�lda 47
=========

int main()
{
	char c;
	while(cin.get(c)) cout.put(c);
}



P�lda 48
=========

void f()
{
	char buf[100];
	cin >> buf;			    // suspect: will overflow some day
	cin.get(buf,100,'\en');	// safe
	// ...
}


class ios_base {
public:
	// ...
	// names of format flags:

	typedef implementation_defined fmtflags;
	static const fmtflags
		skipws,			// skip whitespace on input

		left,			// field adjustment: pad after value
		right,			// pad before value
		internal,		// pad between sign and value

		boolalpha,		// use symbolic representation of true and false

		dec,				// integer base: base 10 output (decimal)
		hex,				// base 16 output (hexadecimal)
		oct,				// base 8 output (octal)

		scientific,			// floating-point notation: d.ddddddEdd
		fixed,			// dddd.dd
		showbase,			// on output prefix oct by 0 and hex by 0x
		showpoint,		// print trailing zeros
		showpos,			// explicit '+' for positive ints
		uppercase,		// 'E', 'X' rather than 'e', 'x'

		adjustfield,		// flags related to field adjustment (_io.field.adjust_)
		basefield,			// flags related to integer base (_io.out.int_)
		floatfield;			// flags related to floating-point output (_io.out.float_)

		fmtflags unitbuf;	// flush output after each output operation

	fmtflags flags() const;		// read flags
	fmtflags flags(fmtflags f);		// set flags

	fmtflags setf(fmtflags f) { return flags(flags()|f); }				// add flag
	// clear and set flags in mask:
	fmtflags setf(fmtflags f, fmtflags mask) { return flags((flags()&~mask)|(f&mask)); }
	void unsetf(fmtflags mask) { flags(flags()&~mask); }				// clear flags

	// ...
};



P�lda 67
=========

const ios_base::fmtflags my_opt = ios_base::left|ios_base::oct|ios_base::fixed;




P�lda 72
=========

cout.setf(ios_base::oct,ios_base::basefield);	// octal
cout.setf(ios_base::dec,ios_base::basefield);	// decimal
cout.setf(ios_base::hex,ios_base::basefield);	// hexadecimal




cout << "default:\et" << 1234.56789 << '\en';

cout.setf(ios_base::scientific,ios_base::floatfield);	// use scientific format
cout << "scientific:\et" << 1234.56789 << '\en';

cout.setf(ios_base::fixed,ios_base::floatfield);		// use fixed-point format
cout << "fixed:\et" << 1234.56789 << '\en';

cout.setf(0,ios_base::floatfield);				// reset to default (that is, general format)
cout << "default:\et" << 1234.56789 << '\en';


default:	1234.57
scientific:	1.234568e+03
fixed:	1234.567890
default:	1234.57



P�lda 77
=========

class ios_base {
public:
	// ...
	streamsize precision() const;		// get precision
	streamsize precision(streamsize n);	// set precision (and get old precision)
	// ...
};


cout.precision(8);
cout << 1234.56789 << ' ' << 1234.56789 << ' ' << 123456 << '\en';

cout.precision(4);
cout << 1234.56789 << ' ' << 1234.56789 << ' ' << 123456 << '\en';


1234.5679 1234.5679 123456
1235 1235 123456



P�lda 80
=========

class ios_base {
public:
	// ...
	streamsize width() const;			// get field width
	streamsize width(streamsize wide);	// set field width
	// ...
};

template <class Ch, class Tr = char_traits<Ch> >
class basic_ios : public ios_base {
public:
	// ...
	Ch fill() const;				// get filler character
	Ch fill(Ch ch);				// set filler character
	// ...
};

cout.width(4);
cout << 12;


cout.width(4);
cout.fill('#');
cout << "ab";


cout.width(0); // ``as many characters as needed''


cout.width(4);
cout.fill('#');
cout << 12 << ':' << 13;



P�lda 86
=========

cout.setf(ios_base::left,ios_base::adjustfield);		// left
cout.setf(ios_base::right,ios_base::adjustfield);	// right
cout.setf(ios_base::internal,ios_base::adjustfield);	// internal


cout.fill('#');

cout << '(';
cout.width(4);
cout << -12 << "),(";

cout.width(4);
cout.setf(ios_base::left,ios_base::adjustfield);
cout << -12 << "),(";

cout.width(4);
cout.setf(ios_base::internal,ios_base::adjustfield);
cout << -12 << ")";



P�lda 88
=========

cout << x << flush << y << flush;


template <class Ch, class Tr = char_traits<Ch> >
class basic_istream : virtual public basic_ios<Ch,Tr> {
public:
	// ...
	basic_istream& operator>>(basic_istream& (*pf)(basic_istream&));
	basic_istream& operator>>(basic_ios<Ch,Tr>& (*pf)(basic_ios<Ch,Tr>&));
	basic_istream& operator>>(ios_base& (*pf)(ios_base&));
	// ...
};


P�lda 100
=========

cout << setprecision(4) << angle;




P�lda 104
=========

ios_base& boolalpha(ios_base&);	// symbolic representation of true and false (input and output)
ios_base& noboolalpha(ios_base& s);	// s.unsetf(ios_base::boolalpha)

ios_base& showbase(ios_base&);	// on output prefix oct by 0 and hex by 0x
ios_base& noshowbase(ios_base& s);	// s.unsetf(ios_base::showbase)

ios_base& showpoint(ios_base&);
ios_base& noshowpoint(ios_base& s);	// s.unsetf(ios_base::showpoint)

ios_base& showpos(ios_base&);
ios_base& noshowpos(ios_base& s);	// s.unsetf(ios_base::showpos)

ios_base& skipws(ios_base&);		// skip whitespace
ios_base& noskipws(ios_base& s);	// s.unsetf(ios_base::skipws)

ios_base& uppercase(ios_base&);	// X and E rather than x and e
ios_base& nouppercase(ios_base&);	// x and e rather than X and E

ios_base& internal(ios_base&);		// adjust _io.field.adjust_
ios_base& left(ios_base&);			// pad after value
ios_base& right(ios_base&);		// pad before value

ios_base& dec(ios_base&);			// integer base is 10 (_io.out.int_)
ios_base& hex(ios_base&);			// integer base is 16
ios_base& oct(ios_base&);			// integer base is 8

ios_base& fixed(ios_base&);		// floating-point format dddd.dd (_io.out.float_)
ios_base& scientific(ios_base&);		// scientific format d.ddddEdd


template <class Ch, class Tr>
	basic_ostream<Ch,Tr>& endl(basic_ostream<Ch,Tr>&);	// put '\en' and flush
template <class Ch, class Tr>
	basic_ostream<Ch,Tr>& ends(basic_ostream<Ch,Tr>&);	// put '\e0' and flush
template <class Ch, class Tr>
	basic_ostream<Ch,Tr>& flush(basic_ostream<Ch,Tr>&);	// flush stream 

template <class Ch, class Tr>
	basic_istream<Ch,Tr>& ws(basic_istream<Ch,Tr>&);	// eat whitespace

smanip resetiosflags(ios_base::fmtflags f);	// clear flags (_io.format_)
smanip setiosflags(ios_base::fmtflags f);		// set flags (_io.format_)
smanip setbase(int b);					// output integers in base b (_io.out.int_)
smanip setfill(int c);					// make c the fill character (_io.fields_)
smanip setprecision(int n);				// n digits (_io.out.float_, _io.manipulators_)
smanip setw(int n);						// next field width is n char (_io.fields_)



P�lda 110
=========

class Bound_form;	// Form plus value

class Form {
	friend ostream& operator<<(ostream&, const Bound_form&);

	int prc;	// precision
	int wdt;	// width, 0 means as wide as necessary
	int fmt;	// general, scientific, or fixed (_io.out.float_)
	// ...
public:
	explicit Form(int p = 6) : prc(p)	// default precision is 6
	{
		fmt = 0;	// general format (_io.out.float_)
		wdt = 0;	// as wide as necessary
	}

	Bound_form operator()(double d) const;	// make a Bound_form for *this and d

	Form& scientific() { fmt = ios_base::scientific; return *this; }
	Form& fixed() { fmt = ios_base::fixed; return *this; }
	Form& general() { fmt = 0; return *this; }

	Form& uppercase();
	Form& lowercase();
	Form& precision(int p) { prc = p; return *this; }

	Form& width(int w) { wdt = w; return *this; }		// applies to all types
	Form& fill(char);

	Form& plus(bool b = true);					// explicit plus
	Form& trailing_zeros(bool b = true);				// print trailing zeros
	// ...
};


struct Bound_form {
	const Form& f;
	double val;

	Bound_form(const Form& ff, double v) : f(ff), val(v) { }
};

Bound_form Form::operator()(double d) { return Bound_form(*this,d); }

ostream& operator<<(ostream& os, const Bound_form& bf)
{
	ostringstream s;		// string streams are described in _io.stringstream_
	s.precision(bf.f.prc);
	s.setf(bf.f.fmt,ios_base::floatfield);
	s << bf.val;			// compose string in s
	return os << s.str();	// output s to os
}



P�lda 112
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_iostream : public basic_istream<Ch,Tr>, public basic_ostream<Ch,Tr> {
public:
	explicit basic_iostream(basic_streambuf<Ch,Tr>* sb);
	virtual ~basic_iostream();
};

typedef basic_iostream<char> iostream;
typedef basic_iostream<wchar_t> wiostream;



P�lda 113
=========

#include <fstream>
#include <cstdlib>

void error(const char* p, const char* p2 = "")
{
	cerr << p << ' ' << p2 << '\en';
	std::exit(1);
}

int main(int argc, char* argv[])
{
	if (argc != 3) error("wrong number of arguments");

	std::ifstream from(argv[1]);					// open input file stream
	if (!from) error("cannot open input file",argv[1]);

	std::ofstream to(argv[2]);					// open output file stream
	if (!to) error("cannot open output file",argv[2]);

	char ch;
	while (from.get(ch)) to.put(ch);

	if (!from.eof() || !to) error("something strange happened");
}



P�lda 114
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_ofstream : public basic_ostream<Ch,Tr> {
public:
	basic_ofstream();
	explicit basic_ofstream(const char* p, openmode m = out);

	basic_filebuf<Ch,Tr>* rdbuf() const;

	bool is_open() const;
	void open(const char* p, openmode m = out);
	void close();
};



P�lda 115
=========

typedef basic_ifstream<char> ifstream;
typedef basic_ofstream<char> ofstream;
typedef basic_fstream<char> fstream;

typedef basic_ifstream<wchar_t> wifstream;
typedef basic_ofstream<wchar_t> wofstream;
typedef basic_fstream<wchar_t> wfstream;


class ios_base {
public:
	// ...

	typedef \fP\f(BIimplementation_defined3\f(CW\fZ openmode;
	static openmode app,	// append
				ate,		// open and seek to end of file (pronounced ``at end'')
				binary,	// I/O to be done in binary mode (rather than text mode)
				in,		// open for reading
				out,		// open for writing
				trunc;	// truncate file to 0-length

	// ...
};




P�lda 123
=========

template <class Ch, class Tr=char_traits<Ch> >
class basic_stringstream : public basic_iostream<Ch,Tr> {
public:
	explicit basic_stringstream(ios_base::openmode m = out|in);
	explicit basic_stringstream(const basic_string<Ch>& s, openmode m = out|in);

	basic_string<Ch> str() const;			// get copy of string
	void str(const basic_string<Ch>& s);	// set value to copy of s

	basic_stringbuf<Ch,Tr>* rdbuf() const;
};

typedef basic_istringstream<char> istringstream;
typedef basic_ostringstream<char> ostringstream;
typedef basic_stringstream<char> stringstream;
typedef basic_istringstream<wchar_t> wistringstream;
typedef basic_ostringstream<wchar_t> wostringstream;
typedef basic_stringstream<wchar_t> wstringstream;



P�lda 124
=========

string compose(int n, const string& cs)
{
	extern const char* std_message[];
	ostringstream ost;
	ost << "error(" << n << ") " << std_message[n] << " (user comment: " << cs << ')';
	return ost.str();
}


P�lda 127
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_ostream : virtual public basic_ios<Ch,Tr> {
public:
	// ...
	explicit basic_ostream(basic_streambuf<Ch,Tr>* b);

	pos_type tellp();							// get current position
	basic_ostream& seekp(pos_type);				// set current position
	basic_ostream& seekp(off_type, ios_base::seekdir);	// set current position

	basic_ostream& flush();		// empty buffer (to real destination)

	basic_ostream& operator<<(basic_streambuf<Ch,Tr>* b);	// write from b
};



P�lda 128
=========

class ios_base {
	// ...

	typedef implementation_defined seekdir;
	static const seekdir beg,	// seek from beginning of current file
					cur,	// seek from current position
					end;	// seek backwards from end of current file
	// ...
};



P�lda 129
=========

int f(ofstream& fout)	// fout refers to some file
{
	fout.seekp(10);
	fout << '#';			// add character and move position (+1)
	fout.seekp(-2,ios_base::cur);
	fout << '*';
}



P�lda 130
=========

template <class Ch, class Tr = char_traits<Ch> >
class basic_istream : virtual public basic_ios<Ch,Tr> {
public:
	// ...

	explicit basic_istream(basic_streambuf<Ch,Tr>* b);



P�lda 140
=========

void f()
{
	std::locale loc("POSIX");		// standard locale for POSIX

	cin.imbue(loc);				// let cin use loc
	// ...
	cin.imbue(std::locale());		// reset cin to use the default (global) locale
}



P�lda 141
=========

void g(const locale& loc = locale())			// use current global locale by default
{
	locale old_global = locale::global(loc);	// make loc the default locale
	// ...
}






P�lda 144
=========

int printf(const char* format ...);			// write to stdout
int fprintf(FILE*, const char* format ...);	// write to ``file'' (stdout, stderr)
int sprintf(char* p, const char* format ...);	// write to p[0] ...


