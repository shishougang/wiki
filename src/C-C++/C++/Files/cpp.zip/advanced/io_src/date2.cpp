#include <iostream>
#include <cstring>
#include <cstdlib>
#include "date2.h"

using namespace std;

date::fmt date::next_fmt = date::ansi;
int (date::*date::print1st)() const = date::get_year;
int (date::*date::print2nd)() const = date::get_month;
int (date::*date::print3rd)() const = date::get_day;

ostream& operator<<( ostream& os, date::fmt f)
{
    switch ( f )
    {
    default:
    case date::ansi:
        date::print1st = date::get_year;
        date::print2nd = date::get_month;
        date::print3rd = date::get_day;
        break;
    case date::us:
        date::print1st = date::get_month;
        date::print2nd = date::get_day;
        date::print3rd = date::get_year;
        break;
    case date::de:
        date::print1st = date::get_day;
        date::print2nd = date::get_month;
        date::print3rd = date::get_year;
        break;
    case date::hu:
        date::print1st = date::get_year;
        date::print2nd = date::get_month;
        date::print3rd = date::get_day;
        break;
    }
    return os;
}
void date::print( std::ostream& os) const
{
    os << "[ " 
       << (this->*print1st)() << ' '
       << (this->*print2nd)() << ' '
       << (this->*print3rd)()
       << " ]";
}
date::date( const char *s)
{
    char *p1 = strchr( s, '.');
    char *p2 = strrchr( s, '.');

    if ( p1 && p2 && p1 != p2 )
    {
        int y = atoi(s);
        int m = atoi(p1);
        int d = atoi(p2);

        set( y, m, d);
    }
}
bool operator<( date d1, date d2)
{
    return d1.get_year() < d2.get_year()  ||
           d1.get_year() == d2.get_year() && d1.get_month() < d2.get_month()  ||
           d1.get_year() == d2.get_year() && d1.get_month() == d2.get_month() 
                                          && d1.get_day() < d2.get_day();

}
date& date::next()
{
    static int day_in_month[] = { 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 };
    ++day;
    if ( day-1 == day_in_month[month-1])
    {
        day = 1;
        ++month;
    }
    if ( 13 == month )
    {
        month = 1;
        ++year;
    }
    return *this;
}
date& date::add( int n)
{
    for (int i = 0; i < n; ++i)
        ++ *this;
    return *this;
}
void date::read( std::istream& is)
{
    // this is not perfect...
    is >> year >> month >> day;
}
istream& operator>>( istream& is, date& d)
{
    d.read( is);
    return is;
}
ostream& operator<<( ostream& os, const date &d)
{
    d.print( os);
    return os;
}


