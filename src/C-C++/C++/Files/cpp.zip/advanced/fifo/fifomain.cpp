#include <iostream>
#include "fifo.h"

using namespace std;

int main()
{
    fifo<int> fd(5);

    fd.push(1);
    fd.push(2);
    fd.push(3);
    fd.push(4);

//    fd.print(cerr);
    cout << fd.pop() << " " << fd.pop() << " ";
 
    fd.push(5);
    fd.push(6);
    fd.push(7);

//    fd.print(cerr);

    while ( ! fd.is_empty() )
        cout << fd.pop() << " ";

    cout << endl;
    return 0;
}