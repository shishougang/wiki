// sorting integers by binary tree 
// using reference
// and constructor

#include <iostream>
#include <new>
#include <memory>

using namespace std;

struct node
{
         node( int v);
    void print() const;

    void *operator new( size_t sz) throw (bad_alloc)
    { 
        std::cerr << "node::new" << std::endl; 
        return ::operator new(sz);
    }
    void  operator delete(void *p) throw()
    { 
        std::cerr << "node::delete" << std::endl;
        ::operator delete(p);
    }

    int   val;
    node *left;
    node *right;
};
node::node( int v)        // the constructor
{
    left = right = 0;
    val = v;
}
void node::print() const	// a const member function
{
    cout << val << " "; 
}

void *operator new( size_t sz) throw (bad_alloc)
{
    std::cerr << "::new" << std::endl;
    return malloc(sz);
}
void operator delete( void *p) throw ()
{
    std::cerr << "::delete" << std::endl;
    // return free(p);
    free(p);
}

void insert( node *&r, int v);	// insert into (sub)tree
void print( node *r);		    // print (sub)tree

int main()
{
    node *root = 0;
    int   i;
    
    while ( cin >> i )
    {
        insert( root, i);
    }
    print( root);
    return 0;
}
void print( node *r)
{
    if ( r )
    {
        print( r->left);
        r->print();
    	print( r->right);
    }
}
void insert( node *&r, int v)
{
    if ( r )
    {
        insert( v < r->val ? r->left : r->right, v);
    }
    else
    {
        r = new node(v);
    }
}
