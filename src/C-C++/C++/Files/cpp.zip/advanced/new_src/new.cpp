
class bad_alloc : public exception { /* ... */ };

struct nothrow_t {};
extern const nothrow_t nothrow;	// indicator for allocation that doesn't throw exceptions

typedef void (*new_handler)();
new_handler set_new_handler(new_handler new_p) throw();

void* operator new(size_t) throw(bad_alloc);	// throws bad_alloc
void operator delete(void*) throw();

void* operator new(size_t, const nothrow_t&) throw();	// nothrow
void operator delete(void*, const nothrow_t&) throw();

void* operator new[](size_t) throw(bad_alloc);
void operator delete[](void*) throw();

void* operator new[](size_t, const nothrow_t&) throw();
void operator delete[](void*, const nothrow_t&) throw();

void* operator new (size_t, void* p) throw() { return p; }	// placement 
void operator delete (void* p, void*) throw() { }

void* operator new[](size_t, void* p) throw() { return p; }
void operator delete[](void* p, void*) throw() { }




void f()
{
	int* p = new int[100000];	// may throw bad_alloc

	if (int* q = new(nothrow) int[100000]) {  // will not throw exception
		// allocation succeeded
	}
	else {
		// allocation failed
	}
}




void* malloc(size_t s);			// allocate s bytes
void* calloc(size_t n, size_t s);	// allocate n times s bytes initialized to 0
void  free(void* p);			// free space allocated by malloc() or calloc()
void* realloc(void* p, size_t s);	// change the size of the array pointed to by p to s;
					// if that cannot be done, allocate s bytes, copy
					// the array pointed to by p to it, and free p




void* memcpy(void* p, const void* q, size_t n);	 // copy non-overlapping areas
void* memmove(void* p, const void* q, size_t n); // copy potentially overlapping areas


void* memchr(const void* p, int b, size_t n);	// like strchr() (_string.c_): find b in p[0]..p[n-1]					
int   memcmp(const void* p, const void* q, size_t n); // like strcmp(): compare byte sequences
void* memset(void* p, int b, size_t n);		// set n bytes to b, return p




