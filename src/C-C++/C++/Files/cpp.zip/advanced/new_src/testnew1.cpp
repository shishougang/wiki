
#include <iostream>
#include <ctime>

#include "date.h"

using namespace std;

int main()
{
    const long num_of_iter = 1000000L;

    time_t start_time = time(0);

    for( long i = 0; i < num_of_iter; ++i)
    {
	for ( long j = 0; j < 100; ++j)
	{
	    date *dp = new date(2001,1,1);
	    // ...
	    delete dp;	    
	}
    }

    time_t	stop_time = time(0);
    
    cout << stop_time - start_time << endl;
    return 0;
}
