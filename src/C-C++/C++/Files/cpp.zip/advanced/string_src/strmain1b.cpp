
#pragma warning(disable:4867)

#include <iostream>
#include <string>
#include "cistring1.h"

using namespace std;

int main()
{
    string s1("hELlo");
    string s2("HEllo");

    cout << boolalpha << (s1 == s2) << endl;

//    ci_string cs1("hELlo");
//    ci_string cs2("HEllo");
    ci_string cs1 = "hELlo";
    ci_string cs2 = "HEllo";

    cout << cs1 << ", " << cs2 << endl;  // syntax error !
/*
    template <class charT, class Traits, class Allocator>
    basic_ostream<charT, Traits>&
        operator<< (basic_ostream<charT, Traits>& os,
                    const basic_string<charT, Traits, Allocator>& str)

    cout has type:  basic_ostream<char, char_traits<char> > !
 */

    cs1 += s1;  // syntax error !

    return 0;
}