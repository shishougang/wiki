
/*
 *  Constructors
 *
 */

template <class T, class A = allocator<T> > class vector {
public:
    // ...
    // constructors, etc.:

    explicit vector(const A& = A());
    explicit vector(size_type n, const T& val = T(), const A& = A());	// n copies of val
    template <class In>						// In must be an input iterator (_iter.oper_)
		vector(In first, In last, const A& = A());	// copy from [first:last[
    vector(const vector& x);

    ~vector();

    vector& operator=(const vector& x);

    template <class In>				    // In must be an input iterator (_iter.oper_)
		void assign(In first, In last);	    // copy from [first:last[
    void assign(size_type n, const T& val);	    // n copies of val

    // ...
};


