
/*
 *  Equal and Mismatch
 *
 */

template<class In, class In2>
    bool equal(In first, In last, In2 first2);

template<class In, class In2, class BinPred>
    bool equal(In first, In last, In2 first2, BinPred p);


// returns with the first non-equal element
template<class In, class In2> 
    pair<In, In2> mismatch(In first, In last, In2 first2);

template<class In, class In2, class BinPred>
    pair<In, In2> mismatch(In first, In last, In2 first2, BinPred p);



/*
 *  Usage: need not be the same type
 *
 */

void f(list<int>& li, vector<double>& vd)
{
    bool b = equal(li.begin(),li.end(),vd.begin());
}


