
/*
 *  Min and Max
 *
 */

template<class T> const T& max(const T& a, const T& b)
{
    return (a<b) ? b : a;
}

template<class T, class Cmp> const T& max(const T& a, const T& b, Cmp cmp)
{
    return (cmp(a,b)) ? b : a;
}

template<class T> const T& min(const T& a, const T& b);

template<class T, class Cmp> const T& min(const T& a, const T& b, Cmp cmp);



template<class For> For max_element(For first, For last);
template<class For, class Cmp> For max_element(For first, For last, Cmp cmp);

template<class For> For min_element(For first, For last);
template<class For, class Cmp> For min_element(For first, For last, Cmp cmp);



template<class In, class In2>
bool lexicographical_compare(In first, In last, In2 first2, In2 last2);

template<class In, class In2, class Cmp>
bool lexicographical_compare(In first, In last, In2 first2, In2 last2, Cmp cmp)
{
    while (first != last && first2 != last2) {
	if (cmp(*first,*first2)) return true;
	if (cmp(*first2++,*first++)) return false;
    }
    return first == last && first2 != last2;
}


/*
 *  Usage
 *
 */

char v1[] = "yes";
char v2[] = "no";
string s1 = "Yes";
string s2 = "No";

void f()
{
    bool b1 = lexicographical_compare(v1,v1+strlen(v1),v2,v2+strlen(v2));
    bool b2 = lexicographical_compare(s1.begin(),s1.end(),s2.begin(),s2.end());

    bool b3 = lexicographical_compare(v1,v1+strlen(v1),s1.begin(),s1.end());
    bool b4 = lexicographical_compare(s1.begin(),s1.end(),v1,v1+strlen(v1),Nocase());
}


