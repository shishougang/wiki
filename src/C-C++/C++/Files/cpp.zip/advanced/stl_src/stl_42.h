
/*
 *  Replace
 *
 */

template<class For, class T>
void replace(For first, For last, const T& val, const T& new_val)
{
    while (first != last) {
    	if (*first == val) *first = new_val;
	++first;
    }
}

template<class For, class Pred, class T>
void replace_if(For first, For last, Pred p, const T& new_val)
{
    while (first != last) {
	if (p(*first)) *first = new_val;
	++first;
    }
}

template<class In, class Out, class T>
Out replace_copy(In first, In last, Out res, const T& val, const T& new_val)
{
    while (first != last) {
	*res++ = (*first == val) ? new_val : *first;
	++first;
    }
     return res;
}

template<class In, class Out, class Pred, class T>
Out replace_copy_if(In first, In last, Out res, Pred p, const T& new_val)
{
    while (first != last) {
    	*res++ = p(*first) ? new_val : *first;
    	++first;
    }
    return res;
}


/*
 *  Usage
 *
 */

void f(list<string>& towns)
{
	replace(towns.begin(),towns.end(),"Aarhus","\*(Aarhus");
}


