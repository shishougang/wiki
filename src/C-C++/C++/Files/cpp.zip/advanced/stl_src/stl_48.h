
/*
 *  Binary Search
 *
 */

template<class For, class T> 
	bool binary_search(For first, For last, const T& val);

template<class For, class T, class Cmp>
	bool binary_search(For first, For last, const T& value, Cmp cmp);


/*
 *  Usage
 *
 */

void f(list<int>& c)
{
	if (binary_search(c.begin(),c.end(),7)) {	// is 7 in c?
		// ...
	}
	// ...
}


