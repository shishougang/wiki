
/*
 *  Sorted Sequences
 *
 *
 *  Sort
 * 
 */

template<class Ran> void sort(Ran first, Ran last);
template<class Ran, class Cmp> void sort(Ran first, Ran last, Cmp cmp);

template<class Ran> void stable_sort(Ran first, Ran last);
template<class Ran, class Cmp> void stable_sort(Ran first, Ran last, Cmp cmp);



template<class Ran> void partial_sort(Ran first, Ran middle, Ran last);
template<class Ran, class Cmp>
	void partial_sort(Ran first, Ran middle, Ran last, Cmp cmp);

template<class In, class Ran>
	Ran partial_sort_copy(In first, In last, Ran first2, Ran last2);
template<class In, class Ran, class Cmp>
	Ran partial_sort_copy(In first, In last, Ran first2, Ran last2, Cmp cmp);



