
/*
 *  Search
 *
 */

template<class For, class For2>
	For search(For first, For last, For2 first2, For2 last2);

template<class For, class For2, class BinPred>
	For search(For first, For last, For2 first2, For2 last2, BinPred p);

template<class For, class For2>
	For find_end(For first, For last, For2 first2, For2 last2);

template<class For, class For2, class BinPred>
	For find_end(For first, For last, For2 first2, For2 last2, BinPred p);

template<class For, class Size, class T>
	For search_n(For first, For last, Size n, const T& val);

template<class For, class Size, class T, class BinPred>
	For search_n(For first, For last, Size n, const T& val, BinPred p);


