
/*
 *  Reverse and Rotate
 *
 */

template<class Bi> void reverse(Bi first, Bi last);
template<class Bi, class Out> Out reverse_copy(Bi first, Bi last, Out res);

template<class For> void rotate(For first, For middle, For last);
template<class For, class Out> Out rotate_copy(For first, For middle, For last, Out res);

template<class Ran> void random_shuffle(Ran first, Ran last);
template<class Ran, class Gen> void random_shuffle(Ran first, Ran last, Gen& g);


/*
 *  Usage
 *
 */

void f()
{
    string v[] = { "Frog", "and","Peach" };

    reverse(v,v+3);	// Peach and Frog
    rotate(v,v+1,v+3);	// and Frog Peach
}


void f(deque<Card>& dc)
{
	Urand r(52);
	random_shuffle(dc.begin(),dc.end(),r);
	// ...
}



