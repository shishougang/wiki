
/*
 *  Count
 *
 */

template<class In, class T>
	typename iterator_traits<In>::difference_type count(In first, In last, const T& val);

template<class In, class Pred>
	typename iterator_traits<In>::difference_type count_if(In first, In last, Pred p);


