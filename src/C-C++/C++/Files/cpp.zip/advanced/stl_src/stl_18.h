
/*
 *  List operations
 *
 */

template <class T, class A = allocator<T> > class vector {
public:
    // ...
    // list operations:

    iterator insert(iterator pos, const T& x);		// add x before pos
    void insert(iterator pos, size_type n, const T& x);	// add n copies of x before pos
    template <class In>					// In must be an input iterator
    void insert(iterator pos, In first, In last);	// insert elements from sequence

    iterator erase(iterator pos);			// remove element at pos
    iterator erase(iterator first, iterator last);	// erase sequence
    void clear();					// erase all elements

    // ...
};


/*
 *  Usage of list operations
 *
 */

void duplicate_elements(vector<string>& f)
{
    for(vector<string>::iterator p = f.begin(); p!=f.end(); ++p) f.insert(p,*p);	// No!
}



template<class C> void f(C& c)
{
    c.erase(c.begin()+7);		// ok (if c's iterators support + )
    c.erase(&c[7]);			// not general
    c.erase(c+7);			// error: adding 7 to a container makes no sense

    c.erase(c.back());			// error: c.back() is a reference, not an iterator
    c.erase(c.end()-2);			// ok (second to last element)
    c.erase(c.rbegin()+2);		// error: vector::reverse_iterator and vector::iterator
					//	are different types
    c.erase((c.rbegin()+2).base());	// obscure, but ok 
}


