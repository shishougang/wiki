
/*
 *  Replace
 *
 */

template<class For, class T> 
	For remove(For first, For last, const T& val);

template<class For, class Pred> 
	For remove_if(For first, For last, Pred p);

template<class In, class Out, class T>
	Out remove_copy(In first, In last, Out res, const T& val);

template<class In, class Out, class Pred>
	Out remove_copy_if(In first, In last, Out res, Pred p);


/*
 *  Usage
 *
 */

class located_in {
    string town;
public:
    located_in(const string& ss) :town(ss) { }
    bool operator()(const Club& c) const { return c.town == town; }
};

void f(list<Club>& lc)
{
    remove_copy_if(lc.begin(),lc.end(),
	output_iterator<Club>(cout),not1(located_in("Koebenhavn")));
}

