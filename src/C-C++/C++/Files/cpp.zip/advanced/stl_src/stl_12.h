/*
 *  Types defined in a container
 */

template <class T, class A = allocator<T> > class std::vector {
public:
    // types:

    typedef T value_type;			// type of element
    typedef A allocator_type;			// type of memory manager
    typedef typename A::size_type size_type;
    typedef typename A::difference_type difference_type;

    typedef implementation_dependent1 iterator;		// T*
    typedef implementation_dependent2 const_iterator; 	// const T*
    typedef std::reverse_iterator<iterator> reverse_iterator;
    typedef std::reverse_iterator<const_iterator> const_reverse_iterator;

    typedef typename A::pointer pointer;		// pointer to element
    typedef typename A::const_pointer const_pointer;
    typedef typename A::reference reference;		// reference to element
    typedef typename A::const_reference const_reference;

    // ...
};


/*
 *  usage of types declared in a container 
 *  makes you be able to write generic code
 *
 */

template<class C> typename C::value_type sum(const C& c)
{
	typename C::value_type s = 0;
	typename C::const_iterator p = c.begin();   // start at the beginning
	while (p!=c.end()) {			    // continue until the end
		s += *p;		// get value of element
		++p;			// make p point to next element
	}
	return s;
}


