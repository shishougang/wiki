/*
 *  Others
 *
 */

template <class T, class A = allocator<T> > class vector {
public:
	// ...

	void swap(vector&);

	allocator_type get_allocator() const;
};


template <class T, class A>
bool std::operator==(const vector<T,A>& x, const vector<T,A>& y);

template <class T, class A>
bool std::operator<(const vector<T,A>& x, const vector<T,A>& y);


template <class T, class A>
inline bool std::operator<(const vector<T,A>& x, const vector<T,A>& y)
{
	return lexicographical_compare(x.begin(),x.end(),y.begin(),y.end());	// see _algo.min_
}


template <class T, class A> void std::swap(vector<T,A>& x, vector<T,A>& y)
{
	x.swap(y);
}


