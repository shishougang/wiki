
/*
 *  Size and Capacity
 *
 */

template <class T, class A = allocator<T> > class vector {
public:
    // ...
    // capacity:

    size_type size() const;			// number of elements
    bool empty() const { return size()==0; }
    size_type max_size() const;			// size of the largest possible vector
    void resize(size_type sz, T val = T());	// added elements initialized by val

    size_type capacity() const;	// size of the memory (in number of elements) allocated
    void reserve(size_type n);	// make room for a total of n elements; don't initialize
				// throw a length_error if n>max_size()
    // ...
};


/*
 *  Usage of size and capacity
 *
 */

class Histogram {
    vector<int> count;
public:
    Histogram(int h) : count(max(h,8)) {}
    void record(int i);
    // ...
};

void Histogram::record(int i)
{
    if (i<0) i = 0;
    if (count.size()<=i) 
	count.resize(i+i);	// make lots of room
    count[i]++;
}



