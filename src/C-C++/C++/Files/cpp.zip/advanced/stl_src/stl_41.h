
/*
 *  Unique
 *
 */

template<class For> For unique(For first, For last);
template<class For, class BinPred> For unique(For first, For last, BinPred p);

template<class In, class Out> Out unique_copy(In first, In last, Out res);
template<class In, class Out, class BinPred>
	Out unique_copy(In first, In last, Out res, BinPred p);


/*
 *  Usage
 *
 */
  
void f(list<string>& ls, vector<string>& vs)
{
	ls.sort();	// list sort (_cont.splice_)
	unique_copy(ls.begin(),ls.end(),back_inserter(vs));
}


/*
 *  Possible implementation
 *
 */

template <class For> For unique(For first, For last)
{
	first = adjacent_find(first,last);	
	return unique_copy(first,last,first);
}



