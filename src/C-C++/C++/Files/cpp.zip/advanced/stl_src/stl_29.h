
/*
 *  List operations on map
 *
 */

template <class Key, class T, class Cmp = less<Key>,
		class A = allocator< pair<const Key,T> > >
class map {
public:
    // ...
    // list operations:

    pair<iterator, bool> insert(const value_type& val);	// insert (key,value) pair
    iterator insert(iterator pos, const value_type& val);   // pos is just a hint
    template <class In> void insert(In first, In last);	// insert elements from sequence

    void erase(iterator pos);			// erase the element pointed to
    size_type erase(const key_type& k);		// erase element with key k (if present)
    void erase(iterator first, iterator last);	// erase range
    void clear();				// Erase all elements

    // ...
};


/*
 *  Usage of list operation
 *
 */

void f(map<string,int>& m)
{
    pair<string,int> p99("Paul",99);

    pair<map<string,int>::iterator,bool> p = m.insert(p99);
    if (p.second) {
    	// "Paul" was inserted
    }
    else {
    	// "Paul" was there already
    }
    map<string,int>::iterator i = p.first;	// points to m["Paul"]
    // ...
}


