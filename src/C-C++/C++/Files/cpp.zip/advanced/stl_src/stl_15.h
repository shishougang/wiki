
/*
 *  Element access
 *
 */

template <class T, class A = allocator<T> > class vector {
public:
    // ...
    // element access:

    reference operator[](size_type n);	// unchecked access
    const_reference operator[](size_type n) const;

    reference at(size_type n);		// checked access
    const_reference at(size_type n) const;

    reference front();		// first element
    const_reference front() const;
    reference back();		// last element
    const_reference back() const;

    // ...
};



/*
 *  Use of constructors
 *
 */

vector<Record> vr(10000);

void f(int s1, int s2)
{
    vector<int> vi(s1);

    vector<double>* p = new vector<double>(s2);
}




void f(const list<X>& lst)
{
    vector<X> v1(lst.begin(),lst.end());    // copy elements from list

    char p[] = "despair";
    vector<char> v2(p,&p[sizeof(p)-1]);	    // copy characters from C-style string
}



vector<int> v1(10);			// ok: vector of 10 ints
vector<int> v2 = vector<int>(10);	// ok: vector of 10 ints
vector<int> v3 = v2;			// ok: v3 is a copy of v2
vector<int> v4 = 10;			// error: attempted implicit conversion of 10 to vector<int>



void f1(vector<int>&);		// common style
void f2(const vector<int>&);	// common style
void f3(vector<int>);		// rare style

void h()
{
    vector<int> v(10000);

    // ...

    f1(v);	// pass a reference
    f2(v);	// pass a reference
    f3(v);	// copy the 10000 elements into a new vector for f3() to use
}


