/*
 *  Transform
 *
 */

template<class In, class Out, class Op>
Out transform(In first, In last, Out res, Op op)
{
	while (first != last) *res++ = op(*first++);
	return res;
}

template<class In, class In2, class Out, class BinOp>
Out transform(In first, In last, In2 first2, Out res, BinOp op)
{
	while (first != last) *res++ = op(*first++,*first2++);
	return res;
}



