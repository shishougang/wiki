
/*
 *  Map constructors
 *
 */

template <class Key, class T, class Cmp =less<Key>,
		class A =allocator<pair<const Key,T> > >
class map {
public:
	// ...
 	// construct/copy/destroy:

	explicit map(const Cmp& = Cmp(), const A& = A());
	template <class In> map(In first, In last, const Cmp& = Cmp(), const A& = A());
	map(const map&);

	~map();

	map& operator=(const map&);

	// ...
};


