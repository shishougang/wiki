
/*
 *  Queue
 *
 */

template <class T, class C = deque<T> > class std::queue {
protected:
    C c;
public:
    typedef typename C::value_type value_type;
    typedef typename C::size_type size_type;
    typedef C container_type;

    explicit queue(const C& a = C()) : c(a) { }

    bool empty() const { return c.empty(); }
    size_type size() const { return c.size(); }

    value_type& front() { return c.front(); }
    const value_type& front() const { return c.front(); }

    value_type& back() { return c.back(); }
    const value_type& back() const { return c.back(); }

    void push(const value_type& x) { c.push_back(x); }
    void pop() { c.pop_front(); }
 };


/*
 *  Usage of queue
 *
 */

struct Message {
    // ...
};

void server(queue<Message>& q)
{
    while(!q.empty()) {
    	Message& m = q.front();	    // get hold of message
    	m.service();		    // call function to serve request
    	q.pop();		    // destroy message
    }
}


