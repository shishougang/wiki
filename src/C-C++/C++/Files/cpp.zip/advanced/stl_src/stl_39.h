
/*
 *  Modifying Sequence Algorithms
 *
 *
 *  Copy
 * 
 */

template<class In, class Out> 
	    Out copy(In first, In last, Out res)
{
    while (first != last) *res++ = *first++;
    return res;
}

template<class Bi, class Bi2> 
	    Bi2 copy_backward(Bi first, Bi last, Bi2 res)
{
    while (first != last) *--res = *--last;
    return res;
}

template<class In, class Out, class Pred>
	    Out copy_if(In first, In last, Out res, Pred p)
{
    while (first != last) {
	if (p(*first)) *res++ = *first;
	++first;
    }
    return res;
}


/*
 *  Usage
 *
 */

void f(list<Club>& lc, ostream& os)
{
    copy(lc.begin(),lc.end(),ostream_iterator<Club>(os));
}


void f(vector<char>& vs)
{
    vector<char> v;

    copy(vs.begin(),vs.end(),v.begin());	// error: might overwrite end of v
    copy(vs.begin(),vs.end(),back_inserter(v));	// ok: add elements from vs to end of v
}


void f(list<int>&ld, int n, ostream& os)
{
    copy_if(ld.begin(),ld.end(),ostream_iterator<int>(os),bind2nd(greater<int>(),n));
}

