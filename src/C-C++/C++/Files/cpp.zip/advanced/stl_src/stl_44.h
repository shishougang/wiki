
/*
 *  Fill and Generate
 *
 */

template<class For, class T> void fill(For first, For last, const T& val);
template<class Out, class Size, class T> void fill_n(Out res, Size n, const T& val);

template<class For, class Gen> void generate(For first, For last, Gen g);
template<class Out, class Size, class Gen> void generate_n(Out res, Size n, Gen g);


/*
 *  Usage
 *
 */

int v1[900];
int v2[900];
vector v3;

void f()
{
    fill(v1,&v1[900],99);		// set all elements of v1 to 99
    generate(v2,&v2[900],Randint());	// set to random values

    // output 200 random integers in the interval [0..99]:
    generate_n(ostream_iterator<int>(cout),200,Urand(100));

    fill_n(back_inserter(v3),20,99);	// add 20 elements with the value 99 to v3
}


