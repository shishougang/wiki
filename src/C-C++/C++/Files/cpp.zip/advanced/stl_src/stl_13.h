
template <class T, class A = allocator<T> > class vector {
public:
	// ...
	// iterators:

	iterator begin();				// points to first element
	const_iterator begin() const;
	iterator end();					// points to one-past-last element
	const_iterator end() const;

	reverse_iterator rbegin();			// points to first element of reverse sequence
	const_reverse_iterator rbegin() const;
	reverse_iterator rend();			// points to one-past-last element of reverse sequence
	const_reverse_iterator rend() const;

	// ...
};


/*
 *  Usage of reverse iterator
 *
 */

template<class C> typename C::iterator find_last(C& c, typename C::value_type v)
{
	typename C::reverse_iterator ri = find(c.rbegin(),c.rend(),v);
	if (ri == c.rend()) return c.end();	// use c.end() to indicate "not found"
	typename C::iterator i = ri.base(); 
	return --i;
}



template<class C> typename C::iterator find_last(C& c, typename C::value_type v)
{
	typename C::iterator p = c.end();	// search backwards from end
	while (p!=c.begin())
		if (*--p==v) return p;
	return c.end();				// use c.end() to indicate "not found"
}



template<class C> typename C::iterator find_last(C& c, typename C::value_type v)
{
	typename C::reverse_iterator p = c.rbegin();	// view sequence in reverse order
	while (p!=c.rend()) {
		if (*p==v) {
			typename C::iterator i = p.base(); 
			return --i;
		}
		++p;			// note: increment, not decrement (--)
	}
	return c.end();	// use c.end() to indicate "not found"
}


