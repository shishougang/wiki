
/*
 *  Access element
 *
 */

template <class Key, class T, class Cmp = less<Key>,
		class A = allocator< pair<const Key,T> > >
class map {
public:
    // ...
    mapped_type& operator[](const key_type& k);	// access element with key k
    // ...
};


/*
 *  Usage of access element
 *
 */

void f()
{
    map<string,int> m;	// map starting out empty
    int x = m["Henry"];	// create new entry for "Henry", initialize to 0, return 0
    m["Harry"] = 7;	// create new entry for "Harry", initialize to 0, and assign 7
    int y = m["Henry"];	// return the value from "Henry"'s entry
    m["Harry"] = 9;	// change the value from "Harry"'s entry to 9
}



