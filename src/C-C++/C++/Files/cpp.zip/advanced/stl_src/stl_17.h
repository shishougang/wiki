
/*
 *  Stack operations
 *
 */

template <class T, class A = allocator<T> > class vector {
public:
    // ...
    // stack operations:

    void push_back(const T& x);	// add to end
    void pop_back();		// remove last element
	// ...
};


/*
 *  Usage of stack operations
 *
 */

void f(vector<char>& s)
{
    s.push_back('a');
    s.push_back('b');
    s.push_back('c');
    s.pop_back();
    if (s[s.size()-1] != 'b') error("impossible!");
    s.pop_back();
    if (s.back() != 'a') error("should never happen!");
}	



vector<Point> cities;

void add_points(Point sentinel)
{
    Point buf;

    while (cin >> buf) {
    	if (buf == sentinel) return;
	// check new point
	cities.push_back(buf);
    }
}



void f()
{
    vector<int> v;
    v.pop_back();	// undefined effect: the state of v becomes undefined
    v.push_back(7);	// undefined effect (the state of v is undefined), probably bad
}


