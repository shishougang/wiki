
/*
 *  Map operations
 *
 */

template <class Key, class T, class Cmp = less<Key>,
		class A = allocator< pair<const Key,T> > >
class map {
public:
    // ...
    // map operations:

    iterator find(const key_type& k);			// find element with key k
    const_iterator find(const key_type& k) const;

    size_type count(const key_type& k) const;		// find number of elements with key k

    iterator lower_bound(const key_type& k);		// find first element with key k
    const_iterator lower_bound(const key_type& k) const;
    iterator upper_bound(const key_type& k);		// find first element with key greater than k
    const_iterator upper_bound(const key_type& k) const;

    pair<iterator,iterator> equal_range(const key_type& k);
    pair<const_iterator,const_iterator> equal_range(const key_type& k) const;

    // ...
};



/*
 *  Usage
 *
 */

void f(map<string,int>& m)
{
    map<string,int>::iterator p = m.find("Gold");
    if (p!=m.end()) {				// if "Gold" was found
    	// ...
    }
    else if (m.find("Silver")!=m.end()) {	// look for "Silver"
	// ...
    }
    // ...
}


void f(multimap<string,int>& m)
{
	multimap<string,int>::iterator lb = m.lower_bound("Gold");
	multimap<string,int>::iterator ub = m.upper_bound("Gold");

	for (multimap<string,int>::iterator p = lb; p!=ub; ++p) {
		// ...
	}
}


