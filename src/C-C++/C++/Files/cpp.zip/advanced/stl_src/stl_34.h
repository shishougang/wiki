/*
 *  Nonmodifying Sequence Algorithms
 *
 *
 *  For_each
 * 
 */

template<class In, class Op> Op for_each(In first, In last, Op f)
{
    while (first != last) f(*first++);
    return f;
}


/*
 *  Usage of for_each
 *
 */

void extract(const list<Club>& lc, list<Person*>& off) // place the officers from `lc' on `off'
{
	for_each(lc.begin(),lc.end(),Extract_officers(off));
}


class Extract_officers {
	list<Person*>& lst;
public:
	explicit Extract_officers(list<Person*>& x) : lst(x) { }

	void operator()(const Club& c)
		{ copy(c.officers.begin(),c.officers.end(),back_inserter(lst)); }
};



