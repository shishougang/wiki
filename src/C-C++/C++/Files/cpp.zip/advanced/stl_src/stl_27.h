
/*
 *  Comparison
 *
 */

template <class Key, class T, class Cmp = less<Key>,
		class A = allocator< pair<const Key,T> > >
class map {
public:
    // ...

    typedef Cmp key_compare;

    class value_compare : public binary_function<value_type,value_type,bool> 
    {
	friend class map;
    protected:
	Cmp cmp;
        value_compare(Cmp c) : cmp(c) {}
    public:
	bool operator()(const value_type& x, const value_type& y) const
		{ return cmp(x.first, y.first); }
    };

    key_compare key_comp() const;
    value_compare value_comp() const;
    // ...
};


/*
 *  Usage of comparison
 *
 */

map<string,int> m1;
map<string,int,Nocase> m2;				// specify comparison type (_cont.comp_)
map<string,int,String_cmp> m3;				// specify comparison type (_cont.comp_)
map<string,int,String_cmp> m4(String_cmp(literary));	// pass comparison object


void f(map<string,int>& m)
{
    map<string,int> mm;			// compare using < by default
    map<string,int> mmm(m.key_comp());	// compare the way m does
    // ...
}


