
/*
 *  The Find family
 *
 */

template<class In, class T> In find(In first, In last, const T& val);

template<class In, class Pred> In find_if(In first, In last, Pred p);



template<class For, class For2>
    For find_first_of(For first, For last, For2 first2, For2 last2);

template<class For, class For2, class BinPred>
    For find_first_of(For first, For last, For2 first2, For2 last2, BinPred p);



template<class For> For adjacent_find(For first, For last);

template<class For, class BinPred> For adjacent_find(For first, For last, BinPred p);


/*
 *  Usage
 *
 */

bool pred(int);

void f(vector<bool(*f)(int)>& v1, vector<int>& v2)
{
    find(v1.begin(),v1.end(),pred);	// find `pred'
    find_if(v2.begin(),v2.end(),pred);	// find int for which pred() returns true
}


int x[] = { 1,3,4 };
int y[] = { 0,2,3,4,5};

void f()
{
    int* p = find_first_of(x,x+3,y,y+5);	// p = &x[1]
    int* q = find_first_of(p+1,x+3,y,y+5);	// q = &x[2]
}


void f(vector<string>& text)
{
    vector<string>::iterator p = adjacent_find(text.begin(),text.end());
    if (p!=text.end() && *p=="the") { // I duplicated "the" again!
	text.erase(p);
	// ...
    }
}



