
/*
 *  Sequence adapters
 * 
 *  Stack
 * 
 */

template <class T, class C = deque<T> > class std::stack {
protected:
    C c;
public:
    typedef typename C::value_type value_type;
    typedef typename C::size_type size_type;
    typedef C container_type;

    explicit stack(const C& a = C()) : c(a) { }

    bool empty() const { return c.empty(); }
    size_type size() const { return c.size(); }

    value_type& top() { return c.back(); }
    const value_type& top() const { return c.back(); }

    void push(const value_type& x) { c.push_back(x); }
    void pop() { c.pop_back(); }
};


/*
 *  Usage of stack
 *
 */

stack<char> s1;			// uses a deque<char> to store elements of type char
stack< int,vector<int> > s2;	// uses a vector<int> to store elements of type int


