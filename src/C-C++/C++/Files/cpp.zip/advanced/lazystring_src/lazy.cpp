#include <iostream>
#include "lstring.h"

using namespace std;

int main()
{
	lstring l1("Hello");
	lstring l2 = l1;

	cout << "l1.c_str() == l2.c_str() "
	/*	 << boolalpha */ << (l1.c_str() == l2.c_str()) << endl;

	l2 += 'x';
	cout << "l1.c_str() == l2.c_str() "
	/*	 << boolalpha */ << (l1.c_str() == l2.c_str()) << endl;

	cout << "l1 == " << l1.c_str()
		 << ", l2 == " << l2.c_str() << endl;

	lstring l3 = l2 + l1;
	cout << "l2 + l1 = " << l3.c_str() << ", " << (l2+l1).c_str() << endl;

	l3 += l1;
	cout << "l3 += l1 = " << l3.c_str() << endl;

	return 0;
}
