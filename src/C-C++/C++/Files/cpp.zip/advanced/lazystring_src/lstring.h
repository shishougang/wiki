#ifndef LSTRING_H
#define LSTRING_H

#include <string>

class lstring
{
public:
	lstring( const char *s);
	lstring( const lstring &rhs);
	~lstring();

	lstring &operator=( const lstring &rhs);
	lstring &operator+=( const lstring &rhs);
	lstring &operator+=( char ch);
	
	const char *c_str() const { return prx->str(); }
private:
	class sproxy
	{
	public:
		sproxy(const char *p) : rcnt(1), s(p) { }
		void incr() { ++rcnt; }
		int  decr() { return --rcnt; }
		int  cnt()  const { return rcnt; }
		const char *str() const { return s.c_str(); }
		void add( char ch) { s+=ch; }
		void add( const char *p) { s+=p; }
	private:
		sproxy(const sproxy& rhs);
		void operator=(const sproxy& rhs);
		int rcnt;
		std::string s;
	};

	void release();
	void get(sproxy* px);

	sproxy *prx;
};

lstring operator+( const lstring &s1, const lstring &s2);


#endif /* LSTRING_H */
