
#include <string>
#include "lstring.h"

lstring::lstring( const char *s)
{
	prx = new sproxy(s);
}
lstring::lstring( const lstring &rhs)
{
	get(rhs.prx);
}
lstring::~lstring()
{
	release();
}
lstring &lstring::operator=( const lstring &rhs)
{
	if ( this != &rhs )
	{
		release();
		get(rhs.prx);
	}
	return *this;
}
void lstring::release()
{
	if ( 0 == prx->decr() )
		delete prx;
}
void lstring::get(lstring::sproxy* px)
{
	prx = px;
	prx->incr();
}
lstring &lstring::operator+=( char ch)
{
	if ( prx->cnt() > 1 )
	{
		sproxy *ptemp = new sproxy(prx->str());
		release();
		prx = ptemp;
	}
	prx->add(ch);
	return *this;
}
lstring &lstring::operator+=( const lstring &s)
{
	if ( prx->cnt() > 1 )
	{
		sproxy *ptemp = new sproxy(prx->str());
		release();
		prx = ptemp;
	}
	prx->add(s.c_str());
	return *this;
}
lstring operator+( const lstring &s1, const lstring &s2)
{
	std::string s = std::string(s1.c_str())+std::string(s2.c_str());
	lstring sum( s.c_str() );
	return sum;
}

