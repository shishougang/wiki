#include <iostream>
#include "stack.h"

using namespace std;

int main()
{
    stack<double> d1(10);
    d1.push(3.14);    d1.push(4.14);    d1.push(5.14);
    cout << d1 << endl;
    stack<double> d2(d1);

    while ( ! d1.is_empty() )
        cout << "pop: " << d1.pop() << endl;

    d1.push(6.14);

    cout << d1 << endl;
    cout << d2 << endl;
    d1 = d2;   // !!
    cout << d1 << endl;
    return 0;
}




