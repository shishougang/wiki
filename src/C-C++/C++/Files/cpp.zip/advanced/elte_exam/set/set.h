#ifndef SET_H
#define SET_H


#include <vector>
#include <algorithm>


template <typename T>
class set
{
public:
    set& put( const T &t);
    set& del( const T &t);
    bool has( const T &t) const;

    bool is_empty() const;
    int  size() const;
    void print( std::ostream &os) const;

    set& operator+=( const T &t);
    set& operator+=( const set<T> &t);
private:
    std::vector<T> vec;
}; 
template <typename T>
set<T> operator+( const set<T> &t1,  const set<T> &t2);

template <typename T>
void set<T>::print( std::ostream &os) const
{
    for( vector<int>::const_iterator ci = vec.begin(); ci != vec.end(); ++ci)
        cout << *ci << ", ";
}

template <typename T>
set<T>& set<T>::put( const T &t)
{
    typename vector<T>::iterator i = find( vec.begin(), vec.end(), t);
    
    if ( vec.end() == i )   vec.push_back(t); 
    return *this;
}

template <typename T>
set<T>& set<T>::del( const T &t)
{
    typename vector<T>::iterator i = find( vec.begin(), vec.end(), t);
    
    if ( vec.end() != i )   vec.erase(i); 
    return *this;
}

template <typename T>
bool set<T>::has( const T &t) const
{
    return vec.end() != find( vec.begin(), vec.end(), t);
}

template <typename T>
bool set<T>::is_empty() const
{
    return 0 == size();
}

template <typename T>
int set<T>::size() const
{
    return vec.size();
}

template <typename T>
set<T>& set<T>::operator+=( const T &t)
{
    put(t);
    return *this;
}

template <typename T>
set<T>& set<T>::operator+=( const set<T> &t)
{
    vec.insert(vec.begin(), t.vec.begin(), t.vec.end());
    sort(vec.begin(), vec.end());
    typename vector<T>::iterator e = unique(vec.begin(), vec.end());
    vec.erase( e, vec.end());
    return *this;
}

template <typename T>
set<T> operator+( const set<T> &t1,  const set<T> &t2)
{
    set<T> result = t1;
    result += t2;
    return result;
}

    
#endif /* SET_H */

