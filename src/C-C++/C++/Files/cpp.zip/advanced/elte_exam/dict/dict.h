/* 
 *  dict:  T -> S map
 *  (C) Porkolab Zoltan, ELTE, Budapest, Hungary
 *  (C) 1998
 */

#include <map>

template <class T>
struct bad_index
{
    bad_index(const T& index) : m_index(index) { }
    T index() { return m_index; }
    T m_index;
};

template <class T, class S>
class dict
{
public:
    S    get( T t) const;
    void put( T t, S s);
    S&   operator[]( T t)  { S s = get(t); return m[t]; } 
    S    operator[]( T t) const  { return get(t); } 
private:
    typename std::map<T,S> m;
};

template <class T, class S>
void dict<T,S>::put(T t, S s)
{
    m[t] = s;
}

template <class T, class S>
S dict<T,S>::get(T t) const
{
    std::map<T,S>::const_iterator i = m.find(t);
    if( i != m.end() )
    {
        return i->second;
    }
    else
    {
        throw bad_index<T>(t);
    }
}
