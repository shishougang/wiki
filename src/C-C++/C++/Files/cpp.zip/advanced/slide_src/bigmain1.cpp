/*
 *  main.cc   - the client code for class Bigint
 *  (C) Porkolab Zoltan, ELTE, Budapest, Hungary
 *  (C) 1998
 */

#include <iostream>
#include "bigint.h"
#include "bigintcnt.h"

int main()
{
    int iMark(1);
    
/* 2-es
    Bigint b1("1999" "1999" "1999" "1999" "1999");
    iMark = (++b1)[4];	    // jobbrol 4-ik szamjegy int erteke
*/

/* 3-as
    Bigint b2("2000");
    Bigint b3 = b2;
    iMark += static_cast<int>(b3 - 1999);   // b3 erteke	
*/

/* 4-es
    Bigint *bip = new BigintCnt("9999");
    iMark += BigintCnt::get_cnt();   // hany BigintCnt objektum el
    delete bip;
    iMark -= BigintCnt::get_cnt();   // hany BigintCnt objektum el
*/
 
/* 5-os
    bip = new BigintCnt("5555");
    if ( bip->Bigint::mark_five() != 5 )
    {
	iMark = bip->mark_five();
    }
*/
    cout << "Your mark is " << iMark << endl;
    return 0;
}
