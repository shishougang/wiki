
/*
 *  Bigint
 *  (C) Porkolab Zoltan, ELTE, Budapest, Hungary
 *  (C) 1998
 */

class Bigint
{
    friend ostream& operator<<( ostream &os, const Bigint &bi);
public:
    Bigint( const char *s);
    Bigint( const Bigint &rhs);
    virtual ~Bigint();

    Bigint  &operator++();
    Bigint  &operator= ( const Bigint &rhs);
    int	    get_digit( int i) const; 
    int     operator[]( int i) const;
    double  get_value() const;
	    operator double() const;
    virtual int mark_five( int arg = 6 );
private:
    int	    size;
    char    *v;

    void    init( const char *s);
};
