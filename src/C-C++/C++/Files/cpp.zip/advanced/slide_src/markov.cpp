#include <iostream>
#include <deque>
#include <map>
#include <vector>
#include <string>

using namespace std;

typedef deque<string> Prefix;

const int nwords = 15000;
const int npref = 3;
char NONWORD[] = "\n";

typedef map<Prefix, vector<string> > tt;

tt statetab;

void add( Prefix& prefix, const string& s)
{
	if ( prefix.size() == npref )
	{
		statetab[prefix].push_back(s);
		prefix.pop_front();
	}
	prefix.push_back(s);
}
void build( Prefix& prefix, istream& in)
{
	string buf;

	while ( in >> buf )
		add( prefix, buf);
}
void generate(int nwords)
{
	Prefix prefix;
	int i;
	int len = 0;

	for ( i = 0; i < npref; ++i)
		add( prefix, NONWORD);

	for ( i = 0; i < nwords; ++i)
	{
		vector<string>& suf = statetab[prefix];
		const string& w = suf[rand() % suf.size()];

		if ( w == NONWORD )
			break;

		if ( len + w.size() > 70 )
		{
			cout << endl;
			len = 0;
		}
		cout << w << " ";
		len += w.size()+1;

		prefix.pop_front();
		prefix.push_back(w);
	}
}
int main()
{
	Prefix prefix;

	for ( int i = 0; i < npref; ++i)
		add( prefix, NONWORD);

	build( prefix, cin);
	add( prefix, NONWORD);
	generate(nwords);

	return 0;
}