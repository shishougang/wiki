class BigintCnt : public Bigint
{
public:
    BigintCnt( const char *s) : Bigint(s) { ++cnt; }
    BigintCnt( const Bigint &rhs) : Bigint(rhs) { ++cnt; }
    ~BigintCnt() { --cnt; }
    static int get_cnt() { return cnt; }
    int mark_five( int arg = 5 )  { return arg - 1; }
private:
    static int cnt;
};
int BigintCnt::cnt = 0;
