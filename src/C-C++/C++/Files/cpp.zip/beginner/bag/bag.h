
#ifndef BAG_H
#define BAG_H

template <typename T>
struct node
{
	node() : cnt(0) { }
	node( const T& x, int i=1) { t = x; cnt = i; }
	T	t;
	int	cnt;
};

template <typename T>
class bag
{
public:
		bag( int sz = 10);
		~bag();
		bag( const bag& rhs);
	bag& operator=( const bag& rhs);

	int	mul( const T& t) const;
	bool	put( const T& t);
	bool	remove( const T& t);
	bool	remove_all( const T& t);
private:
	int		capacity;
	node<T> *v;

	void copy( const bag& rhs);
	int  find( const T& t) const;
	int  find();
};

template <typename T>
bag<T>::bag( int sz) : capacity(sz), v(new node<T>[capacity]) { }

template <typename T>
bag<T>::~bag() { delete [] v; }

template <typename T>
bag<T>::bag( const bag& rhs) : capacity(rhs.capacity), v(new node<T>[capacity]) 
{ 
    copy(rhs);
}

template <typename T>
bag<T>& bag<T>::operator=( const bag& rhs)
{
	if ( this != &rhs )
	{
		delete [] v;
		v = new node<T>[capacity=rhs.capacity];
		copy(rhs);
	}
	return *this;
}

template <typename T>
void bag<T>::copy( const bag& rhs)
{
	for( int i = 0; i < capacity; ++i)
		v[i] = rhs.v[i];
}

template <typename T>
int bag<T>::find( const T& t) const
{
	for ( int i = 0; i < capacity; ++i)
	{
		if ( 0 < v[i].cnt  &&  t == v[i].t )
			return i;
	}
	return capacity;
}

template <typename T>
int bag<T>::find()
{
	for ( int i = 0; i < capacity; ++i)
		if ( 0 == v[i].cnt )
			return i;
	return capacity;
}

template <typename T>
bool bag<T>::put( const T& t)
{
	
	int i = find(t);
	
	if ( i < capacity )
		return ++v[i].cnt;
	else 
	{
		i = find();
		if ( capacity == i )
			return false;
		else
		{
			v[i].t = t;
			v[i].cnt++;
			return true;
		}
	}
}

template <typename T>
int bag<T>::mul( const T& t) const
{
    int i = find(t);

	return  capacity == i ? 0 : v[i].cnt;
}

template <typename T>
bool bag<T>::remove( const T& t)
{
    int i = find(t);

	return  capacity == i ? 0 : v[i].cnt--;
}

template <typename T>
bool bag<T>::remove_all( const T& t)
{
    int i = find(t);

	return  capacity == i ? false : (v[i].cnt=0, true);
}


#endif /* BAG_H */

