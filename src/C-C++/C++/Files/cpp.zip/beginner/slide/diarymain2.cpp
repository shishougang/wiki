#include <iostream>
#include "diary2.h"

using namespace std;

int main()
{
    diary d1( "Tanfolyam kezdete", 2000, 6, 19);
    diary d2( "Tanfolyam vege", 2000, 6, 27);
    diary d3( "Pihenes", 2000, 6, 28);

    d2.append(&d1);
    d3.append(&d2);

    list l;
    l.insert(&d3);

    for ( list *lp = &d1; lp; lp = lp->get_next() )
    {
         cout << *lp;
         cout << endl;
    }
    return 0;
}

/* output:
[ id = 0 ], [ 2000, 6, 19 ], Tanfolyam kezdete
[ id = 1 ], [ 2000, 6, 27 ], Tanfolyam vege
[ id = 2 ], [ 2000, 6, 28 ], Pihenes
*/



