/* simple hello in C */
#include <stdio.h>

int main()
{
    fprintf( stdout, "Hello world\n");
    return 0;
}
