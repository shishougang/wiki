// simple hello in C++
#include <iostream>

int main()
{
    std::cout.put(65).put(10);
    return 0;
}
