
#include <iostream>
#include <fstream>
//#include <ios>
#include <iomanip>
#include <cctype>

using namespace std;

void hd( istream&, ostream& );
void printline( ostream&, long, char*, int);

const int char_in_line = 16;

int main( int argc, char *argv[])
{
    int retval = 0;

    if ( argc < 2 )
	hd( cin, cout);
    else
	for ( int i = 1; i < argc; ++i )
	{
            ifstream inp(argv[i]);
            if ( !inp )
	    {
	        cerr << "Can't open file " << argv[i] << " for read" << endl;
	        ++retval;
	    }
	    else
	    {
	        hd( inp, cout);
	    }
	}
	return 0;
}

void hd( istream& inp, ostream& outp)
{
    char buffer[char_in_line];
    long addr = 0L;
    int cnt = 0;

//	inp.unsetf(ios_base::skipws);

    while ( inp.get(buffer[cnt++]) )
    {
 	if ( 16 == cnt )
	{
            printline( outp, addr, buffer, cnt);
	    addr += cnt;
	    cnt = 0;
	}
    }
    printline( outp, addr, buffer, cnt);
}

void printline( ostream& out, long addr, char *buffer, int cnt)
{
    if ( 0 == cnt )
	return;
	
    out << hex << setw(8) << setfill('0') << addr << "   ";
    for ( int i = 0; i < cnt; ++i)
	out << ' ' << setw(2) << setfill('0') 
	    << hex << (buffer[i] & 0xff);
    for ( int i = cnt; i < char_in_line; ++i)
	out << "   ";
    out << "   ";    
    for ( int i = 0; i < cnt; ++i)
	out << (isgraph(buffer[i]) ? buffer[i] : '.');
    out << endl;					
}


