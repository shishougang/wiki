/* converts from Fahrenheit to Celsius 
 * 3rd try
 *
 * */
#include <stdio.h>

#define LOWER	0
#define UPPER	200
#define STEP	40

int main()
{
    int fahr;

    for ( fahr = LOWER; fahr <= UPPER; fahr += STEP )
    {
        fprintf( stdout, "F = %d\tC = %f\n", fahr, 5./9*(fahr-32));
    }    
    return 0;
}
