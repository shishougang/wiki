
#include <iostream>
#include <string>

int main()
{
   int cnt = 0;
   std::string ch;

   while ( std::cin >> ch )
   {
      ++cnt;
   }
   std::cout << cnt << std::endl;
   return 0;
}
