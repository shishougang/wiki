/* copying stdin to stdout */

#include <stdio.h>

int main()
{
    int ch; /* this is important */

    while ( (ch = getchar()) != EOF)
    {
        putchar(ch);
    }
    return 0;
}

