#ifndef LIST_H
#define LIST_H

#include <iostream>

class list
{
public:
         list();
         ~list();

    list *remove();
    void  append(list *lp);
    void  insert(list *lp);
    list *get_next() const { return next; }
    list *get_prev() const { return prev; }

    void print( std::ostream& os) const; 

    static int get_nid() { return nid; }
private:
    const int  id;
          list *next;
          list *prev;

    static int nid;

    list( const list &rhs);
    list operator=( const list *rhs);
};

std::ostream& operator<<( std::ostream&, const list&);

#endif /* LIST_H */


