// copying cin to cout 
// converting lowercase to uppercase
// 1st version

#include <iostream>

using namespace std;

int main()
{
    char ch;   // this is important

    while ( cin.get(ch) )
    {
         cout << ('a' <= ch && ch <= 'z' ?  ch - 'a'+'A' : ch);
    }
    return 0;
}
