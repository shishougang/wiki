// copying cin to cout 
// converting lowercase to uppercase
// 2nd version

#include <iostream>

using namespace std;

int main()
{
    char ch;   // this is important

    while ( cin.get(ch) )
    {
         cout << static_cast<char>('a'<=ch && ch<='z' ?  ch-'a'+'A' : ch);
    }
    return 0;
}
