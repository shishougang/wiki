#include <iostream>
#include "matrixe.h"
#include "date.h"

using namespace std;

int main()
{
    date          d(2001,1,1);
    matrix<date>  md(52,7);

    for ( int i = 0; i < md.rows(); ++i )
        for ( int j = 0; j < md.cols(); ++j )
            md( i, j ) = d++;

    int week, day;
    while ( cin >> week >> day )
    try
    {
        cout << md.at( --week, --day ) << endl;
    }
    catch( matrixError me )
    {
        cerr << me.reason << endl;
    }
    return 0;
}


