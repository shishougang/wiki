// converts from Fahrenheit to Celsius 
#include <iostream>

using namespace std;

inline double fahr2cels( double f)
{
    return 5./9*(f-32);
}
int main()
{
    const int lower = 0;
    const int upper = 200;
    const int step  = 40;

    for ( int fahr = lower; fahr <= upper; fahr+=step )
    {
        cout << "F = " << fahr << '\t' << "C = " << fahr2cels(fahr) << endl;
    }    
    return 0;
}
