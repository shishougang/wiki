// copying cin to cout 
// 2nd version

#include <iostream>

using namespace std;

int main()
{
    char ch;   // this is important

    // cin >> noskipws;
    // while ( cin >> ch )
    while ( cin.get(ch) )
    {
         cout.put(ch);  // or: cout << ch
    }
    return 0;
}
