#ifndef DIARY_H
#define DIARY_H

#include <iostream>
#include <string>
#include "list2.h"
#include "date.h"

class diary : public list, public date
{
public:
    diary( char *e, int y=2000, int m=1, int d=1);
    diary( char *d, char *e);
    diary( date dd, char *e);

    diary( const diary& rhs);
    const diary& operator=( const diary& rhs);

    void print( std::ostream& os) const;
private:
    std::string event;
};

std::ostream& operator<<( std::ostream& os, const diary& d);

#endif /* DIARY_H */

