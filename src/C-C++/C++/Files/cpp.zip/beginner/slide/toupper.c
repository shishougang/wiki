/* copying stdin to stdout, 
 * converting lowercase to uppercase 
 */

#include <stdio.h>

int main()
{
    int ch; /* this is important */

    while ( (ch = getchar()) != EOF)
    {
        putchar('a' <= ch && ch <= 'z' ?  ch - 'a'+'A' : ch);
    }
    return 0;
}

