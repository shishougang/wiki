#include <iostream>
#include "diary1.h"

using namespace std;

int main()
{
    diary d1( "Tanfolyam kezdete", 2000, 6, 19);
    diary d2( "Tanfolyam vege", 2000, 6, 27);
    diary d3( "Pihenes", 2000, 6, 28);

    d2.append(&d1);
    d3.append(&d2);

//  for ( diary *dp = &d1; dp; dp = dp->get_next() ) // syntax error!
    for ( list *lp = &d1; lp; lp = lp->get_next() ) 
    {
         cout << *lp;
         cout << endl;
    }
    return 0;
}
