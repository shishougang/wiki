#include <iostream>
#include "diary1.h"

using namespace std;

diary::diary( char *e, int y, int m, int d) : date(y,m,d), event(e) { }

diary::diary( char *d, char *e) : date(d), event(e) { }

diary::diary( date dd, char *e) : date(dd), event(e) { }

void diary::print( ostream& os) const
{
    list::print(os);   
    os << ", ";
    date::print(os);
    os << ", ";
    os << event;
}
ostream& operator<<( ostream& os, const diary& d) // no cpy constr
{
    d.print(os);
    return os;
}


