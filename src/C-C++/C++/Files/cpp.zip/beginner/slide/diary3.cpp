#include "diary3.h"

using namespace std;

diary::diary( char *e, int y, int m, int d) : date(y,m,d), event(e) { }

diary::diary( char *d, char *e) : date(d), event(e) { }

diary::diary( date dd, char *e) : date(dd), event(e) { }

diary::diary( const diary& rhs) : date(rhs), event(rhs.event) { }

const diary& diary::operator=( const diary& rhs)
{
    date::operator=(rhs);
    event = rhs.event;
    return *this;
}

void diary::print( ostream& os) const
{
    list::print(os);
    os << ", ";
    os << date(*this);
    os << ", ";
    os << event;
}
ostream& operator<<( ostream& os, const diary& d)
{
    d.print(os);
    return os;
}


