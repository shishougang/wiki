// sorting integers by binary tree 
// using reference
// and constructor

#include <iostream>

using namespace std;

struct node
{
         node( int v);
    void print() const;

    int   val;
    node *left;
    node *right;
};
node::node( int v)        // the constructor
{
//    node *np = new node;
    left = right = 0;
    val = v;

//    return np;
}
void node::print() const	// a const member function
{
    cout << val << " "; 
}

void insert( node *&r, int v);	// insert into (sub)tree
void print( node *r);		// print (sub)tree

int main()
{
    node *root = 0;
    int   i;
    
    while ( cin >> i )
    {
        insert( root, i);
    }
    print( root);
    return 0;
}
void print( node *r)
{
    if ( r )
    {
        print( r->left);
//	  cout << r->val << " ";
        r->print();
	print( r->right);
    }
}
void insert( node *&r, int v)
{
    if ( r )
    {
        insert( v < r->val ? r->left : r->right, v);
    }
    else
    {
//        r = make_node(v);
        r = new node(v);
    }
}
