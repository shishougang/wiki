// sorting integers by binary tree 
// using reference

#include <iostream>

using namespace std;

struct node
{
    int   val;
    node *left;
    node *right;
};

void insert( node *&r, int v);	// insert into (sub)tree
void print( node *r);		// print (sub)tree

int main()
{
    node *root = 0;	// in C: NULL == (void *)0
    int   i;
    
    while ( cin >> i )
    {
        insert( root, i);
    }
    print( root);
    return 0;
}
void print( node *r)
{
    if ( r )
    {
        print( r->left);
	cout << r->val << " ";
	print( r->right);
    }
}
void insert( node *&r, int v)
{
    if ( r )
    {
        insert( v < r->val ? r->left : r->right, v);
    }
    else
    {
        r = new node;
	r->left = r->right = 0;
	r->val = v;
    }
}
