#include "diary2.h"

using namespace std;

diary::diary( char *e, int y, int m, int d) : date(y,m,d), event(e) { }

diary::diary( char *d, char *e) : date(d), event(e) { }

diary::diary( date dd, char *e) : date(dd), event(e) { }

void diary::print( ostream& os) const
{
/*
    const list *lp = this;   // still polymorph
    list l = *this;          // no cpy constr or operator=
    const date *dp = this;

    os << *lp << ", ";
    os << *dp << ", ";
    os << event;
*/
    list::print(os);
//  os << ", " << list(*this);  no cpy constr
    os << ", " << date(*this);
    os << ", " << event;
}
ostream& operator<<( ostream& os, const diary& d)
{
    d.print(os);
    return os;
}


