#include <iostream>
#include "diary3.h"

using namespace std;

int main()
{
    diary d1( "Tanfolyam kezdete", 2000, 6, 19);
    diary d2( "Tanfolyam vege", 2000, 6, 27);
    diary d3( "Pihenes", 2000, 6, 28);

    d2.append(&d1);
    d3.append(&d2);

    for ( list *lp = &d1; lp; lp = lp->get_next() )
    {
         cout << *lp;
         cout << endl;
    }
    
    // step 3.
    diary d4( "Test1");
    diary d5(d2);  // no default cpy constr  
    d4 = d3;       // no default operator=
    cout << d4 << endl;
    cout << d5 << endl;

    return 0;
}

/* output:
[ id = 0 ], [ 2000, 6, 19 ], Tanfolyam kezdete
[ id = 1 ], [ 2000, 6, 27 ], Tanfolyam vege
[ id = 2 ], [ 2000, 6, 28 ], Pihenes
[ id = 3 ], [ 2000, 6, 28 ], Pihenes
[ id = 4 ], [ 2000, 6, 27 ], Tanfolyam vege
*/



