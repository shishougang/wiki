
#include <iostream>
using namespace std;

int &f( int t[], int len)
{
    for( int i = 0; i < len; ++i)
        if ( t[i]%2 )
            return t[i];
    return t[0];
}

int main()
{
    int tt[] = { 2, 4, 6, 7, 8, 10};
    for ( int i = 0; i < sizeof(tt)/sizeof(tt[0]); ++i)
        cout << tt[i] <<", ";
    cout << endl;

    f(tt,sizeof(tt)/sizeof(tt[0])) = 99;

    for ( int i = 0; i < sizeof(tt)/sizeof(tt[0]); ++i)
        cout << tt[i] <<", ";
    cout << endl;
}
