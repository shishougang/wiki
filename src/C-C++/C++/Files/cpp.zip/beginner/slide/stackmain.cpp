#include <iostream>

#include "stack.h"
#include "date.h"

using namespace std;

int main()
{
    stack<int> d1(10);
    d1.push(3);    
    d1.push(4);    
    d1.push(5);
    cout << d1 << endl;

    date d;
    stack<date> d2(5);
    d2.push(date(2000,6,23));
    d2.push(d);
    
    cout << d1 << endl;
    cout << d2 << endl;
    return 0;
}




