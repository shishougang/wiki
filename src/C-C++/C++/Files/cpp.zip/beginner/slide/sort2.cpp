// sorting integers by binary tree 
// working, but _ugly_

#include <iostream>

using namespace std;

struct node
{
    int   val;
    node *left;
    node *right;
};

void insert( node **rp, int v);	// insert into (sub)tree
void print( node *r);		// print (sub)tree

int main()
{
    node *root = 0;	// in C: NULL == (void *)0
    int   i;
    
    while ( cin >> i )
    {
        insert( &root, i);
    }
    print( root);
    return 0;
}
void print( node *r)
{
    if ( r )
    {
        print( r->left);
	cout << r->val << " ";
	print( r->right);
    }
}
void insert( node **rp, int v)
{
    if ( *rp )
    {
        insert( v < (*rp)->val ? &(*rp)->left : &(*rp)->right, v);
    }
    else
    {
        *rp = new node;
	(*rp)->left = (*rp)->right = 0;
	(*rp)->val = v;
    }
}
