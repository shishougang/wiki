// _naive_ dstack client

#include <iostream>
#include "dstack1.h"

using namespace std;

int main()
{
    dstack d1(10);
    d1.push(3.14);    d1.push(4.14);    d1.push(5.14);
    cout << d1 << endl;
    dstack d2(d1); // same as: dstack d2 = d1;

    while ( ! d1.is_empty() )
        cout << "pop: " << d1.pop() << endl;

    cout << d1 << endl;
    cout << d2 << endl;
    return 0;
}




