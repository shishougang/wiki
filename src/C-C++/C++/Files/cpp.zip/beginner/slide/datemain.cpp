#include <iostream>
#include "date.h"

using namespace std;

int main()
{
    date d;
    while ( cin >> d )
    {
        cout << (d+=40) << endl;
    }
    return 0;
}
