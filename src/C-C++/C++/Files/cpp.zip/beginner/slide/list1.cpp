#include <iostream>
#include "list1.h"

using namespace std;

int list::nid = 0;

list::list() : id(nid), prev(0), next(0)
{
    ++nid;
}

list::~list()
{
    remove();
}

list *list::remove() 
{ 
    if ( prev ) prev->next = next; 
    if ( next ) next->prev = prev; 
    next = prev = 0; 
    return this;
}

void list::append( list *lp) 
{ 
    next = lp->next; 
    lp->next = this; 
    prev = lp; 
    if ( next ) next->prev = this; 
}

void list::insert( list *lp) 
{ 
    prev = lp->prev; 
    lp->prev = this; 
    next = lp; 
    if ( prev ) prev->next = this; 
}

void list::print( ostream& os) const
{
    os << "[ id = " << id << " ]";
}

ostream& operator<<( ostream& os, const list &l)
{
    l.print(os);
    return os;
}



