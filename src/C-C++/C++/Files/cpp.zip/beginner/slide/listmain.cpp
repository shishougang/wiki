#include <iostream>
#include "list1.h"

using namespace std;

int main()
{
    cout << "# = " << list::get_nid() << endl;
    list l1, l2, l3, l4;

    l2.append(&l1);
    l3.insert(&l2);
    l4.append(&l3);

    for( list *lp = &l1; lp; lp = lp->get_next() )
        cout << *lp << endl;

    cout << "# = " << list::get_nid() << endl;
    return 0;
}


