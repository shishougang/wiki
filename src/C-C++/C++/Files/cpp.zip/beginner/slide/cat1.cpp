// copying cin to cout 
// 1st version

#include <iostream>

using namespace std;

int main()
{
    char ch;   // this is important

    while ( cin >> ch )
    {
         cout << ch;
    }
    return 0;
}
