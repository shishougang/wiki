#include "allocator.h"
#include <iostream>
#include <vector>

int main() {
  std::vector<int, Allocator<int, StandardAllocPolicy<int> > > v;
  v.push_back(10);
  std::cout << v.size() << std::endl;
  std::cout << v[0] << std::endl;

  std::vector<int, Allocator<int, TrackAllocPolicy<int> > > v_track;
  for (int i = 10; i < 30; ++i) {
    v_track.push_back(i);
  }
  std::cout << v_track.size() << std::endl;
  std::cout << static_cast<unsigned long>(v_track.get_allocator().CurrentAllocations()) << std::endl;
  std::cout << static_cast<unsigned long>(v_track.get_allocator().TotalAllocations()) << std::endl;
  std::cout << static_cast<unsigned long>(v_track.get_allocator().PeakAllocations()) << std::endl;
  return 0;
}
