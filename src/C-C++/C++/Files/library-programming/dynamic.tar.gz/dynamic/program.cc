
#include "filter.h"
#include "low_pass_filter.h"
using namespace std;
int main() {
  Filter* filter = new LowPassFilter();
  filter->process(10);
  return 0;
}
