#ifndef FILTER_H_
#define FILTER_H_

class Filter {
 public:
  virtual void process(int v) = 0;
};

#endif  // FILTER_H_
