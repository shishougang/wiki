
#include <iostream>
using namespace std;
#include "low_pass_filter.h"

void LowPassFilter::process(int v) {
  cout << "Low Pass Filter value = " << v << endl;
}
