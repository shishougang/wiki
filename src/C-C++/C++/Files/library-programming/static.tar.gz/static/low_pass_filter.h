#ifndef LOW_PASS_FILTER_H_
#define LOW_PASS_FILTER_H_
#include "filter.h"

class LowPassFilter : public Filter {
 public:
  virtual void process(int v);
};

#endif  // LOW_PASS_FILTER_H_
