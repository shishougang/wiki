#include <stdio.h>
#include <stdlib.h>
//#include "dd_settings.h"
//#include "dd_settings.pp"
#include "dd_data_dictionary.h"

struct Node{
    int oid;
    int x, y;
};    
struct HashTableEntry{
    struct Node *node;
    int idx;
};
void copyFunction(void * source, void * target){
    target = source;
}


int main(int argc, char ** argv){
  dd_dictionary objects;
  int i;
  objects = dd_new_dictionary();
  dd_set_object_copy_function_for_dictionary(objects, copyFunction); // setting copy function
   
  struct HashTableEntry* hte = malloc(sizeof(struct HashTableEntry));
    hte->idx = 1;
    hte->node = NULL;
    i = 1;
    dd_add_object_for_key(objects, (char *)i, (void*)hte);
    
    struct HashTableEntry* hte2 = malloc(sizeof(struct HashTableEntry)); 
    hte2->idx = 2;
    struct Node n;
    n.oid = 10; n.x = 10; n.y = 10;
    hte2->node = &n;
    i = 2;
    dd_add_object_for_key(objects, (char *)i, (void*)hte2);


     struct HashTableEntry* ret = (struct HashTableEntry *) dd_object_for_key(objects, 1, false);
    if(ret != NULL){
      printf("hte.idx:%d, node: %d\n", ret->idx, ret->node);
    }
    dd_remove_object_for_key(objects, 1);
    dd_remove_object_for_key(objects, 2);
    free(hte); free( hte2); 
     dd_dispose_dictionary(objects);
    return 0;
}


