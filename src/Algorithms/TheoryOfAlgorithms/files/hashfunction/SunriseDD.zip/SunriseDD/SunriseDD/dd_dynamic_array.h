/*
 *  dd_dynamic_array.h
 *  SunriseDD
 *
 *  Created by Benjamin Kowarsch on 7/9/07.
 *  Copyright 2007 __MyCompanyName__. All rights reserved.
 *
 */

#include "dd_types.h"
#include "dd_status_codes.h"

typedef void* dd_array;

dd_array dd_new_array();

dd_array dd_new_array_with_capacity(cardinal capacity);


dd_status dd_set_object_at_index(dd_array array, void* object, cardinal index);

void* dd_object_at_index(dd_array array, cardinal index);

dd_status dd_remove_object_at_index(dd_array array, cardinal index);

cardinal object_count_for_array(dd_array array);


dd_status dd_dispose_array();