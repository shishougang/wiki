#include <linux/module.h>	
#include <linux/kernel.h>	
#include <linux/init.h>
#include <linux/sched.h>
#include <linux/interrupt.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("tasklet examples");

void tasklet_func(unsigned long arg) {
  printk(KERN_INFO "tasklet function %lu", arg);
}
DECLARE_TASKLET(task_test1, tasklet_func, 1);
DECLARE_TASKLET_DISABLED(task_test2, tasklet_func, 2);

static int __init tasklet_example_init(void) {
  printk(KERN_INFO "the state of task1 is %ld and count is %d\n",
         task_test1.state, task_test1.count);
  printk(KERN_INFO "the state of task2 is %ld and count is %d\n",
         task_test2.state, task_test2.count);
  printk(KERN_INFO "enable task2\n");
  tasklet_enable(&task_test2);
  printk(KERN_INFO "after enable, the state of task2 is %ld and count is %d\n",
         task_test2.state, task_test2.count);
  printk(KERN_INFO "schedule tasklets\n");
  tasklet_schedule(&task_test1);
  tasklet_schedule(&task_test2);
  printk(KERN_INFO "the state of task1 is %ld and count is %d\n",
         task_test1.state, task_test1.count);
  printk(KERN_INFO "the state of task2 is %ld and count is %d\n",
         task_test2.state, task_test2.count);
  return 0;
}

static void __exit tasklet_example_exit(void) {
  printk(KERN_INFO "tasklet exit\n");
}
module_init(tasklet_example_init);
module_exit(tasklet_example_exit);
