#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/kthread.h>
#include <linux/delay.h>
#include <linux/sched.h>

MODULE_LICENSE("GPL");
MODULE_DESCRIPTION("kthread examples");


static struct task_struct *task0;
static struct task_struct *task1;

struct Data {
  int cpu;
};

static struct Data data0;
static struct Data data1;
static int stop;

static int thread0_func(void *arg) {
  struct Data* data = (struct Data*)(arg);
  while(!kthread_should_stop()  && !stop) {
    printk("%s(): on cpu:%d, data_cpu:%d, pname:%s\n",\
           __func__, smp_processor_id(), data->cpu, current->comm);
    msleep_interruptible(10);
  }
  return 0;
}

static int thread1_func(void *arg) {
  struct Data* data = (struct Data*)(arg);
  while(!kthread_should_stop()  && !stop) {
    printk("%s(): on cpu:%d, data_cpu:%d,  pname:%s\n",         \
           __func__, smp_processor_id(), data->cpu, current->comm);
    msleep_interruptible(10);
  }
  return 0;
}

static int __init test_kthread_init(void) {
  stop = 0;
  data0.cpu = 0;
  data1.cpu = 1;

  task0 = kthread_run(thread0_func, (void*)(&data0), "thread1");
  if (IS_ERR(task0)) {
    printk("creat thread0 error, exit.\n");
    return -EFAULT;
  }
  kthread_bind(task0, data0.cpu);

  task1 = kthread_create(thread1_func, (void*)(&data1), "thread2");
  if (IS_ERR(task1)) {
    printk("creat thread1 error, exit.\n");
    return -EFAULT;
  }
  kthread_bind(task1, data1.cpu);
  wake_up_process(task1);
  return 0;
}

static void __exit test_kthread_exit(void) {
  stop = 1;
  kthread_stop(task0);
  kthread_stop(task1);
}

module_init(test_kthread_init);
module_exit(test_kthread_exit);
  
