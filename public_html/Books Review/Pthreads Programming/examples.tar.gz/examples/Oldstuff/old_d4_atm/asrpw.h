/* asrpw.h
 * 
 * Include file for server password module for atm example program.
 *
 */

void server_password_init(int);
int  check_server_password(int);
int  set_server_password(int, int);

