package Question7_2;

class Fresher extends Employee {
    public Fresher() {
        super(0);
    }
}
