package Question7_2;

class TechLead extends Employee {
    public TechLead() {
        super(1);
    }
}
