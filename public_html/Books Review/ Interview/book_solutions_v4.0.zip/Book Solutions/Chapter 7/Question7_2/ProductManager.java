package Question7_2;

class ProductManager extends Employee {
    public ProductManager() {
        super(2);
    }
}
