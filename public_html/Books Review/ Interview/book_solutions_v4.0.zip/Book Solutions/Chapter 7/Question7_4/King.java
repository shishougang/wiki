package Question7_4;

public class King extends ChessPieceBase {
	void estimationParameter0() { };
	int estimationParameter1() { return 0; }
	boolean canBeChecked() { return false; }
	boolean isSupportCastle() { return false; }
}
