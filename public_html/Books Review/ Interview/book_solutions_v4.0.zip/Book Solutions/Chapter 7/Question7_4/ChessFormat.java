package Question7_4;

//include info about timing, etc.
public class ChessFormat {
	
}
