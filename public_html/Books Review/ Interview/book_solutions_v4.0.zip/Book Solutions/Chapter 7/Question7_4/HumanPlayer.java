package Question7_4;

public class HumanPlayer extends PlayerBase {
	public ChessPieceTurn getTurn(Position p) { return null; }
}
