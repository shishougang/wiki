package Question7_4;

public abstract class PositionPotentialValue {
	/* compares value of potential game position */
	abstract boolean lessThan(PositionPotentialValue pv);
}

