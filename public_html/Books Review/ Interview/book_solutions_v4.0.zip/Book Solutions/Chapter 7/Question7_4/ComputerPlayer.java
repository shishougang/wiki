package Question7_4;

class ComputerPlayer extends PlayerBase {
	public ChessPieceTurn getTurn(Position p) { return null; }
	public void setDifficulty() { };
	public PositionEstimator estimater;
	public PositionBackTracker backtracter;
}

