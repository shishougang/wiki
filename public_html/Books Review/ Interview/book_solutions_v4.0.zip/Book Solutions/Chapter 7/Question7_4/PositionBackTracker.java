package Question7_4;

public class PositionBackTracker {
	// get next position for estimation.
	public static Position getNext(Position p) { return null; }
}
