package Question7_4;

public class GameManager { // keeps track of time, end of the game, etc
	void processTurn(PlayerBase player) { };
	boolean acceptTurn(ChessPieceTurn turn) { return true; };

	Position currentPosition;
	ChessFormat format;
	public void setGameLog(String filePath) { };
}

