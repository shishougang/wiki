package Question7_4;

import java.util.ArrayList;

public class Position { // represents chess positions in compact form
	ArrayList<ChessPieceBase> black;
	ArrayList<ChessPieceBase> white;
}

