package Question7_4;

public class PositionEstimator {
	// calculate value of a position
	public static PositionPotentialValue estimate(Position p) { return null; }
}

