package Question7_4;

public abstract class PlayerBase {
	public abstract ChessPieceTurn getTurn(Position p);
}

