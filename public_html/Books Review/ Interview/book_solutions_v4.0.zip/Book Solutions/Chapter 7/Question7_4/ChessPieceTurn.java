package Question7_4;

public class ChessPieceTurn {
	
};
