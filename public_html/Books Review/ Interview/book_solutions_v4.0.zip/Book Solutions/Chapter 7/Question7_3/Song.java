package Question7_3;

public class Song {
	private String songName;
	public String toString() { return songName; }
}
