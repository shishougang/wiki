package Question3_1;

class StackNode {
	public int previous;
	public int value;
	public StackNode(int p, int v){
		value = v;
		previous = p;
	}
}
