package Question18_4;

class Resource {
	long id;

	public Resource(long id){
		this.id = id;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}
}
