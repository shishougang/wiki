package Question11_2;

import java.util.ArrayList;

public class Machine {
	public ArrayList<Person> persons = new ArrayList<Person>();
	public int machineID;
}
