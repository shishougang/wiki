package Question11_2;

import java.util.ArrayList;

public class Server {
	ArrayList<Machine> machines = new ArrayList<Machine>();
}
