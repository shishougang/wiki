        #ifndef DSEXCEPTIONS_H_
        #define DSEXCEPTIONS_H_

        class Underflow { };
        class Overflow  { };
        class OutOfMemory { };
        class BadIterator { };

        #endif
