#include <cassert>
#include <leveldb/db.h>
#include <iostream>
#include <string>
using namespace std;

int main() {
  leveldb::DB* db;
  leveldb::Options options;
  options.create_if_missing = true;
  leveldb::Status status = leveldb::DB::Open(options, "/tmp/testdb", &db);
  assert(status.ok());
  string key = "foo";
  string value = "bar";
  cout << "write Key:" << key << " and value:" << value << endl;
  status = db->Put(leveldb::WriteOptions(), key, value);
  assert(status.ok());
  string value_back;
  status = db->Get(leveldb::ReadOptions(), key, &value_back);
  cout << "Read back:" << value_back << endl;
  assert(status.ok());
  assert(value == value_back);
  delete db;
  return 0;
}
  
