#include "OutOfRangeExc.h"

OutOfRangeExc::OutOfRangeExc()
{
}
