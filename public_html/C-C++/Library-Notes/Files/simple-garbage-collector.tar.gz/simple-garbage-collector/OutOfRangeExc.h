#ifndef OUT_OF_RANGE_EXC_H
#define OUT_OF_RANGE_EXC_H

class OutOfRangeExc {
      public:
            OutOfRangeExc();
};

#endif // OUT_OF_RANGE_EXC_H
