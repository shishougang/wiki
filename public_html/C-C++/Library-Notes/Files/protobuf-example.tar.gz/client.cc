#include <string.h>  // for bzero
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <netdb.h>
#include <string>
#include <cstdlib>
#include <iostream>
#include <google/protobuf/message_lite.h>
#include "person.pb.h"
using namespace std;


void error(const char *msg) {
  perror(msg);
  exit(1);
}

#define SERVER_PORT 9999

int main() {
  int client_socket = socket(AF_INET, SOCK_STREAM, 0);
  if (client_socket < 0) {
    error("Open socket failed");
  }
  struct sockaddr_in server_addr;
  bzero(&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = inet_addr("127.0.0.1");
  server_addr.sin_port = htons(SERVER_PORT);

  if (connect(client_socket, (struct sockaddr *) &server_addr,
  	sizeof(server_addr)) == 0)  {
  	char buf[1024];
  	int count = read(client_socket, buf, 1024);
  	example::Person person;
  	person.ParseFromArray(buf, count);
  	cout << "name:" << person.name() << endl;
  	cout << "id:" << person.id() << endl;
  	cout << "email:" << person.email() << endl;
  }
}



