#include <string.h>  // for bzero
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <string>
#include <cstdlib>
#include <iostream>
#include <google/protobuf/message_lite.h>
#include "person.pb.h"
using namespace std;

#define SERVER_PORT 9999
#define LISTEN_COUNT 5

void error(const char *msg) {
  perror(msg);
  exit(1);
}

int main() {
  struct sockaddr_in server_addr;
  bzero(&server_addr, sizeof(server_addr));
  server_addr.sin_family = AF_INET;
  server_addr.sin_addr.s_addr = htons(INADDR_ANY);
  server_addr.sin_port = htons(SERVER_PORT);
  int server_socket = socket(AF_INET, SOCK_STREAM, 0);
  if (server_socket < 0) {
    error("Open socket failed");
  }
  int enable = 1;
  if (setsockopt(server_socket, SOL_SOCKET, SO_REUSEADDR, &enable,
                 sizeof(enable)) < 0) {
    error("setsockopt(SO_REUSEADDR) failed");
  }
  if (bind(server_socket, (struct sockaddr *)&server_addr,
           sizeof(server_addr)) < 0) {
    error("Server bind port failed");
  }
  listen(server_socket, LISTEN_COUNT);
  while (true) {
    struct sockaddr_in client_addr;
    int new_socket = accept(server_socket, 0, 0);
    if (new_socket < 0) {
      error("Server accept failed");
    }
    
    example::Person person;
    person.set_name("example");
    person.set_id(1);
    person.set_email("example@gmail.com");

    int len = person.ByteSize();
    char *buffer = new char[len];
    person.SerializeToArray(buffer, len);
    if (write(new_socket, buffer, len) < 0) {
      delete buffer;
      cout << "Send Failed" << endl;
      break;
    }
    close(new_socket);
    delete buffer;
  }
  close(server_socket);
  return 0;

    }
      
