
#include <iostream>

template <typename R, typename T, typename S>
R max( T x, S y, R)
{
  if ( x > y )
    return x;
  else
    return y;
}

int main()
{
  int i = 3;
  double d = 3.14;

  std::cout << "max( d, i, 0.0 ) = "  << max( d, i, 0.0) << std::endl; 
  std::cout << "max( i, d, 0.0 ) = "  << max( i, d, 0.0) << std::endl; 

  return 0;
}
