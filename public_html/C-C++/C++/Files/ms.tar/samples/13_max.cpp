
#include <iostream>

template <bool cond, typename Then, typename Else>
struct If
{
  typedef Then Ret;
};
template <typename Then, typename Else>
struct If<false, Then, Else>
{
  typedef Else Ret;
};

template <typename T, typename S>
If<sizeof(T)<sizeof(S), S, T>::Ret max( T x, S y)
{
  if ( x > y )
    return x;
  else
    return y;
}

int main()
{
  int i = 3;
  double d = 3.14;

  std::cout << "max( d, i ) = "  << max( d, i) << std::endl; 
  std::cout << "max( i, d ) = "  << max( i, d) << std::endl; 

  return 0;
}
