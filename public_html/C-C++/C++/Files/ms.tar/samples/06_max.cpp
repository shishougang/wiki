
#include <iostream>

template <typename T>
T max( T x, T y)
{
  std::cout << "T max( T x, T y) = ";
  if ( x > y )
    return x;
  else
    return y;
}
template <typename R, typename T, typename S>
R max( T x, S y)
{
  std::cout << "R max( T x, S y) = ";
  if ( x > y )
    return x;
  else
    return y;
}

int main()
{
  int i = 3;
  double d = 3.14;

  std::cout << max( 2, i) << std::endl; 
  std::cout << max<double>( i, d ) << std::endl; 

  return 0;
}
