
#include <iostream>

#define MAX(a,b)  a > b ? a : b


int main()
{
  int i = 3;
  double d = 3.14;

  std::cout << "MAX( i, d ) = "   << ( MAX( i, d) )   << std::endl; 
  std::cout << "MAX( i, d )*2 = " << ( MAX( i, d)*2 ) << std::endl; 
  std::cout << "MAX( ++i, d ) = " << ( MAX( ++i, d) ) << std::endl; 

  return 0;
}
