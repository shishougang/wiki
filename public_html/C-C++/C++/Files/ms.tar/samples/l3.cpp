
#include <algorithm>
#include <iostream>
#include <ostream>
#include <vector>

using namespace std;

int main()
{
    vector<int> v;
    for(int i = 0; i < 10; ++i)
        v.push_back(i);

    for_each(v.begin(), v.end(), [](int n) { 
		    cout << n ; 
		    if ( n % 2 )
		        cout << ":odd ";
		    else
		        cout << ":even ";
		  });
    cout << endl;

    return 0;
}
