
#include <algorithm>
#include <iostream>
#include <ostream>
#include <vector>

using namespace std;

struct X
{
    int s;
    vector<int> v;
    void print() const
    {
        for_each(v.begin(), v.end(), [this](int n) { cout << n*s << " "; });
    }
};

int main()
{
    X x;	
    x.s = 2;
    for(int i = 0; i < 10; ++i)
        x.v.push_back(i);

    x.print(); 
    return 0;
}
