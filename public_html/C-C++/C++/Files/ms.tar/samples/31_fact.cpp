
#include <iostream>

static inline int f(char *s){ return 1;}


template <int N>
struct Fact
{
  enum { begin = sizeof (f("")) };
  enum { value = Fact<N-1>::value * N };
  enum { end = sizeof (f("")) };
};

template <>
struct Fact<1>
{
  enum { begin = sizeof (f("")) };
  enum { value = 1 };
  enum { end = sizeof (f("")) };
};

int main()
{
  std::cout << Fact<6>::value << std::endl;
  return 0;
}
