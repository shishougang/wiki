
#include <iostream>

template <typename R, typename T, typename S>
R max( T x, S y)
{
  if ( x > y )
    return x;
  else
    return y;
}

int main()
{
  int i = 3;
  double d = 3.14;

  std::cout << "max<double>( d, i ) = "  << max<double>( d, i) << std::endl; 
  std::cout << "max<double>( i, d ) = "  << max<double>( i, d) << std::endl; 

  return 0;
}
