
#include <algorithm>
#include <iostream>
#include <ostream>
#include <vector>
#include <deque>

using namespace std;

int main()
{
    vector<int> v;
    for(int i = 0; i < 10; ++i)
        v.push_back(i);

    deque<int> d;

    transform(v.begin(), v.end(), front_inserter(d), [](int n) {return n*n;} );

    for_each(d.begin(), d.end(), [](int n) { cout << n << " "; }); 
    
    cout << endl;
    return 0;
}
