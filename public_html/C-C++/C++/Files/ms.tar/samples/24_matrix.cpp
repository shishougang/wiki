
#include <iostream>
#include <cstring>

template <typename T>
struct is_pod
{
  enum { value = false };
};

template <>
struct is_pod<int>
{
  enum { value = true };
};

template <>
struct is_pod<double>
{
  enum { value = true };
};

template <typename T, bool IsPod>
struct copy_trait
{
  static  void copy( T* to, const T* from, int n)
  {
    std::cerr << "default copy with loop" << std::endl;
          
    for( int i = 0; i < n; ++i )
      to[i] = from[i];
  }
};
template <typename T>
struct copy_trait<T,true>
{
  static void copy( T* to, const T* from, int n)
  {
    std::cerr << "bitwise copy" << std::endl;
   
    memcpy( to, from, n*sizeof(T));
  }
};

template <typename T, typename Cpy = copy_trait<T, is_pod<T>::value> >
class matrix
{
public:
  matrix(int i, int j) : cols_(i), rows_(j), v_(new T[cols_*rows_]) {}
  ~matrix() {delete [] v_;}
  matrix(const matrix& rhs);
  matrix& operator=(const matrix& rhs);
private:
  int cols_;
  int rows_;
  T   *v_;

  void copy(const matrix&);
};
template <class T,typename Cpy>
matrix<T,Cpy>& matrix<T,Cpy>::operator=( const matrix &other)
{
  if ( this != &other )
  {
    delete [] v_;
    copy( other);
  }
  return *this;
}
template <class T, class Cpy>
void matrix<T,Cpy>::copy( const matrix &other)
{
  rows_ = other.rows_;
  cols_ = other.cols_;
  v_ = new T[rows_*cols_];
  Cpy::copy( v_, other.v_, rows_*cols_);
}
class nonpod
{
  char *ptr;
};

int main()
{
  matrix<int>    mi(10,10), mi2(10,10);
  matrix<double> md(20,10), md2(20,10);
  matrix<nonpod> mn(20,10), mn2(20,10);
  mi = mi2;
  md = md2;
  mn = mn2;

  return 0;
}
