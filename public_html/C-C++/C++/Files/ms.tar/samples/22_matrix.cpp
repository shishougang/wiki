
#include <iostream>
#include <cstring>

template <typename T>
class matrix
{
public:
  matrix(int i, int j) : cols_(i), rows_(j), v_(new T[cols_*rows_]) {}
  ~matrix() {delete [] v_;}
  matrix(const matrix& rhs);
  matrix& operator=(const matrix& rhs);
private:
  int cols_;
  int rows_;
  T   *v_;

  void copy(const matrix&);
};
template <class T>
matrix<T>& matrix<T>::operator=( const matrix &other)
{
  if ( this != &other )
  {
    delete [] v_;
    copy( other);
  }
  return *this;
}
template <class T>
void matrix<T>::copy( const matrix &other)
{
  std::cout << "copy with loop" << std::endl;

  rows_ = other.rows_;
  cols_ = other.cols_;
  v_ = new T[rows_*cols_];
  for ( int i = 0; i < rows_*cols_; ++i )
    v_[i] = other.v_[i];
}
template <>
void matrix<int>::copy( const matrix &other)
{
  std::cout << "copy with memcpy" << std::endl;

  rows_ = other.rows_;
  cols_ = other.cols_;
  v_ = new int[rows_*cols_];
  memcpy( v_, other.v_, sizeof(int)*rows_*cols_);
}
class nonpod
{
  char *ptr;
};

int main()
{
  matrix<int>    mi(10,10), mi2(10,10);
  matrix<double> md(20,10), md2(20,10);
  matrix<nonpod> mn(20,10), mn2(20,10);
  mi = mi2;
  md = md2;
  mn = mn2;

  return 0;
}
