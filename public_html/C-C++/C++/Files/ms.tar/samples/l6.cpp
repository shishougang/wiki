
#include <algorithm>
#include <iostream>
#include <ostream>
#include <vector>

using namespace std;

int main()
{
    vector<int> v;
    for(int i = 0; i < 10; ++i)
        v.push_back(i);

    int x = 0;
    int y = 0;
    cin >> x >> y;

    v.erase( remove_if(v.begin(), 
	               v.end(),
                       [x,y](int n) -> double { return x < n && n < y; }
		      ),  
             v.end() 
           );	

    for_each(v.begin(), v.end(), [](double n) { cout << n << " "; }); 
    
    cout << endl;
    return 0;
}
