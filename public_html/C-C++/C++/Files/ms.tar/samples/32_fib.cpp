
#include <iostream>

static inline int f(char *s){ return 1;}

template <int N>
struct Fib
{
  enum { begin = sizeof (f("")) };
  enum { value = Fib<N-1>::value + Fib<N-2>::value };
  enum { end = sizeof (f("")) };
};

template <>
struct Fib<0>
{
  enum { value = 0 };
};
template <>
struct Fib<1>
{
  enum { value = 1 };
};

int main()
{
  std::cout << Fib<6>::value << std::endl;
  return 0;
}
