
#include <iostream>

template <int N>
struct Fact
{
  enum { value = Fact<N-1>::value * N };
};

template <>
struct Fact<1>
{
  enum { value = 1 };
};

int main()
{
  std::cout << Fact<6>::value << std::endl;
  return 0;
}
