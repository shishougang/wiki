
#include <iostream>

template <typename T, typename S>
T max( T x, S y)
{
  if ( x > y )
    return x;
  else
    return y;
}

int main()
{
  int i = 3;
  double d = 3.14;

  std::cout << "max( d, i ) = "  << max( d, i) << std::endl; 
  std::cout << "max( i, d ) = "  << max( i, d) << std::endl; 

  return 0;
}
