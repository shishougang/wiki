
#include <algorithm>
#include <iostream>
#include <ostream>
#include <vector>
#include <deque>

using namespace std;

int main()
{
    vector<int> v;
    for(int i = 0; i < 10; ++i)
        v.push_back(i);

    deque<double> d;

    transform(v.begin(), v.end(), front_inserter(d), 
		    [](int n) -> double  {return n / 2.0;} );

    for_each(d.begin(), d.end(), [](double n) { cout << n << " "; }); 
    
    cout << endl;
    return 0;
}
