
#include <iostream>

template <typename T>
T max( T x, T y)
{
  if ( x > y )
    return x;
  else
    return y;
}

int main()
{
  int i = 3, j = 4;
  double d = 3.14, e = 2.71;

  std::cout << "max( i, j ) = "  << max( i, j) << std::endl; 
  std::cout << "max( d, e ) = "  << max( d, e) << std::endl; 
//  std::cout << "max( i, d ) = "  << max( i, d) << std::endl; 

  return 0;
}
