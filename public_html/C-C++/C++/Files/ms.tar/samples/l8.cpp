
#include <algorithm>
#include <iostream>
#include <ostream>
#include <vector>

using namespace std;

int main()
{
    vector<int> v;
    for(int i = 0; i < 10; ++i)
        v.push_back(i);

    int prev = 0;
    for_each(v.begin(), v.end(), [=](int& r) mutable { 
		            const int oldr = r;
			    r *= prev; 
		            prev = oldr;	    
			 });

    for_each(v.begin(), v.end(), [](int n) { cout << n << " "; }); 
    
    cout << "prev = " << prev << endl;
    return 0;
}
