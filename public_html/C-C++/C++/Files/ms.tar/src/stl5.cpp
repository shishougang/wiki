

A detailed sample: merge two containers

 

#include <iostream>
#include <fstream>
#include <string>

using namespace std;

// simple merge
int main()
{
    string s1, s2;

    ifstream f1("file1.txt");
    ifstream f2("file2.txt");

    f1 >> s1;
    f2 >> s2;

    // the usual way:
    while (f1 || f2)
    {
        if (f1 && ((s1 <= s2) || !f2))
        {
            cout << s1 << endl;
            f1 >> s1;
        }
        if (f2 && ((s1 >= s2) || !f1))
        {
            cout << s2 << endl;
            f2 >> s2;
        }
    }
    return 0;
}



#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>    // merge( b1, e1, b2, e2, b3 [,opc_rend])
#include <vector>

using namespace std;

int main()
{
    ifstream if1("file1.txt");
    ifstream if2("file2.txt");

    string s;

    vector<string> v1;
    while ( if1 >> s ) v1.push_back(s);

    vector<string> v2;
    while ( if2 >> s ) v2.push_back(s);

    // allocate the spacefor the result
    vector<string> v3(v1.size() + v2.size());   // very expensive...

    merge( v1.begin(), v1.end(),
           v2.begin(), v2.end(),
           v3.begin());             // v3[i] = *current 

    for ( int i = 0; i < v3.size(); ++i)
        cout << v3[i] << endl;

    return 0;
}



#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <vector>

using namespace std;

int main()
{
    ifstream if1("file1.txt");
    ifstream if2("file2.txt");

    string s;

    vector<string> v1;
    while ( if1 >> s ) v1.push_back(s);

    vector<string> v2;
    while ( if2 >> s ) v2.push_back(s);

    vector<string> v3;
    v3.reserve( v1.size() + v2.size() );    // allocates but not construct
                                            // size == 0
    merge( v1.begin(), v1.end(),
           v2.begin(), v2.end(),
           back_inserter(v3));      // v3.push_back(*current)

    for ( int i = 0; i < v3.size(); ++i)
        cout << v3[i] << endl;

    return 0;
}



#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <iterator>     // input- and output-iterators

using namespace std;

int main()
{
    ifstream if1("file1.txt");
    ifstream if2("file2.txt");

    // istream_iterator(if1) -> if1 >> *current
    // istream_iterator() -> EOF
    // ostream_iterator(of,x) -> of << *current << x 
    merge( istream_iterator<string>(if1), istream_iterator<string>(),
           istream_iterator<string>(if2), istream_iterator<string>(),
           ostream_iterator<string>(cout,"\n") );
    return 0;
}



#include <iostream>
#include <fstream>
#include <string>
#include <cctype>
#include <algorithm>
#include <iterator>

// function object: "functor"
struct my_less
{
    bool operator()(const std::string& s1, const std::string& s2)
    {
        std::string us1 = s1;
        std::string us2 = s2;

    // TODO: use locale object 
        transform( s1.begin(), s1.end(), us1.begin(), toupper);
        transform( s2.begin(), s2.end(), us2.begin(), toupper);

        return us1 < us2;
    }
};

using namespace std;

int main()
{
    ifstream if1("file1.txt");
    ifstream if2("file2.txt");

    merge( istream_iterator<string>(if1), istream_iterator<string>(),
           istream_iterator<string>(if2), istream_iterator<string>(),
           ostream_iterator<string>(cout,"\n"), my_less() );
    return 0;
}


#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <iterator>

using namespace std;

// one from left, one from right:
struct zipp
{
    zipp() : flag(true) { }
    bool operator()(const string& s1, const string& s2)
    {
        flag = !flag;
        return flag;
    }
    bool flag;
};

int main()
{
    ifstream if1("file1.txt");
    ifstream if2("file2.txt");

    merge( istream_iterator<string>(if1), istream_iterator<string>(),
           istream_iterator<string>(if2), istream_iterator<string>(),
           ostream_iterator<string>(cout,"\n"), zipp() );
    return 0;
}



#include <iostream>
#include <fstream>
#include <string>
#include <algorithm>
#include <iterator>

using namespace std;

template <typename T>
class distr
{
public:
    distr(int l, int r, bool fl = true) :
                       left(l), right(r), from_left(fl), cnt(0) { }
    // formal reasons: "compare" has two parameters of type T
    bool operator()( const T&, const T&)
    {
        bool ret = from_left;
        const int  max = from_left ? left : right;
        if ( ++cnt == max )
        {
            cnt = 0;
            from_left = ! from_left;
        }
        return ret;
    }
private:
    const int left;
    const int right;
    int from_left;
    int cnt;
};

int main()
{
    int left, right;
    cin >> left >> right;
    ifstream if1("file1.txt");
    ifstream if2("file2.txt");

    merge( istream_iterator<string>(if1), istream_iterator<string>(),
           istream_iterator<string>(if2), istream_iterator<string>(),
           ostream_iterator<string>(cout,"\n"),
                                    distr<std::string>(left,right) );
    return 0;
}



