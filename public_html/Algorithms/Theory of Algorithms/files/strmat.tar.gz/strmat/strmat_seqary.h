
void create_seq_array(void), free_seq_ary();
int add_element(void), get_num_sequences(void), delete_element(int);
STRING* get_element(int);
void set_mark(int, int);
int get_mark(int);







































