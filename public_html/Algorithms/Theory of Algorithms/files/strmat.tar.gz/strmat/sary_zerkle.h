
#ifndef _SARY_ZERKLE_H_
#define _SARY_ZERKLE_H_

int zerkle(char *s, int n, int *posarray);
 
#endif
