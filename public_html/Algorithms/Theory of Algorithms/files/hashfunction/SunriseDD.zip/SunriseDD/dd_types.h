/*! Sunrise Data Dictionary Library
 *
 *  @brief a library for hashtable storage of arbitrary data objects
 *  with built-in reference counting and guaranteed order iteration.
 *
 *  @file dd_types.h
 *  common type definitions
 *
 *  Created by Sunrise Telephone Systems Ltd.
 *
 *  This file ("dd_types.h") is hereby placed into the public domain.
 *
 */

#ifndef _DD_TYPES_H
#define _DD_TYPES_H

#ifndef bool
#include <stdbool.h>
#endif

#ifndef BOOLEAN
#define BOOLEAN bool
#endif

#ifndef INTEGER
#define INTEGER int
#endif

#ifndef cardinal
typedef unsigned int cardinal;
#endif

#ifndef CARDINAL
#define CARDINAL cardinal
#endif

#ifndef int8_t
#include <stdint.h>
#endif

#ifndef octett_t
typedef uint8_t octett_t;
#endif

#ifndef OCTETT
#define OCTETT octett_t
#endif

#ifndef BYTE
#define BYTE octett_t
#endif

#ifndef char_t
typedef unsigned char char_t;
#endif

#ifndef CHAR
#define CHAR char_t
#endif

#ifndef word_t
typedef uint16_t word_t;
#endif

#ifndef WORD
#define WORD word_t
#endif

#ifndef pointer_t
typedef void* pointer_t;
#endif

#ifndef POINTER
#define POINTER pointer_t
#endif

#endif

// END OF FILE