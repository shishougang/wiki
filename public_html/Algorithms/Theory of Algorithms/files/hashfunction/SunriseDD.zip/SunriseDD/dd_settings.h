/*! Sunrise Data Dictionary Library
 *
 *  @brief a library for hashtable storage of arbitrary data objects
 *  with built-in reference counting and guaranteed order iteration.
 *
 *  @file dd_settings.h
 *  compile-time settings
 *
 *  This file can be edited by library users for customisation.
 *  The library needs to be rebuild for changes to take effect.
 *
 *  Created by Sunrise Telephone Systems Ltd.
 *
 *  This file ("dd_settings.h") is hereby placed into the public domain.
 *
 */

#ifndef _DD_SETTINGS_H
#define _DD_SETTINGS_H


// --------------------------------------------------------------------------
// Memory allocator
// --------------------------------------------------------------------------
//
// If true,  calls to malloc and free are replaced for use with the Boehm GC.

#define DD_USE_BOEHM_GC   false

// --------------------------------------------------------------------------
// Use of Pthreads
// --------------------------------------------------------------------------
//
// If true,  the library will use Pthread mutex variables for locking.

#define DD_USE_PTHREADS   false


// --------------------------------------------------------------------------
// Performance optimisation
// --------------------------------------------------------------------------
//
// If true,  private functions will always be inlined for better performance.
//
// Factory default: true

#define DD_ALWAYS_INLINE_PRIVATE_FUNCTIONS   true


// --------------------------------------------------------------------------
// Number of significant characters
// --------------------------------------------------------------------------
//
// Number of characters used to calculate hash values from keys when using
// one of the built-in (library supplied) hash functions.
//
// Factory default: 32

#define DD_SIGNIFICANT_CHARS   32


// --------------------------------------------------------------------------
// Default hash algorithm
// --------------------------------------------------------------------------
//
// Selects the default hash algorithm, either SDBM, DJB, ELF, FNVM or HSIEH.
//
// Factory default: DD_SDBM

#define DD_SDBM 1
#define DD_DJB 2
#define DD_ELF 3
#define DD_FNVM 4
#define DD_HSIEH 5

#define DD_DEFAULT_HASH_ALGORITHM   DD_SDBM


// --------------------------------------------------------------------------
// Default case sensitivity
// --------------------------------------------------------------------------
//
// If true  the case sensitive hash function  for the  default hash algorithm 
// will be used as the default hash function,  if false  the case insensitive
// hash function  for the default hash algorithm  will be used as the default
// hash function.
//
// Note: Case insensitive hashing degrades the performance of a hash function
// not simply because all characters need to be checked and converted but far
// more importantly because the resulting hash codes are  not as well spread,
// causing more collissions in hashtables which leads to longer lookup times.
//
// Factory default: true

#define DD_CASE_SENSITIVE_HASHING   true


// --------------------------------------------------------------------------
// Trimming keys
// --------------------------------------------------------------------------
//
// DD_AUTOMATICALLY_TRIM_KEYS
//
// If true, any leading and trailing whitespace will automatically be removed
// from keys and symbols when they are added to a dictionary or symbol table.
//
// Factory default: true
//
// DD_MAXIMUM_CHARS_TO_SCAN_WHEN_TRIMMING
//
// If  automatic  trimming  of  keys  is  enabled,  keys  with  more  leading
// whitespace/tab than this value will be rejected.
//
// Factory default: 32
//
// Note: The resulting behaviour is static, it cannot be changed at runtime.

#define DD_AUTOMATICALLY_TRIM_KEYS   true
#define DD_MAXIMUM_CHARS_TO_SCAN_WHEN_TRIMMING   32


// --------------------------------------------------------------------------
// Rejecting keys
// --------------------------------------------------------------------------
//
// If true, keys containing any characters other than printable 7-bit ASCII
// characters will be rejected.
//
// Note: The resulting behaviour is static, it cannot be changed at runtime.
//
// Factory default: false

#define DD_PRINTABLE_7BIT_ASCII_KEYS_ONLY   false


// --------------------------------------------------------------------------
// Maximum key length limit
// --------------------------------------------------------------------------
//
// Keys longer than this value will be truncated.
//
// Note: The resulting behaviour is static, it cannot be changed at runtime.
//
// Factory default: 128

#define DD_MAXIMUM_KEY_LENGTH   128


// --------------------------------------------------------------------------
// Default hashtable size
// --------------------------------------------------------------------------
//
// This value will be used to determine the _actual_ default hashtable size.
// The actual default hashtable size is always a multiple of 256 rounded up
// to the next prime number but limited to a maximum of 32771.
//
// The memory required by an empty dictionary is calculated as follows:
//
//   memory = hashtable size * 4 bytes + 320 bytes
//
// Factory default: 250

#define DD_MINIMUM_DEFAULT_HASHTABLE_SIZE   250


// --------------------------------------------------------------------------
// Default symbol table size
// --------------------------------------------------------------------------
//
// This value will be used to determine the hashtable size of symbol tables.
// The actual hashtable size is always a prime number in the range 7 to 257.
//
// The memory required by an empty symbol table is calculated as follows:
//
//   memory = hashtable size * 4 bytes + 56 bytes
//
// Factory default: 100

#define DD_MINIMUM_DEFAULT_SYMBOL_TABLE_SIZE   100


// --------------------------------------------------------------------------
// Dictionary disposal wait limit
// --------------------------------------------------------------------------
//
// Maximum number of times  the dictionary disposal function  will  wait  for
// pending lookups and inserts to complete before giving up.  Each wait cycle
// lasts 75 ms.
//
// Note: The resulting behaviour is static, it cannot be changed at runtime.
//
// Factory default: 4000 (resulting total maximum wait time: about 5 minutes)

#define DD_MAXIMUM_DICTIONARY_DISPOSAL_WAIT_LOOP_COUNT   4000


#endif

// END OF FILE