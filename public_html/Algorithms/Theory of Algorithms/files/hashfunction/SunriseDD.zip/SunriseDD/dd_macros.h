/*! Sunrise Data Dictionary Library
*
*  @brief a library for hashtable storage of arbitrary data objects
*  with built-in reference counting and guaranteed order iteration.
*
*  @file dd_macros.h
*  convenience macros go in here
*
*  Created by Sunrise Telephone Systems Ltd.
*
*  This file ("dd_macros.h") is hereby placed into the public domain.
*
*/

#ifndef _DD_CONVENIENCE_MACROS_H
#define _DD_CONVENIENCE_MACROS_H


// --------------------------------------------------------------------------
// macro:  DD_ALWAYS_INLINE
// --------------------------------------------------------------------------
//
// Alias for function attribute "always_inline"

#define DD_ALWAYS_INLINE __attribute__((always_inline))


// --------------------------------------------------------------------------
// macro:  DD_PURE_FUNCTION
// --------------------------------------------------------------------------
//
// Alias for function attribute "pure"

#define DD_PURE_FUNCTION __attribute__((pure))


// --------------------------------------------------------------------------
// macro:  DD_KEY_EXISTS(dict, key)
// --------------------------------------------------------------------------
//
// Returns true if key <key> is present in dictionary <dict>,  returns false
// if it is not or if <dict> is NULL.

#define DD_KEY_EXISTS(_dict, _key) \
(dd_object_for_key(_dict, _key, false) != NULL)


#endif

// END OF FILE
