/*! Sunrise Data Dictionary Library
 *
 *  @brief a library for hashtable storage of arbitrary data objects
 *  with built-in reference counting and guaranteed order iteration.
 *
 *  @file dd_defaults.c
 *  defaults used by the library
 *
 *  @author Benjamin Kowarsch <nospam://com.sunrise-tel/~firstname~>
 *
 *  @note The author's true email address is herewith specifically excluded
 *  from the license of this software.  You are _not permitted_ to make the
 *  author's true email address available to any third party.  You may only
 *  pass on the modified version of the email address as presented above.
 *
 * (C) 2006 Sunrise Telephone Systems Ltd. All rights reserved.
 *
 * @cond LICENSE_TERMS
 *
 * Permission is  hereby granted,  free of charge,  to any person obtaining a
 * copy of this software and associated documentation files (the "Software"),
 * to deal in the Software without restriction,  including without limitation
 * the rights  to  use, copy, modify, merge, publish, distribute, sublicense,
 * and/or  sell copies of  the Software,  and  to permit persons  to whom the
 * Software is furnished to do so,  subject to the following conditions:
 *
 * The above copyright notice  and  this permission notice  shall be included
 * in all copies or substantial portions of the Software.
 *
 * Under no circumstances is it permitted for any licensee to take credit for
 * the creation of  the Software,  to claim  authorship  or  ownership in the
 * Software  or in any other way  give the impression  that they have created
 * the Software.  Credit to the  true authors  and  copyright holders  of the
 * Software is absolutely mandatory and must be given as follows:
 *
 * Software packages incorporating the Software or substantial portions of it
 * shall display  a copyright notice  for the Software  in the same manner as
 * they  display  any  other copyright notice;  shall  display  an authorship
 * notice  for  the Software  in the  same manner  as they display  any other
 * authorship notice;  and shall display  the license terms or a reference to
 * the license terms of the Software  in the same manner  as they display any
 * other license or license reference.
 *
 * GUI-based or GUI-alike  interactive installers  installing the Software or
 * substantial portions of it, shall display the Software's copyright notice,
 * authorship notice  and  license terms  in  full  during  the  installation
 * process.  Other installers such as shell command driven package installers
 * on Unix systems shall display copyright,  authorship  and  license  in the
 * same  manner  as for  any other software.  Installers shall allow users to
 * install the license file for the Software along with the Software itself.
 *
 * Software  which makes use of  but  does not incorporate,  nor bundle,  nor
 * install the Software  or substantial portions of it,  is  NOT  required to
 * display any copyright, authorship, license terms  or license reference for
 * the Software.  Static linking to the Software constitutes 'incorporating',
 * dynamic linking to the Software constitutes 'making use of' the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED,  INCLUDING  BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE  AND  NONINFRINGEMENT.  IN NO EVENT SHALL
 * THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY,  WHETHER IN AN ACTION OF CONTRACT,  TORT OR OTHERWISE,  ARISING
 * FROM,  OUT OF  OR  IN CONNECTION WITH THE SOFTWARE  OR  THE USE  OR  OTHER
 * DEALINGS IN THE SOFTWARE.
 *
 * In countries and territories  where  the  above  no-warranty disclaimer is
 * not permissible by applicable law, the following terms apply:
 *
 * NO PERMISSION TO USE THE SOFTWARE IS GRANTED  AND THE SOFTWARE MUST NOT BE
 * USED AT ALL  IN SUCH COUNTRIES AND TERRITORIES WHERE THE ABOVE NO-WARRANTY
 * DISCLAIMER IS NOT PERMISSIBLE AND INVALIDATED BY APPLICABLE LAW.  HOWEVER,
 * THE COPYRIGHT HOLDERS HEREBY WAIVE THEIR RIGHT TO PURSUE OFFENDERS AS LONG
 * AS THEY OTHERWISE ABIDE BY THE TERMS OF THE LICENSE  AS APPLICABLE FOR USE
 * OF THE SOFTWARE  IN COUNTRIES AND TERRITORIES WHERE THE ABOVE  NO-WARRANTY
 * DISCLAIMER IS PERMITTED BY APPLICABLE LAW. THIS WAIVER DOES NOT CONSTITUTE
 * A LICENSE TO USE THE SOFTWARE IN COUNTRIES AND TERRITORIES WHERE THE ABOVE
 * NO-WARRANTY DISCLAIMER IS  NOT PERMISSIBLE  AND  INVALIDATED BY APPLICABLE
 * LAW.  ANY LIABILITY OF ANY KIND IS CATEGORICALLY RULED OUT AT ALL TIMES.
 *
 * @endcond
 */

#include <stddef.h>

#include "dd_types.h"
#include "dd_settings.pp"
#include "dd_hash_functions.h"


#define DD_LIBRARY_VERSION 100


// --------------------------------------------------------------------------
// function:  dd_library_version()
// --------------------------------------------------------------------------
//
// Returns the library version number.

inline cardinal dd_library_version() {
	return DD_LIBRARY_VERSION;
} // end dd_library_version;

// --------------------------------------------------------------------------
// function:  dd_built_with_boem_gc()
// --------------------------------------------------------------------------
//
// Returns true if the library was built to use the Boehm garbage collector,
// returns false otherwise.  The factory default is 'false'.

inline bool dd_built_with_boem_gc() {
	return DD_USE_BOEHM_GC;
} // end dd_built_with_boem_gc;


// --------------------------------------------------------------------------
// function:  dd_built_with_pthreads()
// --------------------------------------------------------------------------
//
// Returns true if the library  was  built to use the  pthreads API,  returns
// false otherwise.  The factory default is 'false' (this will be changed).

inline bool dd_built_with_pthreads() {
	return DD_USE_PTHREADS;
} // end dd_built_with_pthreads;


// --------------------------------------------------------------------------
// function:  dd_significant_chars()
// --------------------------------------------------------------------------
//
// Returns the number of significant characters used to calculate hash values
// when using one of the library supplied hash functions. The factory default
// for this value is 32.

inline cardinal dd_significant_chars() {
	return DD_SIGNIFICANT_CHARS;
} // end dd_significant_chars;


// --------------------------------------------------------------------------
// function:  dd_default_hash_algorithm()
// --------------------------------------------------------------------------
//
// Returns a  numeric code  for  the  default hash algorithm.  The codes are:
// 1 = SDBM, 2 = DJB, 3 = ELF, 4 = FNVM, 5 = HSIEH.

inline cardinal dd_default_hash_algorithm() {
	return DD_DEFAULT_HASH_ALGORITHM;
} // end dd_default_hash_algorithm;


// --------------------------------------------------------------------------
// function:  dd_default_hash_is_case_sensitive()
// --------------------------------------------------------------------------
//
// Returns true if the default hash function is case sensitive, returns false
// otherwise.  The factory default for this value is 'true'.

inline bool dd_default_hash_is_case_sensitive() {
	return DD_CASE_SENSITIVE_HASHING;
} // end dd_default_hash_is_case_sensitive;


// --------------------------------------------------------------------------
// function:  dd_default_hash_function()
// --------------------------------------------------------------------------
//
// Returns a pointer to the default hash function  used when no specific hash
// function has been set. The factory default is dd_SDBM_hash_string().

inline dd_hash_function dd_default_hash_function() {
	return DD_DEFAULT_HASH_FUNCTION;
} // end dd_default_hash_function;


// --------------------------------------------------------------------------
// function:  dd_keys_are_automatically_trimmed()
// --------------------------------------------------------------------------
//
// Returns true if leading and trailing whitespace is automatically removed
// from keys and symbols when they are added to a dictionary or symbol table,
// returns false otherwise.  The factory default for this value is 'true'.

inline bool dd_keys_are_automatically_trimmed() {
	return DD_AUTOMATICALLY_TRIM_KEYS;
} // end dd_keys_are_automatically_trimmed;


// --------------------------------------------------------------------------
// function:  dd_maximum_key_trim_chars()
// --------------------------------------------------------------------------
//
// Returns the  maximum number of leading whitespace characters  scanned when
// automatic key trimming is enabled.  The factory default is 32.

inline cardinal dd_maximum_key_trim_chars() {
	return DD_MAXIMUM_CHARS_TO_SCAN_WHEN_TRIMMING;
} // end dd_maximum_key_trim_chars;


// --------------------------------------------------------------------------
// function:  dd_printable_7bit_ASCII_only()
// --------------------------------------------------------------------------
//
// Returns true if keys ans symbols containing any characters other than
// printable 7bit ASCII characters are rejected, returns false otherwise.
// The factory default for this value is 'false'.

inline bool dd_printable_7bit_ASCII_keys_only() {
	return DD_PRINTABLE_7BIT_ASCII_KEYS_ONLY;
} // end dd_printable_7bit_ASCII_keys_only;


// --------------------------------------------------------------------------
// function:  dd_maximum_key_length()
// --------------------------------------------------------------------------
//
// Returns the maximum length for keys stored in dictionaries.  The factory
// default for this value is 128.

inline cardinal dd_maximum_key_length() {
	return DD_MAXIMUM_KEY_LENGTH;
} // end dd_maximum_key_length;


// --------------------------------------------------------------------------
// function:  dd_default_hashtable_size()
// --------------------------------------------------------------------------
//
// Returns the default hashtable size for creating dictionaries.  The factory
// default for this value is 257.

inline cardinal dd_default_hashtable_size() {
	return DD_DEFAULT_HASHTABLE_SIZE;
} // end dd_default_hashtable_size;


// --------------------------------------------------------------------------
// function:  dd_default_symtable_size()
// --------------------------------------------------------------------------
//
// Returns the default hashtable size for creating symbol tables. The factory
// default for this value is 257.

inline cardinal dd_default_symtable_size() {
	return DD_DEFAULT_SYMTABLE_SIZE;
} // end dd_default_symtable_size;


// --------------------------------------------------------------------------
// function:  dd_maximum_dictionary_disposal_wait_loop_count()
// --------------------------------------------------------------------------
//
// Returns the maximum number of times  the dictionary disposal function will
// wait for  pending lookups and inserts  to complete before giving up.  Each
// wait cycle lasts 75 ms.  The factory defauls for this value is 4000.

inline cardinal dd_maximum_dictionary_disposal_wait_loop_count() {
	return DD_MAXIMUM_DICTIONARY_DISPOSAL_WAIT_LOOP_COUNT;
} // end dd_maximum_dictionary_disposal_wait_loop_count;


// END OF FILE